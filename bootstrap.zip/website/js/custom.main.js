/*!
 * Webflow: Front-end site library
 * @license MIT
 * Inline scripts may access the api using an async handler:
 *   var Webflow = Webflow || [];
 *   Webflow.push(readyFunction);
 */

(() => {
	var om = Object.create;
	var qn = Object.defineProperty;
	var am = Object.getOwnPropertyDescriptor;
	var sm = Object.getOwnPropertyNames;
	var um = Object.getPrototypeOf,
		cm = Object.prototype.hasOwnProperty;
	var ye = (e, t) => () => (e && (t = e(e = 0)), t);
	var g = (e, t) => () => (t || e((t = {
			exports: {}
		}).exports, t), t.exports),
		Fe = (e, t) => {
			for (var n in t) qn(e, n, {
				get: t[n],
				enumerable: !0
			})
		},
		Ea = (e, t, n, r) => {
			if (t && typeof t == "object" || typeof t == "function")
				for (let i of sm(t)) !cm.call(e, i) && i !== n && qn(e, i, {
					get: () => t[i],
					enumerable: !(r = am(t, i)) || r.enumerable
				});
			return e
		};
	var ge = (e, t, n) => (n = e != null ? om(um(e)) : {}, Ea(t || !e || !e.__esModule ? qn(n, "default", {
			value: e,
			enumerable: !0
		}) : n, e)),
		$e = e => Ea(qn({}, "__esModule", {
			value: !0
		}), e);
	var _a = g(() => {
		"use strict";
		(function() {
			if (typeof window > "u") return;
			let e = window.navigator.userAgent.match(/Edge\/(\d{2})\./),
				t = e ? parseInt(e[1], 10) >= 16 : !1;
			if ("objectFit" in document.documentElement.style && !t) {
				window.objectFitPolyfill = function() {
					return !1
				};
				return
			}
			let r = function(a) {
					let u = window.getComputedStyle(a, null),
						l = u.getPropertyValue("position"),
						_ = u.getPropertyValue("overflow"),
						d = u.getPropertyValue("display");
					(!l || l === "static") && (a.style.position = "relative"), _ !== "hidden" && (a.style.overflow = "hidden"), (!d || d === "inline") && (a.style.display = "block"), a.clientHeight === 0 && (a.style.height = "100%"), a.className.indexOf("object-fit-polyfill") === -1 && (a.className += " object-fit-polyfill")
				},
				i = function(a) {
					let u = window.getComputedStyle(a, null),
						l = {
							"max-width": "none",
							"max-height": "none",
							"min-width": "0px",
							"min-height": "0px",
							top: "auto",
							right: "auto",
							bottom: "auto",
							left: "auto",
							"margin-top": "0px",
							"margin-right": "0px",
							"margin-bottom": "0px",
							"margin-left": "0px"
						};
					for (let _ in l) u.getPropertyValue(_) !== l[_] && (a.style[_] = l[_])
				},
				o = function(a) {
					let u = a.parentNode;
					r(u), i(a), a.style.position = "absolute", a.style.height = "100%", a.style.width = "auto", a.clientWidth > u.clientWidth ? (a.style.top = "0", a.style.marginTop = "0", a.style.left = "50%", a.style.marginLeft = a.clientWidth / -2 + "px") : (a.style.width = "100%", a.style.height = "auto", a.style.left = "0", a.style.marginLeft = "0", a.style.top = "50%", a.style.marginTop = a.clientHeight / -2 + "px")
				},
				s = function(a) {
					if (typeof a > "u" || a instanceof Event) a = document.querySelectorAll("[data-object-fit]");
					else if (a && a.nodeName) a = [a];
					else if (typeof a == "object" && a.length && a[0].nodeName) a = a;
					else return !1;
					for (let u = 0; u < a.length; u++) {
						if (!a[u].nodeName) continue;
						let l = a[u].nodeName.toLowerCase();
						if (l === "img") {
							if (t) continue;
							a[u].complete ? o(a[u]) : a[u].addEventListener("load", function() {
								o(this)
							})
						} else l === "video" ? a[u].readyState > 0 ? o(a[u]) : a[u].addEventListener("loadedmetadata", function() {
							o(this)
						}) : o(a[u])
					}
					return !0
				};
			document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", s) : s(), window.addEventListener("resize", s), window.objectFitPolyfill = s
		})()
	});
	var Ia = g(() => {
		"use strict";
		(function() {
			if (typeof window > "u") return;

			function e(r) {
				Webflow.env("design") || ($("video").each(function() {
					r && $(this).prop("autoplay") ? this.play() : this.pause()
				}), $(".w-background-video--control").each(function() {
					r ? n($(this)) : t($(this))
				}))
			}

			function t(r) {
				r.find("> span").each(function(i) {
					$(this).prop("hidden", () => i === 0)
				})
			}

			function n(r) {
				r.find("> span").each(function(i) {
					$(this).prop("hidden", () => i === 1)
				})
			}
			$(document).ready(() => {
				let r = window.matchMedia("(prefers-reduced-motion: reduce)");
				r.addEventListener("change", i => {
					e(!i.matches)
				}), r.matches && e(!1), $("video:not([autoplay])").each(function() {
					$(this).parent().find(".w-background-video--control").each(function() {
						t($(this))
					})
				}), $(document).on("click", ".w-background-video--control", function(i) {
					if (Webflow.env("design")) return;
					let o = $(i.currentTarget),
						s = $(`video#${o.attr("aria-controls")}`).get(0);
					if (s)
						if (s.paused) {
							let a = s.play();
							n(o), a && typeof a.catch == "function" && a.catch(() => {
								t(o)
							})
						} else s.pause(), t(o)
				})
			})
		})()
	});
	var Zr = g(() => {
		"use strict";
		window.tram = function(e) {
			function t(f, w) {
				var C = new y.Bare;
				return C.init(f, w)
			}

			function n(f) {
				return f.replace(/[A-Z]/g, function(w) {
					return "-" + w.toLowerCase()
				})
			}

			function r(f) {
				var w = parseInt(f.slice(1), 16),
					C = w >> 16 & 255,
					N = w >> 8 & 255,
					k = 255 & w;
				return [C, N, k]
			}

			function i(f, w, C) {
				return "#" + (1 << 24 | f << 16 | w << 8 | C).toString(16).slice(1)
			}

			function o() {}

			function s(f, w) {
				l("Type warning: Expected: [" + f + "] Got: [" + typeof w + "] " + w)
			}

			function a(f, w, C) {
				l("Units do not match [" + f + "]: " + w + ", " + C)
			}

			function u(f, w, C) {
				if (w !== void 0 && (C = w), f === void 0) return C;
				var N = C;
				return be.test(f) || !xe.test(f) ? N = parseInt(f, 10) : xe.test(f) && (N = 1e3 * parseFloat(f)), 0 > N && (N = 0), N === N ? N : C
			}

			function l(f) {
				H.debug && window && window.console.warn(f)
			}

			function _(f) {
				for (var w = -1, C = f ? f.length : 0, N = []; ++w < C;) {
					var k = f[w];
					k && N.push(k)
				}
				return N
			}
			var d = function(f, w, C) {
					function N(se) {
						return typeof se == "object"
					}

					function k(se) {
						return typeof se == "function"
					}

					function G() {}

					function ie(se, oe) {
						function B() {
							var Re = new ue;
							return k(Re.init) && Re.init.apply(Re, arguments), Re
						}

						function ue() {}
						oe === C && (oe = se, se = Object), B.Bare = ue;
						var le, Ie = G[f] = se[f],
							Ve = ue[f] = B[f] = new G;
						return Ve.constructor = B, B.mixin = function(Re) {
							return ue[f] = B[f] = ie(B, Re)[f], B
						}, B.open = function(Re) {
							if (le = {}, k(Re) ? le = Re.call(B, Ve, Ie, B, se) : N(Re) && (le = Re), N(le))
								for (var rn in le) w.call(le, rn) && (Ve[rn] = le[rn]);
							return k(Ve.init) || (Ve.init = se), B
						}, B.open(oe)
					}
					return ie
				}("prototype", {}.hasOwnProperty),
				m = {
					ease: ["ease", function(f, w, C, N) {
						var k = (f /= N) * f,
							G = k * f;
						return w + C * (-2.75 * G * k + 11 * k * k + -15.5 * G + 8 * k + .25 * f)
					}],
					"ease-in": ["ease-in", function(f, w, C, N) {
						var k = (f /= N) * f,
							G = k * f;
						return w + C * (-1 * G * k + 3 * k * k + -3 * G + 2 * k)
					}],
					"ease-out": ["ease-out", function(f, w, C, N) {
						var k = (f /= N) * f,
							G = k * f;
						return w + C * (.3 * G * k + -1.6 * k * k + 2.2 * G + -1.8 * k + 1.9 * f)
					}],
					"ease-in-out": ["ease-in-out", function(f, w, C, N) {
						var k = (f /= N) * f,
							G = k * f;
						return w + C * (2 * G * k + -5 * k * k + 2 * G + 2 * k)
					}],
					linear: ["linear", function(f, w, C, N) {
						return C * f / N + w
					}],
					"ease-in-quad": ["cubic-bezier(0.550, 0.085, 0.680, 0.530)", function(f, w, C, N) {
						return C * (f /= N) * f + w
					}],
					"ease-out-quad": ["cubic-bezier(0.250, 0.460, 0.450, 0.940)", function(f, w, C, N) {
						return -C * (f /= N) * (f - 2) + w
					}],
					"ease-in-out-quad": ["cubic-bezier(0.455, 0.030, 0.515, 0.955)", function(f, w, C, N) {
						return (f /= N / 2) < 1 ? C / 2 * f * f + w : -C / 2 * (--f * (f - 2) - 1) + w
					}],
					"ease-in-cubic": ["cubic-bezier(0.550, 0.055, 0.675, 0.190)", function(f, w, C, N) {
						return C * (f /= N) * f * f + w
					}],
					"ease-out-cubic": ["cubic-bezier(0.215, 0.610, 0.355, 1)", function(f, w, C, N) {
						return C * ((f = f / N - 1) * f * f + 1) + w
					}],
					"ease-in-out-cubic": ["cubic-bezier(0.645, 0.045, 0.355, 1)", function(f, w, C, N) {
						return (f /= N / 2) < 1 ? C / 2 * f * f * f + w : C / 2 * ((f -= 2) * f * f + 2) + w
					}],
					"ease-in-quart": ["cubic-bezier(0.895, 0.030, 0.685, 0.220)", function(f, w, C, N) {
						return C * (f /= N) * f * f * f + w
					}],
					"ease-out-quart": ["cubic-bezier(0.165, 0.840, 0.440, 1)", function(f, w, C, N) {
						return -C * ((f = f / N - 1) * f * f * f - 1) + w
					}],
					"ease-in-out-quart": ["cubic-bezier(0.770, 0, 0.175, 1)", function(f, w, C, N) {
						return (f /= N / 2) < 1 ? C / 2 * f * f * f * f + w : -C / 2 * ((f -= 2) * f * f * f - 2) + w
					}],
					"ease-in-quint": ["cubic-bezier(0.755, 0.050, 0.855, 0.060)", function(f, w, C, N) {
						return C * (f /= N) * f * f * f * f + w
					}],
					"ease-out-quint": ["cubic-bezier(0.230, 1, 0.320, 1)", function(f, w, C, N) {
						return C * ((f = f / N - 1) * f * f * f * f + 1) + w
					}],
					"ease-in-out-quint": ["cubic-bezier(0.860, 0, 0.070, 1)", function(f, w, C, N) {
						return (f /= N / 2) < 1 ? C / 2 * f * f * f * f * f + w : C / 2 * ((f -= 2) * f * f * f * f + 2) + w
					}],
					"ease-in-sine": ["cubic-bezier(0.470, 0, 0.745, 0.715)", function(f, w, C, N) {
						return -C * Math.cos(f / N * (Math.PI / 2)) + C + w
					}],
					"ease-out-sine": ["cubic-bezier(0.390, 0.575, 0.565, 1)", function(f, w, C, N) {
						return C * Math.sin(f / N * (Math.PI / 2)) + w
					}],
					"ease-in-out-sine": ["cubic-bezier(0.445, 0.050, 0.550, 0.950)", function(f, w, C, N) {
						return -C / 2 * (Math.cos(Math.PI * f / N) - 1) + w
					}],
					"ease-in-expo": ["cubic-bezier(0.950, 0.050, 0.795, 0.035)", function(f, w, C, N) {
						return f === 0 ? w : C * Math.pow(2, 10 * (f / N - 1)) + w
					}],
					"ease-out-expo": ["cubic-bezier(0.190, 1, 0.220, 1)", function(f, w, C, N) {
						return f === N ? w + C : C * (-Math.pow(2, -10 * f / N) + 1) + w
					}],
					"ease-in-out-expo": ["cubic-bezier(1, 0, 0, 1)", function(f, w, C, N) {
						return f === 0 ? w : f === N ? w + C : (f /= N / 2) < 1 ? C / 2 * Math.pow(2, 10 * (f - 1)) + w : C / 2 * (-Math.pow(2, -10 * --f) + 2) + w
					}],
					"ease-in-circ": ["cubic-bezier(0.600, 0.040, 0.980, 0.335)", function(f, w, C, N) {
						return -C * (Math.sqrt(1 - (f /= N) * f) - 1) + w
					}],
					"ease-out-circ": ["cubic-bezier(0.075, 0.820, 0.165, 1)", function(f, w, C, N) {
						return C * Math.sqrt(1 - (f = f / N - 1) * f) + w
					}],
					"ease-in-out-circ": ["cubic-bezier(0.785, 0.135, 0.150, 0.860)", function(f, w, C, N) {
						return (f /= N / 2) < 1 ? -C / 2 * (Math.sqrt(1 - f * f) - 1) + w : C / 2 * (Math.sqrt(1 - (f -= 2) * f) + 1) + w
					}],
					"ease-in-back": ["cubic-bezier(0.600, -0.280, 0.735, 0.045)", function(f, w, C, N, k) {
						return k === void 0 && (k = 1.70158), C * (f /= N) * f * ((k + 1) * f - k) + w
					}],
					"ease-out-back": ["cubic-bezier(0.175, 0.885, 0.320, 1.275)", function(f, w, C, N, k) {
						return k === void 0 && (k = 1.70158), C * ((f = f / N - 1) * f * ((k + 1) * f + k) + 1) + w
					}],
					"ease-in-out-back": ["cubic-bezier(0.680, -0.550, 0.265, 1.550)", function(f, w, C, N, k) {
						return k === void 0 && (k = 1.70158), (f /= N / 2) < 1 ? C / 2 * f * f * (((k *= 1.525) + 1) * f - k) + w : C / 2 * ((f -= 2) * f * (((k *= 1.525) + 1) * f + k) + 2) + w
					}]
				},
				v = {
					"ease-in-back": "cubic-bezier(0.600, 0, 0.735, 0.045)",
					"ease-out-back": "cubic-bezier(0.175, 0.885, 0.320, 1)",
					"ease-in-out-back": "cubic-bezier(0.680, 0, 0.265, 1)"
				},
				E = document,
				b = window,
				x = "bkwld-tram",
				T = /[\-\.0-9]/g,
				L = /[A-Z]/,
				P = "number",
				D = /^(rgb|#)/,
				F = /(em|cm|mm|in|pt|pc|px)$/,
				M = /(em|cm|mm|in|pt|pc|px|%)$/,
				Y = /(deg|rad|turn)$/,
				K = "unitless",
				Q = /(all|none) 0s ease 0s/,
				ee = /^(width|height)$/,
				ne = " ",
				V = E.createElement("a"),
				S = ["Webkit", "Moz", "O", "ms"],
				q = ["-webkit-", "-moz-", "-o-", "-ms-"],
				z = function(f) {
					if (f in V.style) return {
						dom: f,
						css: f
					};
					var w, C, N = "",
						k = f.split("-");
					for (w = 0; w < k.length; w++) N += k[w].charAt(0).toUpperCase() + k[w].slice(1);
					for (w = 0; w < S.length; w++)
						if (C = S[w] + N, C in V.style) return {
							dom: C,
							css: q[w] + f
						}
				},
				W = t.support = {
					bind: Function.prototype.bind,
					transform: z("transform"),
					transition: z("transition"),
					backface: z("backface-visibility"),
					timing: z("transition-timing-function")
				};
			if (W.transition) {
				var te = W.timing.dom;
				if (V.style[te] = m["ease-in-back"][0], !V.style[te])
					for (var re in v) m[re][0] = v[re]
			}
			var ce = t.frame = function() {
					var f = b.requestAnimationFrame || b.webkitRequestAnimationFrame || b.mozRequestAnimationFrame || b.oRequestAnimationFrame || b.msRequestAnimationFrame;
					return f && W.bind ? f.bind(b) : function(w) {
						b.setTimeout(w, 16)
					}
				}(),
				fe = t.now = function() {
					var f = b.performance,
						w = f && (f.now || f.webkitNow || f.msNow || f.mozNow);
					return w && W.bind ? w.bind(f) : Date.now || function() {
						return +new Date
					}
				}(),
				I = d(function(f) {
					function w(ae, pe) {
						var Ee = _(("" + ae).split(ne)),
							he = Ee[0];
						pe = pe || {};
						var Ce = j[he];
						if (!Ce) return l("Unsupported property: " + he);
						if (!pe.weak || !this.props[he]) {
							var We = Ce[0],
								Me = this.props[he];
							return Me || (Me = this.props[he] = new We.Bare), Me.init(this.$el, Ee, Ce, pe), Me
						}
					}

					function C(ae, pe, Ee) {
						if (ae) {
							var he = typeof ae;
							if (pe || (this.timer && this.timer.destroy(), this.queue = [], this.active = !1), he == "number" && pe) return this.timer = new U({
								duration: ae,
								context: this,
								complete: G
							}), void(this.active = !0);
							if (he == "string" && pe) {
								switch (ae) {
									case "hide":
										B.call(this);
										break;
									case "stop":
										ie.call(this);
										break;
									case "redraw":
										ue.call(this);
										break;
									default:
										w.call(this, ae, Ee && Ee[1])
								}
								return G.call(this)
							}
							if (he == "function") return void ae.call(this, this);
							if (he == "object") {
								var Ce = 0;
								Ve.call(this, ae, function(Te, im) {
									Te.span > Ce && (Ce = Te.span), Te.stop(), Te.animate(im)
								}, function(Te) {
									"wait" in Te && (Ce = u(Te.wait, 0))
								}), Ie.call(this), Ce > 0 && (this.timer = new U({
									duration: Ce,
									context: this
								}), this.active = !0, pe && (this.timer.complete = G));
								var We = this,
									Me = !1,
									Fn = {};
								ce(function() {
									Ve.call(We, ae, function(Te) {
										Te.active && (Me = !0, Fn[Te.name] = Te.nextStyle)
									}), Me && We.$el.css(Fn)
								})
							}
						}
					}

					function N(ae) {
						ae = u(ae, 0), this.active ? this.queue.push({
							options: ae
						}) : (this.timer = new U({
							duration: ae,
							context: this,
							complete: G
						}), this.active = !0)
					}

					function k(ae) {
						return this.active ? (this.queue.push({
							options: ae,
							args: arguments
						}), void(this.timer.complete = G)) : l("No active transition timer. Use start() or wait() before then().")
					}

					function G() {
						if (this.timer && this.timer.destroy(), this.active = !1, this.queue.length) {
							var ae = this.queue.shift();
							C.call(this, ae.options, !0, ae.args)
						}
					}

					function ie(ae) {
						this.timer && this.timer.destroy(), this.queue = [], this.active = !1;
						var pe;
						typeof ae == "string" ? (pe = {}, pe[ae] = 1) : pe = typeof ae == "object" && ae != null ? ae : this.props, Ve.call(this, pe, Re), Ie.call(this)
					}

					function se(ae) {
						ie.call(this, ae), Ve.call(this, ae, rn, nm)
					}

					function oe(ae) {
						typeof ae != "string" && (ae = "block"), this.el.style.display = ae
					}

					function B() {
						ie.call(this), this.el.style.display = "none"
					}

					function ue() {
						this.el.offsetHeight
					}

					function le() {
						ie.call(this), e.removeData(this.el, x), this.$el = this.el = null
					}

					function Ie() {
						var ae, pe, Ee = [];
						this.upstream && Ee.push(this.upstream);
						for (ae in this.props) pe = this.props[ae], pe.active && Ee.push(pe.string);
						Ee = Ee.join(","), this.style !== Ee && (this.style = Ee, this.el.style[W.transition.dom] = Ee)
					}

					function Ve(ae, pe, Ee) {
						var he, Ce, We, Me, Fn = pe !== Re,
							Te = {};
						for (he in ae) We = ae[he], he in de ? (Te.transform || (Te.transform = {}), Te.transform[he] = We) : (L.test(he) && (he = n(he)), he in j ? Te[he] = We : (Me || (Me = {}), Me[he] = We));
						for (he in Te) {
							if (We = Te[he], Ce = this.props[he], !Ce) {
								if (!Fn) continue;
								Ce = w.call(this, he)
							}
							pe.call(this, Ce, We)
						}
						Ee && Me && Ee.call(this, Me)
					}

					function Re(ae) {
						ae.stop()
					}

					function rn(ae, pe) {
						ae.set(pe)
					}

					function nm(ae) {
						this.$el.css(ae)
					}

					function Ue(ae, pe) {
						f[ae] = function() {
							return this.children ? rm.call(this, pe, arguments) : (this.el && pe.apply(this, arguments), this)
						}
					}

					function rm(ae, pe) {
						var Ee, he = this.children.length;
						for (Ee = 0; he > Ee; Ee++) ae.apply(this.children[Ee], pe);
						return this
					}
					f.init = function(ae) {
						if (this.$el = e(ae), this.el = this.$el[0], this.props = {}, this.queue = [], this.style = "", this.active = !1, H.keepInherited && !H.fallback) {
							var pe = X(this.el, "transition");
							pe && !Q.test(pe) && (this.upstream = pe)
						}
						W.backface && H.hideBackface && h(this.el, W.backface.css, "hidden")
					}, Ue("add", w), Ue("start", C), Ue("wait", N), Ue("then", k), Ue("next", G), Ue("stop", ie), Ue("set", se), Ue("show", oe), Ue("hide", B), Ue("redraw", ue), Ue("destroy", le)
				}),
				y = d(I, function(f) {
					function w(C, N) {
						var k = e.data(C, x) || e.data(C, x, new I.Bare);
						return k.el || k.init(C), N ? k.start(N) : k
					}
					f.init = function(C, N) {
						var k = e(C);
						if (!k.length) return this;
						if (k.length === 1) return w(k[0], N);
						var G = [];
						return k.each(function(ie, se) {
							G.push(w(se, N))
						}), this.children = G, this
					}
				}),
				p = d(function(f) {
					function w() {
						var G = this.get();
						this.update("auto");
						var ie = this.get();
						return this.update(G), ie
					}

					function C(G, ie, se) {
						return ie !== void 0 && (se = ie), G in m ? G : se
					}

					function N(G) {
						var ie = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(G);
						return (ie ? i(ie[1], ie[2], ie[3]) : G).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3")
					}
					var k = {
						duration: 500,
						ease: "ease",
						delay: 0
					};
					f.init = function(G, ie, se, oe) {
						this.$el = G, this.el = G[0];
						var B = ie[0];
						se[2] && (B = se[2]), Z[B] && (B = Z[B]), this.name = B, this.type = se[1], this.duration = u(ie[1], this.duration, k.duration), this.ease = C(ie[2], this.ease, k.ease), this.delay = u(ie[3], this.delay, k.delay), this.span = this.duration + this.delay, this.active = !1, this.nextStyle = null, this.auto = ee.test(this.name), this.unit = oe.unit || this.unit || H.defaultUnit, this.angle = oe.angle || this.angle || H.defaultAngle, H.fallback || oe.fallback ? this.animate = this.fallback : (this.animate = this.transition, this.string = this.name + ne + this.duration + "ms" + (this.ease != "ease" ? ne + m[this.ease][0] : "") + (this.delay ? ne + this.delay + "ms" : ""))
					}, f.set = function(G) {
						G = this.convert(G, this.type), this.update(G), this.redraw()
					}, f.transition = function(G) {
						this.active = !0, G = this.convert(G, this.type), this.auto && (this.el.style[this.name] == "auto" && (this.update(this.get()), this.redraw()), G == "auto" && (G = w.call(this))), this.nextStyle = G
					}, f.fallback = function(G) {
						var ie = this.el.style[this.name] || this.convert(this.get(), this.type);
						G = this.convert(G, this.type), this.auto && (ie == "auto" && (ie = this.convert(this.get(), this.type)), G == "auto" && (G = w.call(this))), this.tween = new R({
							from: ie,
							to: G,
							duration: this.duration,
							delay: this.delay,
							ease: this.ease,
							update: this.update,
							context: this
						})
					}, f.get = function() {
						return X(this.el, this.name)
					}, f.update = function(G) {
						h(this.el, this.name, G)
					}, f.stop = function() {
						(this.active || this.nextStyle) && (this.active = !1, this.nextStyle = null, h(this.el, this.name, this.get()));
						var G = this.tween;
						G && G.context && G.destroy()
					}, f.convert = function(G, ie) {
						if (G == "auto" && this.auto) return G;
						var se, oe = typeof G == "number",
							B = typeof G == "string";
						switch (ie) {
							case P:
								if (oe) return G;
								if (B && G.replace(T, "") === "") return +G;
								se = "number(unitless)";
								break;
							case D:
								if (B) {
									if (G === "" && this.original) return this.original;
									if (ie.test(G)) return G.charAt(0) == "#" && G.length == 7 ? G : N(G)
								}
								se = "hex or rgb string";
								break;
							case F:
								if (oe) return G + this.unit;
								if (B && ie.test(G)) return G;
								se = "number(px) or string(unit)";
								break;
							case M:
								if (oe) return G + this.unit;
								if (B && ie.test(G)) return G;
								se = "number(px) or string(unit or %)";
								break;
							case Y:
								if (oe) return G + this.angle;
								if (B && ie.test(G)) return G;
								se = "number(deg) or string(angle)";
								break;
							case K:
								if (oe || B && M.test(G)) return G;
								se = "number(unitless) or string(unit or %)"
						}
						return s(se, G), G
					}, f.redraw = function() {
						this.el.offsetHeight
					}
				}),
				c = d(p, function(f, w) {
					f.init = function() {
						w.init.apply(this, arguments), this.original || (this.original = this.convert(this.get(), D))
					}
				}),
				A = d(p, function(f, w) {
					f.init = function() {
						w.init.apply(this, arguments), this.animate = this.fallback
					}, f.get = function() {
						return this.$el[this.name]()
					}, f.update = function(C) {
						this.$el[this.name](C)
					}
				}),
				O = d(p, function(f, w) {
					function C(N, k) {
						var G, ie, se, oe, B;
						for (G in N) oe = de[G], se = oe[0], ie = oe[1] || G, B = this.convert(N[G], se), k.call(this, ie, B, se)
					}
					f.init = function() {
						w.init.apply(this, arguments), this.current || (this.current = {}, de.perspective && H.perspective && (this.current.perspective = H.perspective, h(this.el, this.name, this.style(this.current)), this.redraw()))
					}, f.set = function(N) {
						C.call(this, N, function(k, G) {
							this.current[k] = G
						}), h(this.el, this.name, this.style(this.current)), this.redraw()
					}, f.transition = function(N) {
						var k = this.values(N);
						this.tween = new J({
							current: this.current,
							values: k,
							duration: this.duration,
							delay: this.delay,
							ease: this.ease
						});
						var G, ie = {};
						for (G in this.current) ie[G] = G in k ? k[G] : this.current[G];
						this.active = !0, this.nextStyle = this.style(ie)
					}, f.fallback = function(N) {
						var k = this.values(N);
						this.tween = new J({
							current: this.current,
							values: k,
							duration: this.duration,
							delay: this.delay,
							ease: this.ease,
							update: this.update,
							context: this
						})
					}, f.update = function() {
						h(this.el, this.name, this.style(this.current))
					}, f.style = function(N) {
						var k, G = "";
						for (k in N) G += k + "(" + N[k] + ") ";
						return G
					}, f.values = function(N) {
						var k, G = {};
						return C.call(this, N, function(ie, se, oe) {
							G[ie] = se, this.current[ie] === void 0 && (k = 0, ~ie.indexOf("scale") && (k = 1), this.current[ie] = this.convert(k, oe))
						}), G
					}
				}),
				R = d(function(f) {
					function w(B) {
						se.push(B) === 1 && ce(C)
					}

					function C() {
						var B, ue, le, Ie = se.length;
						if (Ie)
							for (ce(C), ue = fe(), B = Ie; B--;) le = se[B], le && le.render(ue)
					}

					function N(B) {
						var ue, le = e.inArray(B, se);
						le >= 0 && (ue = se.slice(le + 1), se.length = le, ue.length && (se = se.concat(ue)))
					}

					function k(B) {
						return Math.round(B * oe) / oe
					}

					function G(B, ue, le) {
						return i(B[0] + le * (ue[0] - B[0]), B[1] + le * (ue[1] - B[1]), B[2] + le * (ue[2] - B[2]))
					}
					var ie = {
						ease: m.ease[1],
						from: 0,
						to: 1
					};
					f.init = function(B) {
						this.duration = B.duration || 0, this.delay = B.delay || 0;
						var ue = B.ease || ie.ease;
						m[ue] && (ue = m[ue][1]), typeof ue != "function" && (ue = ie.ease), this.ease = ue, this.update = B.update || o, this.complete = B.complete || o, this.context = B.context || this, this.name = B.name;
						var le = B.from,
							Ie = B.to;
						le === void 0 && (le = ie.from), Ie === void 0 && (Ie = ie.to), this.unit = B.unit || "", typeof le == "number" && typeof Ie == "number" ? (this.begin = le, this.change = Ie - le) : this.format(Ie, le), this.value = this.begin + this.unit, this.start = fe(), B.autoplay !== !1 && this.play()
					}, f.play = function() {
						this.active || (this.start || (this.start = fe()), this.active = !0, w(this))
					}, f.stop = function() {
						this.active && (this.active = !1, N(this))
					}, f.render = function(B) {
						var ue, le = B - this.start;
						if (this.delay) {
							if (le <= this.delay) return;
							le -= this.delay
						}
						if (le < this.duration) {
							var Ie = this.ease(le, 0, 1, this.duration);
							return ue = this.startRGB ? G(this.startRGB, this.endRGB, Ie) : k(this.begin + Ie * this.change), this.value = ue + this.unit, void this.update.call(this.context, this.value)
						}
						ue = this.endHex || this.begin + this.change, this.value = ue + this.unit, this.update.call(this.context, this.value), this.complete.call(this.context), this.destroy()
					}, f.format = function(B, ue) {
						if (ue += "", B += "", B.charAt(0) == "#") return this.startRGB = r(ue), this.endRGB = r(B), this.endHex = B, this.begin = 0, void(this.change = 1);
						if (!this.unit) {
							var le = ue.replace(T, ""),
								Ie = B.replace(T, "");
							le !== Ie && a("tween", ue, B), this.unit = le
						}
						ue = parseFloat(ue), B = parseFloat(B), this.begin = this.value = ue, this.change = B - ue
					}, f.destroy = function() {
						this.stop(), this.context = null, this.ease = this.update = this.complete = o
					};
					var se = [],
						oe = 1e3
				}),
				U = d(R, function(f) {
					f.init = function(w) {
						this.duration = w.duration || 0, this.complete = w.complete || o, this.context = w.context, this.play()
					}, f.render = function(w) {
						var C = w - this.start;
						C < this.duration || (this.complete.call(this.context), this.destroy())
					}
				}),
				J = d(R, function(f, w) {
					f.init = function(C) {
						this.context = C.context, this.update = C.update, this.tweens = [], this.current = C.current;
						var N, k;
						for (N in C.values) k = C.values[N], this.current[N] !== k && this.tweens.push(new R({
							name: N,
							from: this.current[N],
							to: k,
							duration: C.duration,
							delay: C.delay,
							ease: C.ease,
							autoplay: !1
						}));
						this.play()
					}, f.render = function(C) {
						var N, k, G = this.tweens.length,
							ie = !1;
						for (N = G; N--;) k = this.tweens[N], k.context && (k.render(C), this.current[k.name] = k.value, ie = !0);
						return ie ? void(this.update && this.update.call(this.context)) : this.destroy()
					}, f.destroy = function() {
						if (w.destroy.call(this), this.tweens) {
							var C, N = this.tweens.length;
							for (C = N; C--;) this.tweens[C].destroy();
							this.tweens = null, this.current = null
						}
					}
				}),
				H = t.config = {
					debug: !1,
					defaultUnit: "px",
					defaultAngle: "deg",
					keepInherited: !1,
					hideBackface: !1,
					perspective: "",
					fallback: !W.transition,
					agentTests: []
				};
			t.fallback = function(f) {
				if (!W.transition) return H.fallback = !0;
				H.agentTests.push("(" + f + ")");
				var w = new RegExp(H.agentTests.join("|"), "i");
				H.fallback = w.test(navigator.userAgent)
			}, t.fallback("6.0.[2-5] Safari"), t.tween = function(f) {
				return new R(f)
			}, t.delay = function(f, w, C) {
				return new U({
					complete: w,
					duration: f,
					context: C
				})
			}, e.fn.tram = function(f) {
				return t.call(null, this, f)
			};
			var h = e.style,
				X = e.css,
				Z = {
					transform: W.transform && W.transform.css
				},
				j = {
					color: [c, D],
					background: [c, D, "background-color"],
					"outline-color": [c, D],
					"border-color": [c, D],
					"border-top-color": [c, D],
					"border-right-color": [c, D],
					"border-bottom-color": [c, D],
					"border-left-color": [c, D],
					"border-width": [p, F],
					"border-top-width": [p, F],
					"border-right-width": [p, F],
					"border-bottom-width": [p, F],
					"border-left-width": [p, F],
					"border-spacing": [p, F],
					"letter-spacing": [p, F],
					margin: [p, F],
					"margin-top": [p, F],
					"margin-right": [p, F],
					"margin-bottom": [p, F],
					"margin-left": [p, F],
					padding: [p, F],
					"padding-top": [p, F],
					"padding-right": [p, F],
					"padding-bottom": [p, F],
					"padding-left": [p, F],
					"outline-width": [p, F],
					opacity: [p, P],
					top: [p, M],
					right: [p, M],
					bottom: [p, M],
					left: [p, M],
					"font-size": [p, M],
					"text-indent": [p, M],
					"word-spacing": [p, M],
					width: [p, M],
					"min-width": [p, M],
					"max-width": [p, M],
					height: [p, M],
					"min-height": [p, M],
					"max-height": [p, M],
					"line-height": [p, K],
					"scroll-top": [A, P, "scrollTop"],
					"scroll-left": [A, P, "scrollLeft"]
				},
				de = {};
			W.transform && (j.transform = [O], de = {
				x: [M, "translateX"],
				y: [M, "translateY"],
				rotate: [Y],
				rotateX: [Y],
				rotateY: [Y],
				scale: [P],
				scaleX: [P],
				scaleY: [P],
				skew: [Y],
				skewX: [Y],
				skewY: [Y]
			}), W.transform && W.backface && (de.z = [M, "translateZ"], de.rotateZ = [Y], de.scaleZ = [P], de.perspective = [F]);
			var be = /ms/,
				xe = /s|\./;
			return e.tram = t
		}(window.jQuery)
	});
	var Ta = g((n1, ba) => {
		"use strict";
		var lm = window.$,
			fm = Zr() && lm.tram;
		ba.exports = function() {
			var e = {};
			e.VERSION = "1.6.0-Webflow";
			var t = {},
				n = Array.prototype,
				r = Object.prototype,
				i = Function.prototype,
				o = n.push,
				s = n.slice,
				a = n.concat,
				u = r.toString,
				l = r.hasOwnProperty,
				_ = n.forEach,
				d = n.map,
				m = n.reduce,
				v = n.reduceRight,
				E = n.filter,
				b = n.every,
				x = n.some,
				T = n.indexOf,
				L = n.lastIndexOf,
				P = Array.isArray,
				D = Object.keys,
				F = i.bind,
				M = e.each = e.forEach = function(S, q, z) {
					if (S == null) return S;
					if (_ && S.forEach === _) S.forEach(q, z);
					else if (S.length === +S.length) {
						for (var W = 0, te = S.length; W < te; W++)
							if (q.call(z, S[W], W, S) === t) return
					} else
						for (var re = e.keys(S), W = 0, te = re.length; W < te; W++)
							if (q.call(z, S[re[W]], re[W], S) === t) return;
					return S
				};
			e.map = e.collect = function(S, q, z) {
				var W = [];
				return S == null ? W : d && S.map === d ? S.map(q, z) : (M(S, function(te, re, ce) {
					W.push(q.call(z, te, re, ce))
				}), W)
			}, e.find = e.detect = function(S, q, z) {
				var W;
				return Y(S, function(te, re, ce) {
					if (q.call(z, te, re, ce)) return W = te, !0
				}), W
			}, e.filter = e.select = function(S, q, z) {
				var W = [];
				return S == null ? W : E && S.filter === E ? S.filter(q, z) : (M(S, function(te, re, ce) {
					q.call(z, te, re, ce) && W.push(te)
				}), W)
			};
			var Y = e.some = e.any = function(S, q, z) {
				q || (q = e.identity);
				var W = !1;
				return S == null ? W : x && S.some === x ? S.some(q, z) : (M(S, function(te, re, ce) {
					if (W || (W = q.call(z, te, re, ce))) return t
				}), !!W)
			};
			e.contains = e.include = function(S, q) {
				return S == null ? !1 : T && S.indexOf === T ? S.indexOf(q) != -1 : Y(S, function(z) {
					return z === q
				})
			}, e.delay = function(S, q) {
				var z = s.call(arguments, 2);
				return setTimeout(function() {
					return S.apply(null, z)
				}, q)
			}, e.defer = function(S) {
				return e.delay.apply(e, [S, 1].concat(s.call(arguments, 1)))
			}, e.throttle = function(S) {
				var q, z, W;
				return function() {
					q || (q = !0, z = arguments, W = this, fm.frame(function() {
						q = !1, S.apply(W, z)
					}))
				}
			}, e.debounce = function(S, q, z) {
				var W, te, re, ce, fe, I = function() {
					var y = e.now() - ce;
					y < q ? W = setTimeout(I, q - y) : (W = null, z || (fe = S.apply(re, te), re = te = null))
				};
				return function() {
					re = this, te = arguments, ce = e.now();
					var y = z && !W;
					return W || (W = setTimeout(I, q)), y && (fe = S.apply(re, te), re = te = null), fe
				}
			}, e.defaults = function(S) {
				if (!e.isObject(S)) return S;
				for (var q = 1, z = arguments.length; q < z; q++) {
					var W = arguments[q];
					for (var te in W) S[te] === void 0 && (S[te] = W[te])
				}
				return S
			}, e.keys = function(S) {
				if (!e.isObject(S)) return [];
				if (D) return D(S);
				var q = [];
				for (var z in S) e.has(S, z) && q.push(z);
				return q
			}, e.has = function(S, q) {
				return l.call(S, q)
			}, e.isObject = function(S) {
				return S === Object(S)
			}, e.now = Date.now || function() {
				return new Date().getTime()
			}, e.templateSettings = {
				evaluate: /<%([\s\S]+?)%>/g,
				interpolate: /<%=([\s\S]+?)%>/g,
				escape: /<%-([\s\S]+?)%>/g
			};
			var K = /(.)^/,
				Q = {
					"'": "'",
					"\\": "\\",
					"\r": "r",
					"\n": "n",
					"\u2028": "u2028",
					"\u2029": "u2029"
				},
				ee = /\\|'|\r|\n|\u2028|\u2029/g,
				ne = function(S) {
					return "\\" + Q[S]
				},
				V = /^\s*(\w|\$)+\s*$/;
			return e.template = function(S, q, z) {
				!q && z && (q = z), q = e.defaults({}, q, e.templateSettings);
				var W = RegExp([(q.escape || K).source, (q.interpolate || K).source, (q.evaluate || K).source].join("|") + "|$", "g"),
					te = 0,
					re = "__p+='";
				S.replace(W, function(y, p, c, A, O) {
					return re += S.slice(te, O).replace(ee, ne), te = O + y.length, p ? re += `'+
((__t=(` + p + `))==null?'':_.escape(__t))+
'` : c ? re += `'+
((__t=(` + c + `))==null?'':__t)+
'` : A && (re += `';
` + A + `
__p+='`), y
				}), re += `';
`;
				var ce = q.variable;
				if (ce) {
					if (!V.test(ce)) throw new Error("variable is not a bare identifier: " + ce)
				} else re = `with(obj||{}){
` + re + `}
`, ce = "obj";
				re = `var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
` + re + `return __p;
`;
				var fe;
				try {
					fe = new Function(q.variable || "obj", "_", re)
				} catch (y) {
					throw y.source = re, y
				}
				var I = function(y) {
					return fe.call(this, y, e)
				};
				return I.source = "function(" + ce + `){
` + re + "}", I
			}, e
		}()
	});
	var Le = g((r1, La) => {
		"use strict";
		var ve = {},
			St = {},
			Rt = [],
			ei = window.Webflow || [],
			ft = window.jQuery,
			Be = ft(window),
			dm = ft(document),
			Ze = ft.isFunction,
			He = ve._ = Ta(),
			xa = ve.tram = Zr() && ft.tram,
			Gn = !1,
			ti = !1;
		xa.config.hideBackface = !1;
		xa.config.keepInherited = !0;
		ve.define = function(e, t, n) {
			St[e] && Oa(St[e]);
			var r = St[e] = t(ft, He, n) || {};
			return Aa(r), r
		};
		ve.require = function(e) {
			return St[e]
		};

		function Aa(e) {
			ve.env() && (Ze(e.design) && Be.on("__wf_design", e.design), Ze(e.preview) && Be.on("__wf_preview", e.preview)), Ze(e.destroy) && Be.on("__wf_destroy", e.destroy), e.ready && Ze(e.ready) && pm(e)
		}

		function pm(e) {
			if (Gn) {
				e.ready();
				return
			}
			He.contains(Rt, e.ready) || Rt.push(e.ready)
		}

		function Oa(e) {
			Ze(e.design) && Be.off("__wf_design", e.design), Ze(e.preview) && Be.off("__wf_preview", e.preview), Ze(e.destroy) && Be.off("__wf_destroy", e.destroy), e.ready && Ze(e.ready) && gm(e)
		}

		function gm(e) {
			Rt = He.filter(Rt, function(t) {
				return t !== e.ready
			})
		}
		ve.push = function(e) {
			if (Gn) {
				Ze(e) && e();
				return
			}
			ei.push(e)
		};
		ve.env = function(e) {
			var t = window.__wf_design,
				n = typeof t < "u";
			if (!e) return n;
			if (e === "design") return n && t;
			if (e === "preview") return n && !t;
			if (e === "slug") return n && window.__wf_slug;
			if (e === "editor") return window.WebflowEditor;
			if (e === "test") return window.__wf_test;
			if (e === "frame") return window !== window.top
		};
		var kn = navigator.userAgent.toLowerCase(),
			Sa = ve.env.touch = "ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch,
			hm = ve.env.chrome = /chrome/.test(kn) && /Google/.test(navigator.vendor) && parseInt(kn.match(/chrome\/(\d+)\./)[1], 10),
			vm = ve.env.ios = /(ipod|iphone|ipad)/.test(kn);
		ve.env.safari = /safari/.test(kn) && !hm && !vm;
		var Jr;
		Sa && dm.on("touchstart mousedown", function(e) {
			Jr = e.target
		});
		ve.validClick = Sa ? function(e) {
			return e === Jr || ft.contains(e, Jr)
		} : function() {
			return !0
		};
		var Ra = "resize.webflow orientationchange.webflow load.webflow",
			mm = "scroll.webflow " + Ra;
		ve.resize = ni(Be, Ra);
		ve.scroll = ni(Be, mm);
		ve.redraw = ni();

		function ni(e, t) {
			var n = [],
				r = {};
			return r.up = He.throttle(function(i) {
				He.each(n, function(o) {
					o(i)
				})
			}), e && t && e.on(t, r.up), r.on = function(i) {
				typeof i == "function" && (He.contains(n, i) || n.push(i))
			}, r.off = function(i) {
				if (!arguments.length) {
					n = [];
					return
				}
				n = He.filter(n, function(o) {
					return o !== i
				})
			}, r
		}
		ve.location = function(e) {
			window.location = e
		};
		ve.env() && (ve.location = function() {});
		ve.ready = function() {
			Gn = !0, ti ? ym() : He.each(Rt, wa), He.each(ei, wa), ve.resize.up()
		};

		function wa(e) {
			Ze(e) && e()
		}

		function ym() {
			ti = !1, He.each(St, Aa)
		}
		var Et;
		ve.load = function(e) {
			Et.then(e)
		};

		function Ca() {
			Et && (Et.reject(), Be.off("load", Et.resolve)), Et = new ft.Deferred, Be.on("load", Et.resolve)
		}
		ve.destroy = function(e) {
			e = e || {}, ti = !0, Be.triggerHandler("__wf_destroy"), e.domready != null && (Gn = e.domready), He.each(St, Oa), ve.resize.off(), ve.scroll.off(), ve.redraw.off(), Rt = [], ei = [], Et.state() === "pending" && Ca()
		};
		ft(ve.ready);
		Ca();
		La.exports = window.Webflow = ve
	});
	var Da = g((i1, Na) => {
		"use strict";
		var Pa = Le();
		Pa.define("brand", Na.exports = function(e) {
			var t = {},
				n = document,
				r = e("html"),
				i = e("body"),
				o = ".w-webflow-badge",
				s = window.location,
				a = /PhantomJS/i.test(navigator.userAgent),
				u = "fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange",
				l;
			t.ready = function() {
				var v = r.attr("data-wf-status"),
					E = r.attr("data-wf-domain") || "";
				/\.webflow\.io$/i.test(E) && s.hostname !== E && (v = !0), v && !a && (l = l || d(), m(), setTimeout(m, 500), e(n).off(u, _).on(u, _))
			};

			function _() {
				var v = n.fullScreen || n.mozFullScreen || n.webkitIsFullScreen || n.msFullscreenElement || !!n.webkitFullscreenElement;
				e(l).attr("style", v ? "display: none !important;" : "")
			}

			function d() {
				var v = e('<a class="w-webflow-badge"></a>').attr("href", "https://webflow.com?utm_campaign=brandjs"),
					E = e("<img>").attr("src", "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-icon-d2.89e12c322e.svg").attr("alt", "").css({
						marginRight: "4px",
						width: "26px"
					}),
					b = e("<img>").attr("src", "https://d3e54v103j8qbb.cloudfront.net/img/webflow-badge-text-d2.c82cec3b78.svg").attr("alt", "Made in Webflow");
				return v.append(E, b), v[0]
			}

			function m() {
				var v = i.children(o),
					E = v.length && v.get(0) === l,
					b = Pa.env("editor");
				if (E) {
					b && v.remove();
					return
				}
				v.length && v.remove(), b || i.append(l)
			}
			return t
		})
	});
	var Fa = g((o1, Ma) => {
		"use strict";
		var ri = Le();
		ri.define("edit", Ma.exports = function(e, t, n) {
			if (n = n || {}, (ri.env("test") || ri.env("frame")) && !n.fixture && !Em()) return {
				exit: 1
			};
			var r = {},
				i = e(window),
				o = e(document.documentElement),
				s = document.location,
				a = "hashchange",
				u, l = n.load || m,
				_ = !1;
			try {
				_ = localStorage && localStorage.getItem && localStorage.getItem("WebflowEditor")
			} catch {}
			_ ? l() : s.search ? (/[?&](edit)(?:[=&?]|$)/.test(s.search) || /\?edit$/.test(s.href)) && l() : i.on(a, d).triggerHandler(a);

			function d() {
				u || /\?edit/.test(s.hash) && l()
			}

			function m() {
				u = !0, window.WebflowEditor = !0, i.off(a, d), L(function(D) {
					e.ajax({
						url: T("https://editor-api.webflow.com/api/editor/view"),
						data: {
							siteId: o.attr("data-wf-site")
						},
						xhrFields: {
							withCredentials: !0
						},
						dataType: "json",
						crossDomain: !0,
						success: v(D)
					})
				})
			}

			function v(D) {
				return function(F) {
					if (!F) {
						console.error("Could not load editor data");
						return
					}
					F.thirdPartyCookiesSupported = D, E(x(F.scriptPath), function() {
						window.WebflowEditor(F)
					})
				}
			}

			function E(D, F) {
				e.ajax({
					type: "GET",
					url: D,
					dataType: "script",
					cache: !0
				}).then(F, b)
			}

			function b(D, F, M) {
				throw console.error("Could not load editor script: " + F), M
			}

			function x(D) {
				return D.indexOf("//") >= 0 ? D : T("https://editor-api.webflow.com" + D)
			}

			function T(D) {
				return D.replace(/([^:])\/\//g, "$1/")
			}

			function L(D) {
				var F = window.document.createElement("iframe");
				F.src = "https://webflow.com/site/third-party-cookie-check.html", F.style.display = "none", F.sandbox = "allow-scripts allow-same-origin";
				var M = function(Y) {
					Y.data === "WF_third_party_cookies_unsupported" ? (P(F, M), D(!1)) : Y.data === "WF_third_party_cookies_supported" && (P(F, M), D(!0))
				};
				F.onerror = function() {
					P(F, M), D(!1)
				}, window.addEventListener("message", M, !1), window.document.body.appendChild(F)
			}

			function P(D, F) {
				window.removeEventListener("message", F, !1), D.remove()
			}
			return r
		});

		function Em() {
			try {
				return window.top.__Cypress__
			} catch {
				return !1
			}
		}
	});
	var ka = g((a1, qa) => {
		"use strict";
		var _m = Le();
		_m.define("focus-visible", qa.exports = function() {
			function e(n) {
				var r = !0,
					i = !1,
					o = null,
					s = {
						text: !0,
						search: !0,
						url: !0,
						tel: !0,
						email: !0,
						password: !0,
						number: !0,
						date: !0,
						month: !0,
						week: !0,
						time: !0,
						datetime: !0,
						"datetime-local": !0
					};

				function a(P) {
					return !!(P && P !== document && P.nodeName !== "HTML" && P.nodeName !== "BODY" && "classList" in P && "contains" in P.classList)
				}

				function u(P) {
					var D = P.type,
						F = P.tagName;
					return !!(F === "INPUT" && s[D] && !P.readOnly || F === "TEXTAREA" && !P.readOnly || P.isContentEditable)
				}

				function l(P) {
					P.getAttribute("data-wf-focus-visible") || P.setAttribute("data-wf-focus-visible", "true")
				}

				function _(P) {
					P.getAttribute("data-wf-focus-visible") && P.removeAttribute("data-wf-focus-visible")
				}

				function d(P) {
					P.metaKey || P.altKey || P.ctrlKey || (a(n.activeElement) && l(n.activeElement), r = !0)
				}

				function m() {
					r = !1
				}

				function v(P) {
					a(P.target) && (r || u(P.target)) && l(P.target)
				}

				function E(P) {
					a(P.target) && P.target.hasAttribute("data-wf-focus-visible") && (i = !0, window.clearTimeout(o), o = window.setTimeout(function() {
						i = !1
					}, 100), _(P.target))
				}

				function b() {
					document.visibilityState === "hidden" && (i && (r = !0), x())
				}

				function x() {
					document.addEventListener("mousemove", L), document.addEventListener("mousedown", L), document.addEventListener("mouseup", L), document.addEventListener("pointermove", L), document.addEventListener("pointerdown", L), document.addEventListener("pointerup", L), document.addEventListener("touchmove", L), document.addEventListener("touchstart", L), document.addEventListener("touchend", L)
				}

				function T() {
					document.removeEventListener("mousemove", L), document.removeEventListener("mousedown", L), document.removeEventListener("mouseup", L), document.removeEventListener("pointermove", L), document.removeEventListener("pointerdown", L), document.removeEventListener("pointerup", L), document.removeEventListener("touchmove", L), document.removeEventListener("touchstart", L), document.removeEventListener("touchend", L)
				}

				function L(P) {
					P.target.nodeName && P.target.nodeName.toLowerCase() === "html" || (r = !1, T())
				}
				document.addEventListener("keydown", d, !0), document.addEventListener("mousedown", m, !0), document.addEventListener("pointerdown", m, !0), document.addEventListener("touchstart", m, !0), document.addEventListener("visibilitychange", b, !0), x(), n.addEventListener("focus", v, !0), n.addEventListener("blur", E, !0)
			}

			function t() {
				if (typeof document < "u") try {
					document.querySelector(":focus-visible")
				} catch {
					e(document)
				}
			}
			return {
				ready: t
			}
		})
	});
	var Xa = g((s1, Va) => {
		"use strict";
		var Ga = Le();
		Ga.define("focus", Va.exports = function() {
			var e = [],
				t = !1;

			function n(s) {
				t && (s.preventDefault(), s.stopPropagation(), s.stopImmediatePropagation(), e.unshift(s))
			}

			function r(s) {
				var a = s.target,
					u = a.tagName;
				return /^a$/i.test(u) && a.href != null || /^(button|textarea)$/i.test(u) && a.disabled !== !0 || /^input$/i.test(u) && /^(button|reset|submit|radio|checkbox)$/i.test(a.type) && !a.disabled || !/^(button|input|textarea|select|a)$/i.test(u) && !Number.isNaN(Number.parseFloat(a.tabIndex)) || /^audio$/i.test(u) || /^video$/i.test(u) && a.controls === !0
			}

			function i(s) {
				r(s) && (t = !0, setTimeout(() => {
					for (t = !1, s.target.focus(); e.length > 0;) {
						var a = e.pop();
						a.target.dispatchEvent(new MouseEvent(a.type, a))
					}
				}, 0))
			}

			function o() {
				typeof document < "u" && document.body.hasAttribute("data-wf-focus-within") && Ga.env.safari && (document.addEventListener("mousedown", i, !0), document.addEventListener("mouseup", n, !0), document.addEventListener("click", n, !0))
			}
			return {
				ready: o
			}
		})
	});
	var Ha = g((u1, Wa) => {
		"use strict";
		var ii = window.jQuery,
			Je = {},
			Vn = [],
			Ua = ".w-ix",
			Xn = {
				reset: function(e, t) {
					t.__wf_intro = null
				},
				intro: function(e, t) {
					t.__wf_intro || (t.__wf_intro = !0, ii(t).triggerHandler(Je.types.INTRO))
				},
				outro: function(e, t) {
					t.__wf_intro && (t.__wf_intro = null, ii(t).triggerHandler(Je.types.OUTRO))
				}
			};
		Je.triggers = {};
		Je.types = {
			INTRO: "w-ix-intro" + Ua,
			OUTRO: "w-ix-outro" + Ua
		};
		Je.init = function() {
			for (var e = Vn.length, t = 0; t < e; t++) {
				var n = Vn[t];
				n[0](0, n[1])
			}
			Vn = [], ii.extend(Je.triggers, Xn)
		};
		Je.async = function() {
			for (var e in Xn) {
				var t = Xn[e];
				Xn.hasOwnProperty(e) && (Je.triggers[e] = function(n, r) {
					Vn.push([t, r])
				})
			}
		};
		Je.async();
		Wa.exports = Je
	});
	var on = g((c1, ja) => {
		"use strict";
		var oi = Ha();

		function Ba(e, t) {
			var n = document.createEvent("CustomEvent");
			n.initCustomEvent(t, !0, !0, null), e.dispatchEvent(n)
		}
		var Im = window.jQuery,
			Un = {},
			za = ".w-ix",
			bm = {
				reset: function(e, t) {
					oi.triggers.reset(e, t)
				},
				intro: function(e, t) {
					oi.triggers.intro(e, t), Ba(t, "COMPONENT_ACTIVE")
				},
				outro: function(e, t) {
					oi.triggers.outro(e, t), Ba(t, "COMPONENT_INACTIVE")
				}
			};
		Un.triggers = {};
		Un.types = {
			INTRO: "w-ix-intro" + za,
			OUTRO: "w-ix-outro" + za
		};
		Im.extend(Un.triggers, bm);
		ja.exports = Un
	});
	var ai = g((l1, Ka) => {
		var Tm = typeof global == "object" && global && global.Object === Object && global;
		Ka.exports = Tm
	});
	var ze = g((f1, Ya) => {
		var wm = ai(),
			xm = typeof self == "object" && self && self.Object === Object && self,
			Am = wm || xm || Function("return this")();
		Ya.exports = Am
	});
	var Ct = g((d1, Qa) => {
		var Om = ze(),
			Sm = Om.Symbol;
		Qa.exports = Sm
	});
	var es = g((p1, Ja) => {
		var $a = Ct(),
			Za = Object.prototype,
			Rm = Za.hasOwnProperty,
			Cm = Za.toString,
			an = $a ? $a.toStringTag : void 0;

		function Lm(e) {
			var t = Rm.call(e, an),
				n = e[an];
			try {
				e[an] = void 0;
				var r = !0
			} catch {}
			var i = Cm.call(e);
			return r && (t ? e[an] = n : delete e[an]), i
		}
		Ja.exports = Lm
	});
	var ns = g((g1, ts) => {
		var Pm = Object.prototype,
			Nm = Pm.toString;

		function Dm(e) {
			return Nm.call(e)
		}
		ts.exports = Dm
	});
	var dt = g((h1, os) => {
		var rs = Ct(),
			Mm = es(),
			Fm = ns(),
			qm = "[object Null]",
			km = "[object Undefined]",
			is = rs ? rs.toStringTag : void 0;

		function Gm(e) {
			return e == null ? e === void 0 ? km : qm : is && is in Object(e) ? Mm(e) : Fm(e)
		}
		os.exports = Gm
	});
	var si = g((v1, as) => {
		function Vm(e, t) {
			return function(n) {
				return e(t(n))
			}
		}
		as.exports = Vm
	});
	var ui = g((m1, ss) => {
		var Xm = si(),
			Um = Xm(Object.getPrototypeOf, Object);
		ss.exports = Um
	});
	var at = g((y1, us) => {
		function Wm(e) {
			return e != null && typeof e == "object"
		}
		us.exports = Wm
	});
	var ci = g((E1, ls) => {
		var Hm = dt(),
			Bm = ui(),
			zm = at(),
			jm = "[object Object]",
			Km = Function.prototype,
			Ym = Object.prototype,
			cs = Km.toString,
			Qm = Ym.hasOwnProperty,
			$m = cs.call(Object);

		function Zm(e) {
			if (!zm(e) || Hm(e) != jm) return !1;
			var t = Bm(e);
			if (t === null) return !0;
			var n = Qm.call(t, "constructor") && t.constructor;
			return typeof n == "function" && n instanceof n && cs.call(n) == $m
		}
		ls.exports = Zm
	});
	var fs = g(li => {
		"use strict";
		Object.defineProperty(li, "__esModule", {
			value: !0
		});
		li.default = Jm;

		function Jm(e) {
			var t, n = e.Symbol;
			return typeof n == "function" ? n.observable ? t = n.observable : (t = n("observable"), n.observable = t) : t = "@@observable", t
		}
	});
	var ds = g((di, fi) => {
		"use strict";
		Object.defineProperty(di, "__esModule", {
			value: !0
		});
		var ey = fs(),
			ty = ny(ey);

		function ny(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}
		var Lt;
		typeof self < "u" ? Lt = self : typeof window < "u" ? Lt = window : typeof global < "u" ? Lt = global : typeof fi < "u" ? Lt = fi : Lt = Function("return this")();
		var ry = (0, ty.default)(Lt);
		di.default = ry
	});
	var pi = g(sn => {
		"use strict";
		sn.__esModule = !0;
		sn.ActionTypes = void 0;
		sn.default = vs;
		var iy = ci(),
			oy = hs(iy),
			ay = ds(),
			ps = hs(ay);

		function hs(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}
		var gs = sn.ActionTypes = {
			INIT: "@@redux/INIT"
		};

		function vs(e, t, n) {
			var r;
			if (typeof t == "function" && typeof n > "u" && (n = t, t = void 0), typeof n < "u") {
				if (typeof n != "function") throw new Error("Expected the enhancer to be a function.");
				return n(vs)(e, t)
			}
			if (typeof e != "function") throw new Error("Expected the reducer to be a function.");
			var i = e,
				o = t,
				s = [],
				a = s,
				u = !1;

			function l() {
				a === s && (a = s.slice())
			}

			function _() {
				return o
			}

			function d(b) {
				if (typeof b != "function") throw new Error("Expected listener to be a function.");
				var x = !0;
				return l(), a.push(b),
					function() {
						if (x) {
							x = !1, l();
							var L = a.indexOf(b);
							a.splice(L, 1)
						}
					}
			}

			function m(b) {
				if (!(0, oy.default)(b)) throw new Error("Actions must be plain objects. Use custom middleware for async actions.");
				if (typeof b.type > "u") throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');
				if (u) throw new Error("Reducers may not dispatch actions.");
				try {
					u = !0, o = i(o, b)
				} finally {
					u = !1
				}
				for (var x = s = a, T = 0; T < x.length; T++) x[T]();
				return b
			}

			function v(b) {
				if (typeof b != "function") throw new Error("Expected the nextReducer to be a function.");
				i = b, m({
					type: gs.INIT
				})
			}

			function E() {
				var b, x = d;
				return b = {
					subscribe: function(L) {
						if (typeof L != "object") throw new TypeError("Expected the observer to be an object.");

						function P() {
							L.next && L.next(_())
						}
						P();
						var D = x(P);
						return {
							unsubscribe: D
						}
					}
				}, b[ps.default] = function() {
					return this
				}, b
			}
			return m({
				type: gs.INIT
			}), r = {
				dispatch: m,
				subscribe: d,
				getState: _,
				replaceReducer: v
			}, r[ps.default] = E, r
		}
	});
	var hi = g(gi => {
		"use strict";
		gi.__esModule = !0;
		gi.default = sy;

		function sy(e) {
			typeof console < "u" && typeof console.error == "function" && console.error(e);
			try {
				throw new Error(e)
			} catch {}
		}
	});
	var Es = g(vi => {
		"use strict";
		vi.__esModule = !0;
		vi.default = dy;
		var ms = pi(),
			uy = ci(),
			T1 = ys(uy),
			cy = hi(),
			w1 = ys(cy);

		function ys(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}

		function ly(e, t) {
			var n = t && t.type,
				r = n && '"' + n.toString() + '"' || "an action";
			return "Given action " + r + ', reducer "' + e + '" returned undefined. To ignore an action, you must explicitly return the previous state.'
		}

		function fy(e) {
			Object.keys(e).forEach(function(t) {
				var n = e[t],
					r = n(void 0, {
						type: ms.ActionTypes.INIT
					});
				if (typeof r > "u") throw new Error('Reducer "' + t + '" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined.');
				var i = "@@redux/PROBE_UNKNOWN_ACTION_" + Math.random().toString(36).substring(7).split("").join(".");
				if (typeof n(void 0, {
						type: i
					}) > "u") throw new Error('Reducer "' + t + '" returned undefined when probed with a random type. ' + ("Don't try to handle " + ms.ActionTypes.INIT + ' or other actions in "redux/*" ') + "namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined.")
			})
		}

		function dy(e) {
			for (var t = Object.keys(e), n = {}, r = 0; r < t.length; r++) {
				var i = t[r];
				typeof e[i] == "function" && (n[i] = e[i])
			}
			var o = Object.keys(n);
			if (!1) var s;
			var a;
			try {
				fy(n)
			} catch (u) {
				a = u
			}
			return function() {
				var l = arguments.length <= 0 || arguments[0] === void 0 ? {} : arguments[0],
					_ = arguments[1];
				if (a) throw a;
				if (!1) var d;
				for (var m = !1, v = {}, E = 0; E < o.length; E++) {
					var b = o[E],
						x = n[b],
						T = l[b],
						L = x(T, _);
					if (typeof L > "u") {
						var P = ly(b, _);
						throw new Error(P)
					}
					v[b] = L, m = m || L !== T
				}
				return m ? v : l
			}
		}
	});
	var Is = g(mi => {
		"use strict";
		mi.__esModule = !0;
		mi.default = py;

		function _s(e, t) {
			return function() {
				return t(e.apply(void 0, arguments))
			}
		}

		function py(e, t) {
			if (typeof e == "function") return _s(e, t);
			if (typeof e != "object" || e === null) throw new Error("bindActionCreators expected an object or a function, instead received " + (e === null ? "null" : typeof e) + '. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');
			for (var n = Object.keys(e), r = {}, i = 0; i < n.length; i++) {
				var o = n[i],
					s = e[o];
				typeof s == "function" && (r[o] = _s(s, t))
			}
			return r
		}
	});
	var Ei = g(yi => {
		"use strict";
		yi.__esModule = !0;
		yi.default = gy;

		function gy() {
			for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
			if (t.length === 0) return function(o) {
				return o
			};
			if (t.length === 1) return t[0];
			var r = t[t.length - 1],
				i = t.slice(0, -1);
			return function() {
				return i.reduceRight(function(o, s) {
					return s(o)
				}, r.apply(void 0, arguments))
			}
		}
	});
	var bs = g(_i => {
		"use strict";
		_i.__esModule = !0;
		var hy = Object.assign || function(e) {
			for (var t = 1; t < arguments.length; t++) {
				var n = arguments[t];
				for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
			}
			return e
		};
		_i.default = Ey;
		var vy = Ei(),
			my = yy(vy);

		function yy(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}

		function Ey() {
			for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
			return function(r) {
				return function(i, o, s) {
					var a = r(i, o, s),
						u = a.dispatch,
						l = [],
						_ = {
							getState: a.getState,
							dispatch: function(m) {
								return u(m)
							}
						};
					return l = t.map(function(d) {
						return d(_)
					}), u = my.default.apply(void 0, l)(a.dispatch), hy({}, a, {
						dispatch: u
					})
				}
			}
		}
	});
	var Ii = g(Xe => {
		"use strict";
		Xe.__esModule = !0;
		Xe.compose = Xe.applyMiddleware = Xe.bindActionCreators = Xe.combineReducers = Xe.createStore = void 0;
		var _y = pi(),
			Iy = Pt(_y),
			by = Es(),
			Ty = Pt(by),
			wy = Is(),
			xy = Pt(wy),
			Ay = bs(),
			Oy = Pt(Ay),
			Sy = Ei(),
			Ry = Pt(Sy),
			Cy = hi(),
			R1 = Pt(Cy);

		function Pt(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}
		Xe.createStore = Iy.default;
		Xe.combineReducers = Ty.default;
		Xe.bindActionCreators = xy.default;
		Xe.applyMiddleware = Oy.default;
		Xe.compose = Ry.default
	});
	var je, bi, et, Ly, Py, Wn, Ny, Ti = ye(() => {
		"use strict";
		je = {
			NAVBAR_OPEN: "NAVBAR_OPEN",
			NAVBAR_CLOSE: "NAVBAR_CLOSE",
			TAB_ACTIVE: "TAB_ACTIVE",
			TAB_INACTIVE: "TAB_INACTIVE",
			SLIDER_ACTIVE: "SLIDER_ACTIVE",
			SLIDER_INACTIVE: "SLIDER_INACTIVE",
			DROPDOWN_OPEN: "DROPDOWN_OPEN",
			DROPDOWN_CLOSE: "DROPDOWN_CLOSE",
			MOUSE_CLICK: "MOUSE_CLICK",
			MOUSE_SECOND_CLICK: "MOUSE_SECOND_CLICK",
			MOUSE_DOWN: "MOUSE_DOWN",
			MOUSE_UP: "MOUSE_UP",
			MOUSE_OVER: "MOUSE_OVER",
			MOUSE_OUT: "MOUSE_OUT",
			MOUSE_MOVE: "MOUSE_MOVE",
			MOUSE_MOVE_IN_VIEWPORT: "MOUSE_MOVE_IN_VIEWPORT",
			SCROLL_INTO_VIEW: "SCROLL_INTO_VIEW",
			SCROLL_OUT_OF_VIEW: "SCROLL_OUT_OF_VIEW",
			SCROLLING_IN_VIEW: "SCROLLING_IN_VIEW",
			ECOMMERCE_CART_OPEN: "ECOMMERCE_CART_OPEN",
			ECOMMERCE_CART_CLOSE: "ECOMMERCE_CART_CLOSE",
			PAGE_START: "PAGE_START",
			PAGE_FINISH: "PAGE_FINISH",
			PAGE_SCROLL_UP: "PAGE_SCROLL_UP",
			PAGE_SCROLL_DOWN: "PAGE_SCROLL_DOWN",
			PAGE_SCROLL: "PAGE_SCROLL"
		}, bi = {
			ELEMENT: "ELEMENT",
			CLASS: "CLASS",
			PAGE: "PAGE"
		}, et = {
			ELEMENT: "ELEMENT",
			VIEWPORT: "VIEWPORT"
		}, Ly = {
			X_AXIS: "X_AXIS",
			Y_AXIS: "Y_AXIS"
		}, Py = {
			CHILDREN: "CHILDREN",
			SIBLINGS: "SIBLINGS",
			IMMEDIATE_CHILDREN: "IMMEDIATE_CHILDREN"
		}, Wn = {
			FADE_EFFECT: "FADE_EFFECT",
			SLIDE_EFFECT: "SLIDE_EFFECT",
			GROW_EFFECT: "GROW_EFFECT",
			SHRINK_EFFECT: "SHRINK_EFFECT",
			SPIN_EFFECT: "SPIN_EFFECT",
			FLY_EFFECT: "FLY_EFFECT",
			POP_EFFECT: "POP_EFFECT",
			FLIP_EFFECT: "FLIP_EFFECT",
			JIGGLE_EFFECT: "JIGGLE_EFFECT",
			PULSE_EFFECT: "PULSE_EFFECT",
			DROP_EFFECT: "DROP_EFFECT",
			BLINK_EFFECT: "BLINK_EFFECT",
			BOUNCE_EFFECT: "BOUNCE_EFFECT",
			FLIP_LEFT_TO_RIGHT_EFFECT: "FLIP_LEFT_TO_RIGHT_EFFECT",
			FLIP_RIGHT_TO_LEFT_EFFECT: "FLIP_RIGHT_TO_LEFT_EFFECT",
			RUBBER_BAND_EFFECT: "RUBBER_BAND_EFFECT",
			JELLO_EFFECT: "JELLO_EFFECT",
			GROW_BIG_EFFECT: "GROW_BIG_EFFECT",
			SHRINK_BIG_EFFECT: "SHRINK_BIG_EFFECT",
			PLUGIN_LOTTIE_EFFECT: "PLUGIN_LOTTIE_EFFECT"
		}, Ny = {
			LEFT: "LEFT",
			RIGHT: "RIGHT",
			BOTTOM: "BOTTOM",
			TOP: "TOP",
			BOTTOM_LEFT: "BOTTOM_LEFT",
			BOTTOM_RIGHT: "BOTTOM_RIGHT",
			TOP_RIGHT: "TOP_RIGHT",
			TOP_LEFT: "TOP_LEFT",
			CLOCKWISE: "CLOCKWISE",
			COUNTER_CLOCKWISE: "COUNTER_CLOCKWISE"
		}
	});
	var Pe, Dy, Hn = ye(() => {
		"use strict";
		Pe = {
			TRANSFORM_MOVE: "TRANSFORM_MOVE",
			TRANSFORM_SCALE: "TRANSFORM_SCALE",
			TRANSFORM_ROTATE: "TRANSFORM_ROTATE",
			TRANSFORM_SKEW: "TRANSFORM_SKEW",
			STYLE_OPACITY: "STYLE_OPACITY",
			STYLE_SIZE: "STYLE_SIZE",
			STYLE_FILTER: "STYLE_FILTER",
			STYLE_FONT_VARIATION: "STYLE_FONT_VARIATION",
			STYLE_BACKGROUND_COLOR: "STYLE_BACKGROUND_COLOR",
			STYLE_BORDER: "STYLE_BORDER",
			STYLE_TEXT_COLOR: "STYLE_TEXT_COLOR",
			OBJECT_VALUE: "OBJECT_VALUE",
			PLUGIN_LOTTIE: "PLUGIN_LOTTIE",
			PLUGIN_SPLINE: "PLUGIN_SPLINE",
			PLUGIN_RIVE: "PLUGIN_RIVE",
			PLUGIN_VARIABLE: "PLUGIN_VARIABLE",
			GENERAL_DISPLAY: "GENERAL_DISPLAY",
			GENERAL_START_ACTION: "GENERAL_START_ACTION",
			GENERAL_CONTINUOUS_ACTION: "GENERAL_CONTINUOUS_ACTION",
			GENERAL_COMBO_CLASS: "GENERAL_COMBO_CLASS",
			GENERAL_STOP_ACTION: "GENERAL_STOP_ACTION",
			GENERAL_LOOP: "GENERAL_LOOP",
			STYLE_BOX_SHADOW: "STYLE_BOX_SHADOW"
		}, Dy = {
			ELEMENT: "ELEMENT",
			ELEMENT_CLASS: "ELEMENT_CLASS",
			TRIGGER_ELEMENT: "TRIGGER_ELEMENT"
		}
	});
	var My, Ts = ye(() => {
		"use strict";
		My = {
			MOUSE_CLICK_INTERACTION: "MOUSE_CLICK_INTERACTION",
			MOUSE_HOVER_INTERACTION: "MOUSE_HOVER_INTERACTION",
			MOUSE_MOVE_INTERACTION: "MOUSE_MOVE_INTERACTION",
			SCROLL_INTO_VIEW_INTERACTION: "SCROLL_INTO_VIEW_INTERACTION",
			SCROLLING_IN_VIEW_INTERACTION: "SCROLLING_IN_VIEW_INTERACTION",
			MOUSE_MOVE_IN_VIEWPORT_INTERACTION: "MOUSE_MOVE_IN_VIEWPORT_INTERACTION",
			PAGE_IS_SCROLLING_INTERACTION: "PAGE_IS_SCROLLING_INTERACTION",
			PAGE_LOAD_INTERACTION: "PAGE_LOAD_INTERACTION",
			PAGE_SCROLLED_INTERACTION: "PAGE_SCROLLED_INTERACTION",
			NAVBAR_INTERACTION: "NAVBAR_INTERACTION",
			DROPDOWN_INTERACTION: "DROPDOWN_INTERACTION",
			ECOMMERCE_CART_INTERACTION: "ECOMMERCE_CART_INTERACTION",
			TAB_INTERACTION: "TAB_INTERACTION",
			SLIDER_INTERACTION: "SLIDER_INTERACTION"
		}
	});
	var Fy, qy, ky, Gy, Vy, Xy, Uy, wi, ws = ye(() => {
		"use strict";
		Hn();
		({
			TRANSFORM_MOVE: Fy,
			TRANSFORM_SCALE: qy,
			TRANSFORM_ROTATE: ky,
			TRANSFORM_SKEW: Gy,
			STYLE_SIZE: Vy,
			STYLE_FILTER: Xy,
			STYLE_FONT_VARIATION: Uy
		} = Pe), wi = {
			[Fy]: !0,
			[qy]: !0,
			[ky]: !0,
			[Gy]: !0,
			[Vy]: !0,
			[Xy]: !0,
			[Uy]: !0
		}
	});
	var we = {};
	Fe(we, {
		IX2_ACTION_LIST_PLAYBACK_CHANGED: () => oE,
		IX2_ANIMATION_FRAME_CHANGED: () => Jy,
		IX2_CLEAR_REQUESTED: () => Qy,
		IX2_ELEMENT_STATE_CHANGED: () => iE,
		IX2_EVENT_LISTENER_ADDED: () => $y,
		IX2_EVENT_STATE_CHANGED: () => Zy,
		IX2_INSTANCE_ADDED: () => tE,
		IX2_INSTANCE_REMOVED: () => rE,
		IX2_INSTANCE_STARTED: () => nE,
		IX2_MEDIA_QUERIES_DEFINED: () => sE,
		IX2_PARAMETER_CHANGED: () => eE,
		IX2_PLAYBACK_REQUESTED: () => Ky,
		IX2_PREVIEW_REQUESTED: () => jy,
		IX2_RAW_DATA_IMPORTED: () => Wy,
		IX2_SESSION_INITIALIZED: () => Hy,
		IX2_SESSION_STARTED: () => By,
		IX2_SESSION_STOPPED: () => zy,
		IX2_STOP_REQUESTED: () => Yy,
		IX2_TEST_FRAME_RENDERED: () => uE,
		IX2_VIEWPORT_WIDTH_CHANGED: () => aE
	});
	var Wy, Hy, By, zy, jy, Ky, Yy, Qy, $y, Zy, Jy, eE, tE, nE, rE, iE, oE, aE, sE, uE, xs = ye(() => {
		"use strict";
		Wy = "IX2_RAW_DATA_IMPORTED", Hy = "IX2_SESSION_INITIALIZED", By = "IX2_SESSION_STARTED", zy = "IX2_SESSION_STOPPED", jy = "IX2_PREVIEW_REQUESTED", Ky = "IX2_PLAYBACK_REQUESTED", Yy = "IX2_STOP_REQUESTED", Qy = "IX2_CLEAR_REQUESTED", $y = "IX2_EVENT_LISTENER_ADDED", Zy = "IX2_EVENT_STATE_CHANGED", Jy = "IX2_ANIMATION_FRAME_CHANGED", eE = "IX2_PARAMETER_CHANGED", tE = "IX2_INSTANCE_ADDED", nE = "IX2_INSTANCE_STARTED", rE = "IX2_INSTANCE_REMOVED", iE = "IX2_ELEMENT_STATE_CHANGED", oE = "IX2_ACTION_LIST_PLAYBACK_CHANGED", aE = "IX2_VIEWPORT_WIDTH_CHANGED", sE = "IX2_MEDIA_QUERIES_DEFINED", uE = "IX2_TEST_FRAME_RENDERED"
	});
	var Se = {};
	Fe(Se, {
		ABSTRACT_NODE: () => a_,
		AUTO: () => YE,
		BACKGROUND: () => WE,
		BACKGROUND_COLOR: () => UE,
		BAR_DELIMITER: () => ZE,
		BORDER_COLOR: () => HE,
		BOUNDARY_SELECTOR: () => pE,
		CHILDREN: () => JE,
		COLON_DELIMITER: () => $E,
		COLOR: () => BE,
		COMMA_DELIMITER: () => QE,
		CONFIG_UNIT: () => IE,
		CONFIG_VALUE: () => mE,
		CONFIG_X_UNIT: () => yE,
		CONFIG_X_VALUE: () => gE,
		CONFIG_Y_UNIT: () => EE,
		CONFIG_Y_VALUE: () => hE,
		CONFIG_Z_UNIT: () => _E,
		CONFIG_Z_VALUE: () => vE,
		DISPLAY: () => zE,
		FILTER: () => kE,
		FLEX: () => jE,
		FONT_VARIATION_SETTINGS: () => GE,
		HEIGHT: () => XE,
		HTML_ELEMENT: () => i_,
		IMMEDIATE_CHILDREN: () => e_,
		IX2_ID_DELIMITER: () => cE,
		OPACITY: () => qE,
		PARENT: () => n_,
		PLAIN_OBJECT: () => o_,
		PRESERVE_3D: () => r_,
		RENDER_GENERAL: () => u_,
		RENDER_PLUGIN: () => l_,
		RENDER_STYLE: () => c_,
		RENDER_TRANSFORM: () => s_,
		ROTATE_X: () => LE,
		ROTATE_Y: () => PE,
		ROTATE_Z: () => NE,
		SCALE_3D: () => CE,
		SCALE_X: () => OE,
		SCALE_Y: () => SE,
		SCALE_Z: () => RE,
		SIBLINGS: () => t_,
		SKEW: () => DE,
		SKEW_X: () => ME,
		SKEW_Y: () => FE,
		TRANSFORM: () => bE,
		TRANSLATE_3D: () => AE,
		TRANSLATE_X: () => TE,
		TRANSLATE_Y: () => wE,
		TRANSLATE_Z: () => xE,
		WF_PAGE: () => lE,
		WIDTH: () => VE,
		WILL_CHANGE: () => KE,
		W_MOD_IX: () => dE,
		W_MOD_JS: () => fE
	});
	var cE, lE, fE, dE, pE, gE, hE, vE, mE, yE, EE, _E, IE, bE, TE, wE, xE, AE, OE, SE, RE, CE, LE, PE, NE, DE, ME, FE, qE, kE, GE, VE, XE, UE, WE, HE, BE, zE, jE, KE, YE, QE, $E, ZE, JE, e_, t_, n_, r_, i_, o_, a_, s_, u_, c_, l_, As = ye(() => {
		"use strict";
		cE = "|", lE = "data-wf-page", fE = "w-mod-js", dE = "w-mod-ix", pE = ".w-dyn-item", gE = "xValue", hE = "yValue", vE = "zValue", mE = "value", yE = "xUnit", EE = "yUnit", _E = "zUnit", IE = "unit", bE = "transform", TE = "translateX", wE = "translateY", xE = "translateZ", AE = "translate3d", OE = "scaleX", SE = "scaleY", RE = "scaleZ", CE = "scale3d", LE = "rotateX", PE = "rotateY", NE = "rotateZ", DE = "skew", ME = "skewX", FE = "skewY", qE = "opacity", kE = "filter", GE = "font-variation-settings", VE = "width", XE = "height", UE = "backgroundColor", WE = "background", HE = "borderColor", BE = "color", zE = "display", jE = "flex", KE = "willChange", YE = "AUTO", QE = ",", $E = ":", ZE = "|", JE = "CHILDREN", e_ = "IMMEDIATE_CHILDREN", t_ = "SIBLINGS", n_ = "PARENT", r_ = "preserve-3d", i_ = "HTML_ELEMENT", o_ = "PLAIN_OBJECT", a_ = "ABSTRACT_NODE", s_ = "RENDER_TRANSFORM", u_ = "RENDER_GENERAL", c_ = "RENDER_STYLE", l_ = "RENDER_PLUGIN"
	});
	var Os = {};
	Fe(Os, {
		ActionAppliesTo: () => Dy,
		ActionTypeConsts: () => Pe,
		EventAppliesTo: () => bi,
		EventBasedOn: () => et,
		EventContinuousMouseAxes: () => Ly,
		EventLimitAffectedElements: () => Py,
		EventTypeConsts: () => je,
		IX2EngineActionTypes: () => we,
		IX2EngineConstants: () => Se,
		InteractionTypeConsts: () => My,
		QuickEffectDirectionConsts: () => Ny,
		QuickEffectIds: () => Wn,
		ReducedMotionTypes: () => wi
	});
	var qe = ye(() => {
		"use strict";
		Ti();
		Hn();
		Ts();
		ws();
		xs();
		As();
		Hn();
		Ti()
	});
	var f_, Ss, Rs = ye(() => {
		"use strict";
		qe();
		({
			IX2_RAW_DATA_IMPORTED: f_
		} = we), Ss = (e = Object.freeze({}), t) => {
			switch (t.type) {
				case f_:
					return t.payload.ixData || Object.freeze({});
				default:
					return e
			}
		}
	});
	var Nt = g(_e => {
		"use strict";
		Object.defineProperty(_e, "__esModule", {
			value: !0
		});
		var d_ = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
			return typeof e
		} : function(e) {
			return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
		};
		_e.clone = zn;
		_e.addLast = Ps;
		_e.addFirst = Ns;
		_e.removeLast = Ds;
		_e.removeFirst = Ms;
		_e.insert = Fs;
		_e.removeAt = qs;
		_e.replaceAt = ks;
		_e.getIn = jn;
		_e.set = Kn;
		_e.setIn = Yn;
		_e.update = Vs;
		_e.updateIn = Xs;
		_e.merge = Us;
		_e.mergeDeep = Ws;
		_e.mergeIn = Hs;
		_e.omit = Bs;
		_e.addDefaults = zs;
		var Cs = "INVALID_ARGS";

		function Ls(e) {
			throw new Error(e)
		}

		function xi(e) {
			var t = Object.keys(e);
			return Object.getOwnPropertySymbols ? t.concat(Object.getOwnPropertySymbols(e)) : t
		}
		var p_ = {}.hasOwnProperty;

		function zn(e) {
			if (Array.isArray(e)) return e.slice();
			for (var t = xi(e), n = {}, r = 0; r < t.length; r++) {
				var i = t[r];
				n[i] = e[i]
			}
			return n
		}

		function ke(e, t, n) {
			var r = n;
			r == null && Ls(Cs);
			for (var i = !1, o = arguments.length, s = Array(o > 3 ? o - 3 : 0), a = 3; a < o; a++) s[a - 3] = arguments[a];
			for (var u = 0; u < s.length; u++) {
				var l = s[u];
				if (l != null) {
					var _ = xi(l);
					if (_.length)
						for (var d = 0; d <= _.length; d++) {
							var m = _[d];
							if (!(e && r[m] !== void 0)) {
								var v = l[m];
								t && Bn(r[m]) && Bn(v) && (v = ke(e, t, r[m], v)), !(v === void 0 || v === r[m]) && (i || (i = !0, r = zn(r)), r[m] = v)
							}
						}
				}
			}
			return r
		}

		function Bn(e) {
			var t = typeof e > "u" ? "undefined" : d_(e);
			return e != null && (t === "object" || t === "function")
		}

		function Ps(e, t) {
			return Array.isArray(t) ? e.concat(t) : e.concat([t])
		}

		function Ns(e, t) {
			return Array.isArray(t) ? t.concat(e) : [t].concat(e)
		}

		function Ds(e) {
			return e.length ? e.slice(0, e.length - 1) : e
		}

		function Ms(e) {
			return e.length ? e.slice(1) : e
		}

		function Fs(e, t, n) {
			return e.slice(0, t).concat(Array.isArray(n) ? n : [n]).concat(e.slice(t))
		}

		function qs(e, t) {
			return t >= e.length || t < 0 ? e : e.slice(0, t).concat(e.slice(t + 1))
		}

		function ks(e, t, n) {
			if (e[t] === n) return e;
			for (var r = e.length, i = Array(r), o = 0; o < r; o++) i[o] = e[o];
			return i[t] = n, i
		}

		function jn(e, t) {
			if (!Array.isArray(t) && Ls(Cs), e != null) {
				for (var n = e, r = 0; r < t.length; r++) {
					var i = t[r];
					if (n = n?.[i], n === void 0) return n
				}
				return n
			}
		}

		function Kn(e, t, n) {
			var r = typeof t == "number" ? [] : {},
				i = e ?? r;
			if (i[t] === n) return i;
			var o = zn(i);
			return o[t] = n, o
		}

		function Gs(e, t, n, r) {
			var i = void 0,
				o = t[r];
			if (r === t.length - 1) i = n;
			else {
				var s = Bn(e) && Bn(e[o]) ? e[o] : typeof t[r + 1] == "number" ? [] : {};
				i = Gs(s, t, n, r + 1)
			}
			return Kn(e, o, i)
		}

		function Yn(e, t, n) {
			return t.length ? Gs(e, t, n, 0) : n
		}

		function Vs(e, t, n) {
			var r = e?.[t],
				i = n(r);
			return Kn(e, t, i)
		}

		function Xs(e, t, n) {
			var r = jn(e, t),
				i = n(r);
			return Yn(e, t, i)
		}

		function Us(e, t, n, r, i, o) {
			for (var s = arguments.length, a = Array(s > 6 ? s - 6 : 0), u = 6; u < s; u++) a[u - 6] = arguments[u];
			return a.length ? ke.call.apply(ke, [null, !1, !1, e, t, n, r, i, o].concat(a)) : ke(!1, !1, e, t, n, r, i, o)
		}

		function Ws(e, t, n, r, i, o) {
			for (var s = arguments.length, a = Array(s > 6 ? s - 6 : 0), u = 6; u < s; u++) a[u - 6] = arguments[u];
			return a.length ? ke.call.apply(ke, [null, !1, !0, e, t, n, r, i, o].concat(a)) : ke(!1, !0, e, t, n, r, i, o)
		}

		function Hs(e, t, n, r, i, o, s) {
			var a = jn(e, t);
			a == null && (a = {});
			for (var u = void 0, l = arguments.length, _ = Array(l > 7 ? l - 7 : 0), d = 7; d < l; d++) _[d - 7] = arguments[d];
			return _.length ? u = ke.call.apply(ke, [null, !1, !1, a, n, r, i, o, s].concat(_)) : u = ke(!1, !1, a, n, r, i, o, s), Yn(e, t, u)
		}

		function Bs(e, t) {
			for (var n = Array.isArray(t) ? t : [t], r = !1, i = 0; i < n.length; i++)
				if (p_.call(e, n[i])) {
					r = !0;
					break
				} if (!r) return e;
			for (var o = {}, s = xi(e), a = 0; a < s.length; a++) {
				var u = s[a];
				n.indexOf(u) >= 0 || (o[u] = e[u])
			}
			return o
		}

		function zs(e, t, n, r, i, o) {
			for (var s = arguments.length, a = Array(s > 6 ? s - 6 : 0), u = 6; u < s; u++) a[u - 6] = arguments[u];
			return a.length ? ke.call.apply(ke, [null, !0, !1, e, t, n, r, i, o].concat(a)) : ke(!0, !1, e, t, n, r, i, o)
		}
		var g_ = {
			clone: zn,
			addLast: Ps,
			addFirst: Ns,
			removeLast: Ds,
			removeFirst: Ms,
			insert: Fs,
			removeAt: qs,
			replaceAt: ks,
			getIn: jn,
			set: Kn,
			setIn: Yn,
			update: Vs,
			updateIn: Xs,
			merge: Us,
			mergeDeep: Ws,
			mergeIn: Hs,
			omit: Bs,
			addDefaults: zs
		};
		_e.default = g_
	});
	var Ks, h_, v_, m_, y_, E_, js, Ys, Qs = ye(() => {
		"use strict";
		qe();
		Ks = ge(Nt()), {
			IX2_PREVIEW_REQUESTED: h_,
			IX2_PLAYBACK_REQUESTED: v_,
			IX2_STOP_REQUESTED: m_,
			IX2_CLEAR_REQUESTED: y_
		} = we, E_ = {
			preview: {},
			playback: {},
			stop: {},
			clear: {}
		}, js = Object.create(null, {
			[h_]: {
				value: "preview"
			},
			[v_]: {
				value: "playback"
			},
			[m_]: {
				value: "stop"
			},
			[y_]: {
				value: "clear"
			}
		}), Ys = (e = E_, t) => {
			if (t.type in js) {
				let n = [js[t.type]];
				return (0, Ks.setIn)(e, [n], {
					...t.payload
				})
			}
			return e
		}
	});
	var Ne, __, I_, b_, T_, w_, x_, A_, O_, S_, R_, $s, C_, Zs, Js = ye(() => {
		"use strict";
		qe();
		Ne = ge(Nt()), {
			IX2_SESSION_INITIALIZED: __,
			IX2_SESSION_STARTED: I_,
			IX2_TEST_FRAME_RENDERED: b_,
			IX2_SESSION_STOPPED: T_,
			IX2_EVENT_LISTENER_ADDED: w_,
			IX2_EVENT_STATE_CHANGED: x_,
			IX2_ANIMATION_FRAME_CHANGED: A_,
			IX2_ACTION_LIST_PLAYBACK_CHANGED: O_,
			IX2_VIEWPORT_WIDTH_CHANGED: S_,
			IX2_MEDIA_QUERIES_DEFINED: R_
		} = we, $s = {
			active: !1,
			tick: 0,
			eventListeners: [],
			eventState: {},
			playbackState: {},
			viewportWidth: 0,
			mediaQueryKey: null,
			hasBoundaryNodes: !1,
			hasDefinedMediaQueries: !1,
			reducedMotion: !1
		}, C_ = 20, Zs = (e = $s, t) => {
			switch (t.type) {
				case __: {
					let {
						hasBoundaryNodes: n,
						reducedMotion: r
					} = t.payload;
					return (0, Ne.merge)(e, {
						hasBoundaryNodes: n,
						reducedMotion: r
					})
				}
				case I_:
					return (0, Ne.set)(e, "active", !0);
				case b_: {
					let {
						payload: {
							step: n = C_
						}
					} = t;
					return (0, Ne.set)(e, "tick", e.tick + n)
				}
				case T_:
					return $s;
				case A_: {
					let {
						payload: {
							now: n
						}
					} = t;
					return (0, Ne.set)(e, "tick", n)
				}
				case w_: {
					let n = (0, Ne.addLast)(e.eventListeners, t.payload);
					return (0, Ne.set)(e, "eventListeners", n)
				}
				case x_: {
					let {
						stateKey: n,
						newState: r
					} = t.payload;
					return (0, Ne.setIn)(e, ["eventState", n], r)
				}
				case O_: {
					let {
						actionListId: n,
						isPlaying: r
					} = t.payload;
					return (0, Ne.setIn)(e, ["playbackState", n], r)
				}
				case S_: {
					let {
						width: n,
						mediaQueries: r
					} = t.payload, i = r.length, o = null;
					for (let s = 0; s < i; s++) {
						let {
							key: a,
							min: u,
							max: l
						} = r[s];
						if (n >= u && n <= l) {
							o = a;
							break
						}
					}
					return (0, Ne.merge)(e, {
						viewportWidth: n,
						mediaQueryKey: o
					})
				}
				case R_:
					return (0, Ne.set)(e, "hasDefinedMediaQueries", !0);
				default:
					return e
			}
		}
	});
	var tu = g((Y1, eu) => {
		function L_() {
			this.__data__ = [], this.size = 0
		}
		eu.exports = L_
	});
	var Qn = g((Q1, nu) => {
		function P_(e, t) {
			return e === t || e !== e && t !== t
		}
		nu.exports = P_
	});
	var un = g(($1, ru) => {
		var N_ = Qn();

		function D_(e, t) {
			for (var n = e.length; n--;)
				if (N_(e[n][0], t)) return n;
			return -1
		}
		ru.exports = D_
	});
	var ou = g((Z1, iu) => {
		var M_ = un(),
			F_ = Array.prototype,
			q_ = F_.splice;

		function k_(e) {
			var t = this.__data__,
				n = M_(t, e);
			if (n < 0) return !1;
			var r = t.length - 1;
			return n == r ? t.pop() : q_.call(t, n, 1), --this.size, !0
		}
		iu.exports = k_
	});
	var su = g((J1, au) => {
		var G_ = un();

		function V_(e) {
			var t = this.__data__,
				n = G_(t, e);
			return n < 0 ? void 0 : t[n][1]
		}
		au.exports = V_
	});
	var cu = g((e2, uu) => {
		var X_ = un();

		function U_(e) {
			return X_(this.__data__, e) > -1
		}
		uu.exports = U_
	});
	var fu = g((t2, lu) => {
		var W_ = un();

		function H_(e, t) {
			var n = this.__data__,
				r = W_(n, e);
			return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
		}
		lu.exports = H_
	});
	var cn = g((n2, du) => {
		var B_ = tu(),
			z_ = ou(),
			j_ = su(),
			K_ = cu(),
			Y_ = fu();

		function Dt(e) {
			var t = -1,
				n = e == null ? 0 : e.length;
			for (this.clear(); ++t < n;) {
				var r = e[t];
				this.set(r[0], r[1])
			}
		}
		Dt.prototype.clear = B_;
		Dt.prototype.delete = z_;
		Dt.prototype.get = j_;
		Dt.prototype.has = K_;
		Dt.prototype.set = Y_;
		du.exports = Dt
	});
	var gu = g((r2, pu) => {
		var Q_ = cn();

		function $_() {
			this.__data__ = new Q_, this.size = 0
		}
		pu.exports = $_
	});
	var vu = g((i2, hu) => {
		function Z_(e) {
			var t = this.__data__,
				n = t.delete(e);
			return this.size = t.size, n
		}
		hu.exports = Z_
	});
	var yu = g((o2, mu) => {
		function J_(e) {
			return this.__data__.get(e)
		}
		mu.exports = J_
	});
	var _u = g((a2, Eu) => {
		function eI(e) {
			return this.__data__.has(e)
		}
		Eu.exports = eI
	});
	var tt = g((s2, Iu) => {
		function tI(e) {
			var t = typeof e;
			return e != null && (t == "object" || t == "function")
		}
		Iu.exports = tI
	});
	var Ai = g((u2, bu) => {
		var nI = dt(),
			rI = tt(),
			iI = "[object AsyncFunction]",
			oI = "[object Function]",
			aI = "[object GeneratorFunction]",
			sI = "[object Proxy]";

		function uI(e) {
			if (!rI(e)) return !1;
			var t = nI(e);
			return t == oI || t == aI || t == iI || t == sI
		}
		bu.exports = uI
	});
	var wu = g((c2, Tu) => {
		var cI = ze(),
			lI = cI["__core-js_shared__"];
		Tu.exports = lI
	});
	var Ou = g((l2, Au) => {
		var Oi = wu(),
			xu = function() {
				var e = /[^.]+$/.exec(Oi && Oi.keys && Oi.keys.IE_PROTO || "");
				return e ? "Symbol(src)_1." + e : ""
			}();

		function fI(e) {
			return !!xu && xu in e
		}
		Au.exports = fI
	});
	var Si = g((f2, Su) => {
		var dI = Function.prototype,
			pI = dI.toString;

		function gI(e) {
			if (e != null) {
				try {
					return pI.call(e)
				} catch {}
				try {
					return e + ""
				} catch {}
			}
			return ""
		}
		Su.exports = gI
	});
	var Cu = g((d2, Ru) => {
		var hI = Ai(),
			vI = Ou(),
			mI = tt(),
			yI = Si(),
			EI = /[\\^$.*+?()[\]{}|]/g,
			_I = /^\[object .+?Constructor\]$/,
			II = Function.prototype,
			bI = Object.prototype,
			TI = II.toString,
			wI = bI.hasOwnProperty,
			xI = RegExp("^" + TI.call(wI).replace(EI, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

		function AI(e) {
			if (!mI(e) || vI(e)) return !1;
			var t = hI(e) ? xI : _I;
			return t.test(yI(e))
		}
		Ru.exports = AI
	});
	var Pu = g((p2, Lu) => {
		function OI(e, t) {
			return e?.[t]
		}
		Lu.exports = OI
	});
	var pt = g((g2, Nu) => {
		var SI = Cu(),
			RI = Pu();

		function CI(e, t) {
			var n = RI(e, t);
			return SI(n) ? n : void 0
		}
		Nu.exports = CI
	});
	var $n = g((h2, Du) => {
		var LI = pt(),
			PI = ze(),
			NI = LI(PI, "Map");
		Du.exports = NI
	});
	var ln = g((v2, Mu) => {
		var DI = pt(),
			MI = DI(Object, "create");
		Mu.exports = MI
	});
	var ku = g((m2, qu) => {
		var Fu = ln();

		function FI() {
			this.__data__ = Fu ? Fu(null) : {}, this.size = 0
		}
		qu.exports = FI
	});
	var Vu = g((y2, Gu) => {
		function qI(e) {
			var t = this.has(e) && delete this.__data__[e];
			return this.size -= t ? 1 : 0, t
		}
		Gu.exports = qI
	});
	var Uu = g((E2, Xu) => {
		var kI = ln(),
			GI = "__lodash_hash_undefined__",
			VI = Object.prototype,
			XI = VI.hasOwnProperty;

		function UI(e) {
			var t = this.__data__;
			if (kI) {
				var n = t[e];
				return n === GI ? void 0 : n
			}
			return XI.call(t, e) ? t[e] : void 0
		}
		Xu.exports = UI
	});
	var Hu = g((_2, Wu) => {
		var WI = ln(),
			HI = Object.prototype,
			BI = HI.hasOwnProperty;

		function zI(e) {
			var t = this.__data__;
			return WI ? t[e] !== void 0 : BI.call(t, e)
		}
		Wu.exports = zI
	});
	var zu = g((I2, Bu) => {
		var jI = ln(),
			KI = "__lodash_hash_undefined__";

		function YI(e, t) {
			var n = this.__data__;
			return this.size += this.has(e) ? 0 : 1, n[e] = jI && t === void 0 ? KI : t, this
		}
		Bu.exports = YI
	});
	var Ku = g((b2, ju) => {
		var QI = ku(),
			$I = Vu(),
			ZI = Uu(),
			JI = Hu(),
			eb = zu();

		function Mt(e) {
			var t = -1,
				n = e == null ? 0 : e.length;
			for (this.clear(); ++t < n;) {
				var r = e[t];
				this.set(r[0], r[1])
			}
		}
		Mt.prototype.clear = QI;
		Mt.prototype.delete = $I;
		Mt.prototype.get = ZI;
		Mt.prototype.has = JI;
		Mt.prototype.set = eb;
		ju.exports = Mt
	});
	var $u = g((T2, Qu) => {
		var Yu = Ku(),
			tb = cn(),
			nb = $n();

		function rb() {
			this.size = 0, this.__data__ = {
				hash: new Yu,
				map: new(nb || tb),
				string: new Yu
			}
		}
		Qu.exports = rb
	});
	var Ju = g((w2, Zu) => {
		function ib(e) {
			var t = typeof e;
			return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null
		}
		Zu.exports = ib
	});
	var fn = g((x2, ec) => {
		var ob = Ju();

		function ab(e, t) {
			var n = e.__data__;
			return ob(t) ? n[typeof t == "string" ? "string" : "hash"] : n.map
		}
		ec.exports = ab
	});
	var nc = g((A2, tc) => {
		var sb = fn();

		function ub(e) {
			var t = sb(this, e).delete(e);
			return this.size -= t ? 1 : 0, t
		}
		tc.exports = ub
	});
	var ic = g((O2, rc) => {
		var cb = fn();

		function lb(e) {
			return cb(this, e).get(e)
		}
		rc.exports = lb
	});
	var ac = g((S2, oc) => {
		var fb = fn();

		function db(e) {
			return fb(this, e).has(e)
		}
		oc.exports = db
	});
	var uc = g((R2, sc) => {
		var pb = fn();

		function gb(e, t) {
			var n = pb(this, e),
				r = n.size;
			return n.set(e, t), this.size += n.size == r ? 0 : 1, this
		}
		sc.exports = gb
	});
	var Zn = g((C2, cc) => {
		var hb = $u(),
			vb = nc(),
			mb = ic(),
			yb = ac(),
			Eb = uc();

		function Ft(e) {
			var t = -1,
				n = e == null ? 0 : e.length;
			for (this.clear(); ++t < n;) {
				var r = e[t];
				this.set(r[0], r[1])
			}
		}
		Ft.prototype.clear = hb;
		Ft.prototype.delete = vb;
		Ft.prototype.get = mb;
		Ft.prototype.has = yb;
		Ft.prototype.set = Eb;
		cc.exports = Ft
	});
	var fc = g((L2, lc) => {
		var _b = cn(),
			Ib = $n(),
			bb = Zn(),
			Tb = 200;

		function wb(e, t) {
			var n = this.__data__;
			if (n instanceof _b) {
				var r = n.__data__;
				if (!Ib || r.length < Tb - 1) return r.push([e, t]), this.size = ++n.size, this;
				n = this.__data__ = new bb(r)
			}
			return n.set(e, t), this.size = n.size, this
		}
		lc.exports = wb
	});
	var Ri = g((P2, dc) => {
		var xb = cn(),
			Ab = gu(),
			Ob = vu(),
			Sb = yu(),
			Rb = _u(),
			Cb = fc();

		function qt(e) {
			var t = this.__data__ = new xb(e);
			this.size = t.size
		}
		qt.prototype.clear = Ab;
		qt.prototype.delete = Ob;
		qt.prototype.get = Sb;
		qt.prototype.has = Rb;
		qt.prototype.set = Cb;
		dc.exports = qt
	});
	var gc = g((N2, pc) => {
		var Lb = "__lodash_hash_undefined__";

		function Pb(e) {
			return this.__data__.set(e, Lb), this
		}
		pc.exports = Pb
	});
	var vc = g((D2, hc) => {
		function Nb(e) {
			return this.__data__.has(e)
		}
		hc.exports = Nb
	});
	var yc = g((M2, mc) => {
		var Db = Zn(),
			Mb = gc(),
			Fb = vc();

		function Jn(e) {
			var t = -1,
				n = e == null ? 0 : e.length;
			for (this.__data__ = new Db; ++t < n;) this.add(e[t])
		}
		Jn.prototype.add = Jn.prototype.push = Mb;
		Jn.prototype.has = Fb;
		mc.exports = Jn
	});
	var _c = g((F2, Ec) => {
		function qb(e, t) {
			for (var n = -1, r = e == null ? 0 : e.length; ++n < r;)
				if (t(e[n], n, e)) return !0;
			return !1
		}
		Ec.exports = qb
	});
	var bc = g((q2, Ic) => {
		function kb(e, t) {
			return e.has(t)
		}
		Ic.exports = kb
	});
	var Ci = g((k2, Tc) => {
		var Gb = yc(),
			Vb = _c(),
			Xb = bc(),
			Ub = 1,
			Wb = 2;

		function Hb(e, t, n, r, i, o) {
			var s = n & Ub,
				a = e.length,
				u = t.length;
			if (a != u && !(s && u > a)) return !1;
			var l = o.get(e),
				_ = o.get(t);
			if (l && _) return l == t && _ == e;
			var d = -1,
				m = !0,
				v = n & Wb ? new Gb : void 0;
			for (o.set(e, t), o.set(t, e); ++d < a;) {
				var E = e[d],
					b = t[d];
				if (r) var x = s ? r(b, E, d, t, e, o) : r(E, b, d, e, t, o);
				if (x !== void 0) {
					if (x) continue;
					m = !1;
					break
				}
				if (v) {
					if (!Vb(t, function(T, L) {
							if (!Xb(v, L) && (E === T || i(E, T, n, r, o))) return v.push(L)
						})) {
						m = !1;
						break
					}
				} else if (!(E === b || i(E, b, n, r, o))) {
					m = !1;
					break
				}
			}
			return o.delete(e), o.delete(t), m
		}
		Tc.exports = Hb
	});
	var xc = g((G2, wc) => {
		var Bb = ze(),
			zb = Bb.Uint8Array;
		wc.exports = zb
	});
	var Oc = g((V2, Ac) => {
		function jb(e) {
			var t = -1,
				n = Array(e.size);
			return e.forEach(function(r, i) {
				n[++t] = [i, r]
			}), n
		}
		Ac.exports = jb
	});
	var Rc = g((X2, Sc) => {
		function Kb(e) {
			var t = -1,
				n = Array(e.size);
			return e.forEach(function(r) {
				n[++t] = r
			}), n
		}
		Sc.exports = Kb
	});
	var Dc = g((U2, Nc) => {
		var Cc = Ct(),
			Lc = xc(),
			Yb = Qn(),
			Qb = Ci(),
			$b = Oc(),
			Zb = Rc(),
			Jb = 1,
			eT = 2,
			tT = "[object Boolean]",
			nT = "[object Date]",
			rT = "[object Error]",
			iT = "[object Map]",
			oT = "[object Number]",
			aT = "[object RegExp]",
			sT = "[object Set]",
			uT = "[object String]",
			cT = "[object Symbol]",
			lT = "[object ArrayBuffer]",
			fT = "[object DataView]",
			Pc = Cc ? Cc.prototype : void 0,
			Li = Pc ? Pc.valueOf : void 0;

		function dT(e, t, n, r, i, o, s) {
			switch (n) {
				case fT:
					if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
					e = e.buffer, t = t.buffer;
				case lT:
					return !(e.byteLength != t.byteLength || !o(new Lc(e), new Lc(t)));
				case tT:
				case nT:
				case oT:
					return Yb(+e, +t);
				case rT:
					return e.name == t.name && e.message == t.message;
				case aT:
				case uT:
					return e == t + "";
				case iT:
					var a = $b;
				case sT:
					var u = r & Jb;
					if (a || (a = Zb), e.size != t.size && !u) return !1;
					var l = s.get(e);
					if (l) return l == t;
					r |= eT, s.set(e, t);
					var _ = Qb(a(e), a(t), r, i, o, s);
					return s.delete(e), _;
				case cT:
					if (Li) return Li.call(e) == Li.call(t)
			}
			return !1
		}
		Nc.exports = dT
	});
	var er = g((W2, Mc) => {
		function pT(e, t) {
			for (var n = -1, r = t.length, i = e.length; ++n < r;) e[i + n] = t[n];
			return e
		}
		Mc.exports = pT
	});
	var Ae = g((H2, Fc) => {
		var gT = Array.isArray;
		Fc.exports = gT
	});
	var Pi = g((B2, qc) => {
		var hT = er(),
			vT = Ae();

		function mT(e, t, n) {
			var r = t(e);
			return vT(e) ? r : hT(r, n(e))
		}
		qc.exports = mT
	});
	var Gc = g((z2, kc) => {
		function yT(e, t) {
			for (var n = -1, r = e == null ? 0 : e.length, i = 0, o = []; ++n < r;) {
				var s = e[n];
				t(s, n, e) && (o[i++] = s)
			}
			return o
		}
		kc.exports = yT
	});
	var Ni = g((j2, Vc) => {
		function ET() {
			return []
		}
		Vc.exports = ET
	});
	var Di = g((K2, Uc) => {
		var _T = Gc(),
			IT = Ni(),
			bT = Object.prototype,
			TT = bT.propertyIsEnumerable,
			Xc = Object.getOwnPropertySymbols,
			wT = Xc ? function(e) {
				return e == null ? [] : (e = Object(e), _T(Xc(e), function(t) {
					return TT.call(e, t)
				}))
			} : IT;
		Uc.exports = wT
	});
	var Hc = g((Y2, Wc) => {
		function xT(e, t) {
			for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
			return r
		}
		Wc.exports = xT
	});
	var zc = g((Q2, Bc) => {
		var AT = dt(),
			OT = at(),
			ST = "[object Arguments]";

		function RT(e) {
			return OT(e) && AT(e) == ST
		}
		Bc.exports = RT
	});
	var dn = g(($2, Yc) => {
		var jc = zc(),
			CT = at(),
			Kc = Object.prototype,
			LT = Kc.hasOwnProperty,
			PT = Kc.propertyIsEnumerable,
			NT = jc(function() {
				return arguments
			}()) ? jc : function(e) {
				return CT(e) && LT.call(e, "callee") && !PT.call(e, "callee")
			};
		Yc.exports = NT
	});
	var $c = g((Z2, Qc) => {
		function DT() {
			return !1
		}
		Qc.exports = DT
	});
	var tr = g((pn, kt) => {
		var MT = ze(),
			FT = $c(),
			el = typeof pn == "object" && pn && !pn.nodeType && pn,
			Zc = el && typeof kt == "object" && kt && !kt.nodeType && kt,
			qT = Zc && Zc.exports === el,
			Jc = qT ? MT.Buffer : void 0,
			kT = Jc ? Jc.isBuffer : void 0,
			GT = kT || FT;
		kt.exports = GT
	});
	var nr = g((J2, tl) => {
		var VT = 9007199254740991,
			XT = /^(?:0|[1-9]\d*)$/;

		function UT(e, t) {
			var n = typeof e;
			return t = t ?? VT, !!t && (n == "number" || n != "symbol" && XT.test(e)) && e > -1 && e % 1 == 0 && e < t
		}
		tl.exports = UT
	});
	var rr = g((eq, nl) => {
		var WT = 9007199254740991;

		function HT(e) {
			return typeof e == "number" && e > -1 && e % 1 == 0 && e <= WT
		}
		nl.exports = HT
	});
	var il = g((tq, rl) => {
		var BT = dt(),
			zT = rr(),
			jT = at(),
			KT = "[object Arguments]",
			YT = "[object Array]",
			QT = "[object Boolean]",
			$T = "[object Date]",
			ZT = "[object Error]",
			JT = "[object Function]",
			ew = "[object Map]",
			tw = "[object Number]",
			nw = "[object Object]",
			rw = "[object RegExp]",
			iw = "[object Set]",
			ow = "[object String]",
			aw = "[object WeakMap]",
			sw = "[object ArrayBuffer]",
			uw = "[object DataView]",
			cw = "[object Float32Array]",
			lw = "[object Float64Array]",
			fw = "[object Int8Array]",
			dw = "[object Int16Array]",
			pw = "[object Int32Array]",
			gw = "[object Uint8Array]",
			hw = "[object Uint8ClampedArray]",
			vw = "[object Uint16Array]",
			mw = "[object Uint32Array]",
			me = {};
		me[cw] = me[lw] = me[fw] = me[dw] = me[pw] = me[gw] = me[hw] = me[vw] = me[mw] = !0;
		me[KT] = me[YT] = me[sw] = me[QT] = me[uw] = me[$T] = me[ZT] = me[JT] = me[ew] = me[tw] = me[nw] = me[rw] = me[iw] = me[ow] = me[aw] = !1;

		function yw(e) {
			return jT(e) && zT(e.length) && !!me[BT(e)]
		}
		rl.exports = yw
	});
	var al = g((nq, ol) => {
		function Ew(e) {
			return function(t) {
				return e(t)
			}
		}
		ol.exports = Ew
	});
	var ul = g((gn, Gt) => {
		var _w = ai(),
			sl = typeof gn == "object" && gn && !gn.nodeType && gn,
			hn = sl && typeof Gt == "object" && Gt && !Gt.nodeType && Gt,
			Iw = hn && hn.exports === sl,
			Mi = Iw && _w.process,
			bw = function() {
				try {
					var e = hn && hn.require && hn.require("util").types;
					return e || Mi && Mi.binding && Mi.binding("util")
				} catch {}
			}();
		Gt.exports = bw
	});
	var ir = g((rq, fl) => {
		var Tw = il(),
			ww = al(),
			cl = ul(),
			ll = cl && cl.isTypedArray,
			xw = ll ? ww(ll) : Tw;
		fl.exports = xw
	});
	var Fi = g((iq, dl) => {
		var Aw = Hc(),
			Ow = dn(),
			Sw = Ae(),
			Rw = tr(),
			Cw = nr(),
			Lw = ir(),
			Pw = Object.prototype,
			Nw = Pw.hasOwnProperty;

		function Dw(e, t) {
			var n = Sw(e),
				r = !n && Ow(e),
				i = !n && !r && Rw(e),
				o = !n && !r && !i && Lw(e),
				s = n || r || i || o,
				a = s ? Aw(e.length, String) : [],
				u = a.length;
			for (var l in e)(t || Nw.call(e, l)) && !(s && (l == "length" || i && (l == "offset" || l == "parent") || o && (l == "buffer" || l == "byteLength" || l == "byteOffset") || Cw(l, u))) && a.push(l);
			return a
		}
		dl.exports = Dw
	});
	var or = g((oq, pl) => {
		var Mw = Object.prototype;

		function Fw(e) {
			var t = e && e.constructor,
				n = typeof t == "function" && t.prototype || Mw;
			return e === n
		}
		pl.exports = Fw
	});
	var hl = g((aq, gl) => {
		var qw = si(),
			kw = qw(Object.keys, Object);
		gl.exports = kw
	});
	var ar = g((sq, vl) => {
		var Gw = or(),
			Vw = hl(),
			Xw = Object.prototype,
			Uw = Xw.hasOwnProperty;

		function Ww(e) {
			if (!Gw(e)) return Vw(e);
			var t = [];
			for (var n in Object(e)) Uw.call(e, n) && n != "constructor" && t.push(n);
			return t
		}
		vl.exports = Ww
	});
	var _t = g((uq, ml) => {
		var Hw = Ai(),
			Bw = rr();

		function zw(e) {
			return e != null && Bw(e.length) && !Hw(e)
		}
		ml.exports = zw
	});
	var vn = g((cq, yl) => {
		var jw = Fi(),
			Kw = ar(),
			Yw = _t();

		function Qw(e) {
			return Yw(e) ? jw(e) : Kw(e)
		}
		yl.exports = Qw
	});
	var _l = g((lq, El) => {
		var $w = Pi(),
			Zw = Di(),
			Jw = vn();

		function e0(e) {
			return $w(e, Jw, Zw)
		}
		El.exports = e0
	});
	var Tl = g((fq, bl) => {
		var Il = _l(),
			t0 = 1,
			n0 = Object.prototype,
			r0 = n0.hasOwnProperty;

		function i0(e, t, n, r, i, o) {
			var s = n & t0,
				a = Il(e),
				u = a.length,
				l = Il(t),
				_ = l.length;
			if (u != _ && !s) return !1;
			for (var d = u; d--;) {
				var m = a[d];
				if (!(s ? m in t : r0.call(t, m))) return !1
			}
			var v = o.get(e),
				E = o.get(t);
			if (v && E) return v == t && E == e;
			var b = !0;
			o.set(e, t), o.set(t, e);
			for (var x = s; ++d < u;) {
				m = a[d];
				var T = e[m],
					L = t[m];
				if (r) var P = s ? r(L, T, m, t, e, o) : r(T, L, m, e, t, o);
				if (!(P === void 0 ? T === L || i(T, L, n, r, o) : P)) {
					b = !1;
					break
				}
				x || (x = m == "constructor")
			}
			if (b && !x) {
				var D = e.constructor,
					F = t.constructor;
				D != F && "constructor" in e && "constructor" in t && !(typeof D == "function" && D instanceof D && typeof F == "function" && F instanceof F) && (b = !1)
			}
			return o.delete(e), o.delete(t), b
		}
		bl.exports = i0
	});
	var xl = g((dq, wl) => {
		var o0 = pt(),
			a0 = ze(),
			s0 = o0(a0, "DataView");
		wl.exports = s0
	});
	var Ol = g((pq, Al) => {
		var u0 = pt(),
			c0 = ze(),
			l0 = u0(c0, "Promise");
		Al.exports = l0
	});
	var Rl = g((gq, Sl) => {
		var f0 = pt(),
			d0 = ze(),
			p0 = f0(d0, "Set");
		Sl.exports = p0
	});
	var qi = g((hq, Cl) => {
		var g0 = pt(),
			h0 = ze(),
			v0 = g0(h0, "WeakMap");
		Cl.exports = v0
	});
	var sr = g((vq, ql) => {
		var ki = xl(),
			Gi = $n(),
			Vi = Ol(),
			Xi = Rl(),
			Ui = qi(),
			Fl = dt(),
			Vt = Si(),
			Ll = "[object Map]",
			m0 = "[object Object]",
			Pl = "[object Promise]",
			Nl = "[object Set]",
			Dl = "[object WeakMap]",
			Ml = "[object DataView]",
			y0 = Vt(ki),
			E0 = Vt(Gi),
			_0 = Vt(Vi),
			I0 = Vt(Xi),
			b0 = Vt(Ui),
			It = Fl;
		(ki && It(new ki(new ArrayBuffer(1))) != Ml || Gi && It(new Gi) != Ll || Vi && It(Vi.resolve()) != Pl || Xi && It(new Xi) != Nl || Ui && It(new Ui) != Dl) && (It = function(e) {
			var t = Fl(e),
				n = t == m0 ? e.constructor : void 0,
				r = n ? Vt(n) : "";
			if (r) switch (r) {
				case y0:
					return Ml;
				case E0:
					return Ll;
				case _0:
					return Pl;
				case I0:
					return Nl;
				case b0:
					return Dl
			}
			return t
		});
		ql.exports = It
	});
	var Bl = g((mq, Hl) => {
		var Wi = Ri(),
			T0 = Ci(),
			w0 = Dc(),
			x0 = Tl(),
			kl = sr(),
			Gl = Ae(),
			Vl = tr(),
			A0 = ir(),
			O0 = 1,
			Xl = "[object Arguments]",
			Ul = "[object Array]",
			ur = "[object Object]",
			S0 = Object.prototype,
			Wl = S0.hasOwnProperty;

		function R0(e, t, n, r, i, o) {
			var s = Gl(e),
				a = Gl(t),
				u = s ? Ul : kl(e),
				l = a ? Ul : kl(t);
			u = u == Xl ? ur : u, l = l == Xl ? ur : l;
			var _ = u == ur,
				d = l == ur,
				m = u == l;
			if (m && Vl(e)) {
				if (!Vl(t)) return !1;
				s = !0, _ = !1
			}
			if (m && !_) return o || (o = new Wi), s || A0(e) ? T0(e, t, n, r, i, o) : w0(e, t, u, n, r, i, o);
			if (!(n & O0)) {
				var v = _ && Wl.call(e, "__wrapped__"),
					E = d && Wl.call(t, "__wrapped__");
				if (v || E) {
					var b = v ? e.value() : e,
						x = E ? t.value() : t;
					return o || (o = new Wi), i(b, x, n, r, o)
				}
			}
			return m ? (o || (o = new Wi), x0(e, t, n, r, i, o)) : !1
		}
		Hl.exports = R0
	});
	var Hi = g((yq, Kl) => {
		var C0 = Bl(),
			zl = at();

		function jl(e, t, n, r, i) {
			return e === t ? !0 : e == null || t == null || !zl(e) && !zl(t) ? e !== e && t !== t : C0(e, t, n, r, jl, i)
		}
		Kl.exports = jl
	});
	var Ql = g((Eq, Yl) => {
		var L0 = Ri(),
			P0 = Hi(),
			N0 = 1,
			D0 = 2;

		function M0(e, t, n, r) {
			var i = n.length,
				o = i,
				s = !r;
			if (e == null) return !o;
			for (e = Object(e); i--;) {
				var a = n[i];
				if (s && a[2] ? a[1] !== e[a[0]] : !(a[0] in e)) return !1
			}
			for (; ++i < o;) {
				a = n[i];
				var u = a[0],
					l = e[u],
					_ = a[1];
				if (s && a[2]) {
					if (l === void 0 && !(u in e)) return !1
				} else {
					var d = new L0;
					if (r) var m = r(l, _, u, e, t, d);
					if (!(m === void 0 ? P0(_, l, N0 | D0, r, d) : m)) return !1
				}
			}
			return !0
		}
		Yl.exports = M0
	});
	var Bi = g((_q, $l) => {
		var F0 = tt();

		function q0(e) {
			return e === e && !F0(e)
		}
		$l.exports = q0
	});
	var Jl = g((Iq, Zl) => {
		var k0 = Bi(),
			G0 = vn();

		function V0(e) {
			for (var t = G0(e), n = t.length; n--;) {
				var r = t[n],
					i = e[r];
				t[n] = [r, i, k0(i)]
			}
			return t
		}
		Zl.exports = V0
	});
	var zi = g((bq, ef) => {
		function X0(e, t) {
			return function(n) {
				return n == null ? !1 : n[e] === t && (t !== void 0 || e in Object(n))
			}
		}
		ef.exports = X0
	});
	var nf = g((Tq, tf) => {
		var U0 = Ql(),
			W0 = Jl(),
			H0 = zi();

		function B0(e) {
			var t = W0(e);
			return t.length == 1 && t[0][2] ? H0(t[0][0], t[0][1]) : function(n) {
				return n === e || U0(n, e, t)
			}
		}
		tf.exports = B0
	});
	var mn = g((wq, rf) => {
		var z0 = dt(),
			j0 = at(),
			K0 = "[object Symbol]";

		function Y0(e) {
			return typeof e == "symbol" || j0(e) && z0(e) == K0
		}
		rf.exports = Y0
	});
	var cr = g((xq, of) => {
		var Q0 = Ae(),
			$0 = mn(),
			Z0 = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
			J0 = /^\w*$/;

		function ex(e, t) {
			if (Q0(e)) return !1;
			var n = typeof e;
			return n == "number" || n == "symbol" || n == "boolean" || e == null || $0(e) ? !0 : J0.test(e) || !Z0.test(e) || t != null && e in Object(t)
		}
		of.exports = ex
	});
	var uf = g((Aq, sf) => {
		var af = Zn(),
			tx = "Expected a function";

		function ji(e, t) {
			if (typeof e != "function" || t != null && typeof t != "function") throw new TypeError(tx);
			var n = function() {
				var r = arguments,
					i = t ? t.apply(this, r) : r[0],
					o = n.cache;
				if (o.has(i)) return o.get(i);
				var s = e.apply(this, r);
				return n.cache = o.set(i, s) || o, s
			};
			return n.cache = new(ji.Cache || af), n
		}
		ji.Cache = af;
		sf.exports = ji
	});
	var lf = g((Oq, cf) => {
		var nx = uf(),
			rx = 500;

		function ix(e) {
			var t = nx(e, function(r) {
					return n.size === rx && n.clear(), r
				}),
				n = t.cache;
			return t
		}
		cf.exports = ix
	});
	var df = g((Sq, ff) => {
		var ox = lf(),
			ax = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
			sx = /\\(\\)?/g,
			ux = ox(function(e) {
				var t = [];
				return e.charCodeAt(0) === 46 && t.push(""), e.replace(ax, function(n, r, i, o) {
					t.push(i ? o.replace(sx, "$1") : r || n)
				}), t
			});
		ff.exports = ux
	});
	var Ki = g((Rq, pf) => {
		function cx(e, t) {
			for (var n = -1, r = e == null ? 0 : e.length, i = Array(r); ++n < r;) i[n] = t(e[n], n, e);
			return i
		}
		pf.exports = cx
	});
	var Ef = g((Cq, yf) => {
		var gf = Ct(),
			lx = Ki(),
			fx = Ae(),
			dx = mn(),
			px = 1 / 0,
			hf = gf ? gf.prototype : void 0,
			vf = hf ? hf.toString : void 0;

		function mf(e) {
			if (typeof e == "string") return e;
			if (fx(e)) return lx(e, mf) + "";
			if (dx(e)) return vf ? vf.call(e) : "";
			var t = e + "";
			return t == "0" && 1 / e == -px ? "-0" : t
		}
		yf.exports = mf
	});
	var If = g((Lq, _f) => {
		var gx = Ef();

		function hx(e) {
			return e == null ? "" : gx(e)
		}
		_f.exports = hx
	});
	var yn = g((Pq, bf) => {
		var vx = Ae(),
			mx = cr(),
			yx = df(),
			Ex = If();

		function _x(e, t) {
			return vx(e) ? e : mx(e, t) ? [e] : yx(Ex(e))
		}
		bf.exports = _x
	});
	var Xt = g((Nq, Tf) => {
		var Ix = mn(),
			bx = 1 / 0;

		function Tx(e) {
			if (typeof e == "string" || Ix(e)) return e;
			var t = e + "";
			return t == "0" && 1 / e == -bx ? "-0" : t
		}
		Tf.exports = Tx
	});
	var lr = g((Dq, wf) => {
		var wx = yn(),
			xx = Xt();

		function Ax(e, t) {
			t = wx(t, e);
			for (var n = 0, r = t.length; e != null && n < r;) e = e[xx(t[n++])];
			return n && n == r ? e : void 0
		}
		wf.exports = Ax
	});
	var fr = g((Mq, xf) => {
		var Ox = lr();

		function Sx(e, t, n) {
			var r = e == null ? void 0 : Ox(e, t);
			return r === void 0 ? n : r
		}
		xf.exports = Sx
	});
	var Of = g((Fq, Af) => {
		function Rx(e, t) {
			return e != null && t in Object(e)
		}
		Af.exports = Rx
	});
	var Rf = g((qq, Sf) => {
		var Cx = yn(),
			Lx = dn(),
			Px = Ae(),
			Nx = nr(),
			Dx = rr(),
			Mx = Xt();

		function Fx(e, t, n) {
			t = Cx(t, e);
			for (var r = -1, i = t.length, o = !1; ++r < i;) {
				var s = Mx(t[r]);
				if (!(o = e != null && n(e, s))) break;
				e = e[s]
			}
			return o || ++r != i ? o : (i = e == null ? 0 : e.length, !!i && Dx(i) && Nx(s, i) && (Px(e) || Lx(e)))
		}
		Sf.exports = Fx
	});
	var Lf = g((kq, Cf) => {
		var qx = Of(),
			kx = Rf();

		function Gx(e, t) {
			return e != null && kx(e, t, qx)
		}
		Cf.exports = Gx
	});
	var Nf = g((Gq, Pf) => {
		var Vx = Hi(),
			Xx = fr(),
			Ux = Lf(),
			Wx = cr(),
			Hx = Bi(),
			Bx = zi(),
			zx = Xt(),
			jx = 1,
			Kx = 2;

		function Yx(e, t) {
			return Wx(e) && Hx(t) ? Bx(zx(e), t) : function(n) {
				var r = Xx(n, e);
				return r === void 0 && r === t ? Ux(n, e) : Vx(t, r, jx | Kx)
			}
		}
		Pf.exports = Yx
	});
	var dr = g((Vq, Df) => {
		function Qx(e) {
			return e
		}
		Df.exports = Qx
	});
	var Yi = g((Xq, Mf) => {
		function $x(e) {
			return function(t) {
				return t?.[e]
			}
		}
		Mf.exports = $x
	});
	var qf = g((Uq, Ff) => {
		var Zx = lr();

		function Jx(e) {
			return function(t) {
				return Zx(t, e)
			}
		}
		Ff.exports = Jx
	});
	var Gf = g((Wq, kf) => {
		var eA = Yi(),
			tA = qf(),
			nA = cr(),
			rA = Xt();

		function iA(e) {
			return nA(e) ? eA(rA(e)) : tA(e)
		}
		kf.exports = iA
	});
	var gt = g((Hq, Vf) => {
		var oA = nf(),
			aA = Nf(),
			sA = dr(),
			uA = Ae(),
			cA = Gf();

		function lA(e) {
			return typeof e == "function" ? e : e == null ? sA : typeof e == "object" ? uA(e) ? aA(e[0], e[1]) : oA(e) : cA(e)
		}
		Vf.exports = lA
	});
	var Qi = g((Bq, Xf) => {
		var fA = gt(),
			dA = _t(),
			pA = vn();

		function gA(e) {
			return function(t, n, r) {
				var i = Object(t);
				if (!dA(t)) {
					var o = fA(n, 3);
					t = pA(t), n = function(a) {
						return o(i[a], a, i)
					}
				}
				var s = e(t, n, r);
				return s > -1 ? i[o ? t[s] : s] : void 0
			}
		}
		Xf.exports = gA
	});
	var $i = g((zq, Uf) => {
		function hA(e, t, n, r) {
			for (var i = e.length, o = n + (r ? 1 : -1); r ? o-- : ++o < i;)
				if (t(e[o], o, e)) return o;
			return -1
		}
		Uf.exports = hA
	});
	var Hf = g((jq, Wf) => {
		var vA = /\s/;

		function mA(e) {
			for (var t = e.length; t-- && vA.test(e.charAt(t)););
			return t
		}
		Wf.exports = mA
	});
	var zf = g((Kq, Bf) => {
		var yA = Hf(),
			EA = /^\s+/;

		function _A(e) {
			return e && e.slice(0, yA(e) + 1).replace(EA, "")
		}
		Bf.exports = _A
	});
	var pr = g((Yq, Yf) => {
		var IA = zf(),
			jf = tt(),
			bA = mn(),
			Kf = 0 / 0,
			TA = /^[-+]0x[0-9a-f]+$/i,
			wA = /^0b[01]+$/i,
			xA = /^0o[0-7]+$/i,
			AA = parseInt;

		function OA(e) {
			if (typeof e == "number") return e;
			if (bA(e)) return Kf;
			if (jf(e)) {
				var t = typeof e.valueOf == "function" ? e.valueOf() : e;
				e = jf(t) ? t + "" : t
			}
			if (typeof e != "string") return e === 0 ? e : +e;
			e = IA(e);
			var n = wA.test(e);
			return n || xA.test(e) ? AA(e.slice(2), n ? 2 : 8) : TA.test(e) ? Kf : +e
		}
		Yf.exports = OA
	});
	var Zf = g((Qq, $f) => {
		var SA = pr(),
			Qf = 1 / 0,
			RA = 17976931348623157e292;

		function CA(e) {
			if (!e) return e === 0 ? e : 0;
			if (e = SA(e), e === Qf || e === -Qf) {
				var t = e < 0 ? -1 : 1;
				return t * RA
			}
			return e === e ? e : 0
		}
		$f.exports = CA
	});
	var Zi = g(($q, Jf) => {
		var LA = Zf();

		function PA(e) {
			var t = LA(e),
				n = t % 1;
			return t === t ? n ? t - n : t : 0
		}
		Jf.exports = PA
	});
	var td = g((Zq, ed) => {
		var NA = $i(),
			DA = gt(),
			MA = Zi(),
			FA = Math.max;

		function qA(e, t, n) {
			var r = e == null ? 0 : e.length;
			if (!r) return -1;
			var i = n == null ? 0 : MA(n);
			return i < 0 && (i = FA(r + i, 0)), NA(e, DA(t, 3), i)
		}
		ed.exports = qA
	});
	var Ji = g((Jq, nd) => {
		var kA = Qi(),
			GA = td(),
			VA = kA(GA);
		nd.exports = VA
	});
	var od = {};
	Fe(od, {
		ELEMENT_MATCHES: () => XA,
		FLEX_PREFIXED: () => eo,
		IS_BROWSER_ENV: () => Ke,
		TRANSFORM_PREFIXED: () => ht,
		TRANSFORM_STYLE_PREFIXED: () => hr,
		withBrowser: () => gr
	});
	var id, Ke, gr, XA, eo, ht, rd, hr, vr = ye(() => {
		"use strict";
		id = ge(Ji()), Ke = typeof window < "u", gr = (e, t) => Ke ? e() : t, XA = gr(() => (0, id.default)(["matches", "matchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector", "webkitMatchesSelector"], e => e in Element.prototype)), eo = gr(() => {
			let e = document.createElement("i"),
				t = ["flex", "-webkit-flex", "-ms-flexbox", "-moz-box", "-webkit-box"],
				n = "";
			try {
				let {
					length: r
				} = t;
				for (let i = 0; i < r; i++) {
					let o = t[i];
					if (e.style.display = o, e.style.display === o) return o
				}
				return n
			} catch {
				return n
			}
		}, "flex"), ht = gr(() => {
			let e = document.createElement("i");
			if (e.style.transform == null) {
				let t = ["Webkit", "Moz", "ms"],
					n = "Transform",
					{
						length: r
					} = t;
				for (let i = 0; i < r; i++) {
					let o = t[i] + n;
					if (e.style[o] !== void 0) return o
				}
			}
			return "transform"
		}, "transform"), rd = ht.split("transform")[0], hr = rd ? rd + "TransformStyle" : "transformStyle"
	});
	var to = g((ek, ld) => {
		var UA = 4,
			WA = .001,
			HA = 1e-7,
			BA = 10,
			En = 11,
			mr = 1 / (En - 1),
			zA = typeof Float32Array == "function";

		function ad(e, t) {
			return 1 - 3 * t + 3 * e
		}

		function sd(e, t) {
			return 3 * t - 6 * e
		}

		function ud(e) {
			return 3 * e
		}

		function yr(e, t, n) {
			return ((ad(t, n) * e + sd(t, n)) * e + ud(t)) * e
		}

		function cd(e, t, n) {
			return 3 * ad(t, n) * e * e + 2 * sd(t, n) * e + ud(t)
		}

		function jA(e, t, n, r, i) {
			var o, s, a = 0;
			do s = t + (n - t) / 2, o = yr(s, r, i) - e, o > 0 ? n = s : t = s; while (Math.abs(o) > HA && ++a < BA);
			return s
		}

		function KA(e, t, n, r) {
			for (var i = 0; i < UA; ++i) {
				var o = cd(t, n, r);
				if (o === 0) return t;
				var s = yr(t, n, r) - e;
				t -= s / o
			}
			return t
		}
		ld.exports = function(t, n, r, i) {
			if (!(0 <= t && t <= 1 && 0 <= r && r <= 1)) throw new Error("bezier x values must be in [0, 1] range");
			var o = zA ? new Float32Array(En) : new Array(En);
			if (t !== n || r !== i)
				for (var s = 0; s < En; ++s) o[s] = yr(s * mr, t, r);

			function a(u) {
				for (var l = 0, _ = 1, d = En - 1; _ !== d && o[_] <= u; ++_) l += mr;
				--_;
				var m = (u - o[_]) / (o[_ + 1] - o[_]),
					v = l + m * mr,
					E = cd(v, t, r);
				return E >= WA ? KA(u, v, t, r) : E === 0 ? v : jA(u, l, l + mr, t, r)
			}
			return function(l) {
				return t === n && r === i ? l : l === 0 ? 0 : l === 1 ? 1 : yr(a(l), n, i)
			}
		}
	});
	var In = {};
	Fe(In, {
		bounce: () => CO,
		bouncePast: () => LO,
		ease: () => YA,
		easeIn: () => QA,
		easeInOut: () => ZA,
		easeOut: () => $A,
		inBack: () => IO,
		inCirc: () => mO,
		inCubic: () => nO,
		inElastic: () => wO,
		inExpo: () => gO,
		inOutBack: () => TO,
		inOutCirc: () => EO,
		inOutCubic: () => iO,
		inOutElastic: () => AO,
		inOutExpo: () => vO,
		inOutQuad: () => tO,
		inOutQuart: () => sO,
		inOutQuint: () => lO,
		inOutSine: () => pO,
		inQuad: () => JA,
		inQuart: () => oO,
		inQuint: () => uO,
		inSine: () => fO,
		outBack: () => bO,
		outBounce: () => _O,
		outCirc: () => yO,
		outCubic: () => rO,
		outElastic: () => xO,
		outExpo: () => hO,
		outQuad: () => eO,
		outQuart: () => aO,
		outQuint: () => cO,
		outSine: () => dO,
		swingFrom: () => SO,
		swingFromTo: () => OO,
		swingTo: () => RO
	});

	function JA(e) {
		return Math.pow(e, 2)
	}

	function eO(e) {
		return -(Math.pow(e - 1, 2) - 1)
	}

	function tO(e) {
		return (e /= .5) < 1 ? .5 * Math.pow(e, 2) : -.5 * ((e -= 2) * e - 2)
	}

	function nO(e) {
		return Math.pow(e, 3)
	}

	function rO(e) {
		return Math.pow(e - 1, 3) + 1
	}

	function iO(e) {
		return (e /= .5) < 1 ? .5 * Math.pow(e, 3) : .5 * (Math.pow(e - 2, 3) + 2)
	}

	function oO(e) {
		return Math.pow(e, 4)
	}

	function aO(e) {
		return -(Math.pow(e - 1, 4) - 1)
	}

	function sO(e) {
		return (e /= .5) < 1 ? .5 * Math.pow(e, 4) : -.5 * ((e -= 2) * Math.pow(e, 3) - 2)
	}

	function uO(e) {
		return Math.pow(e, 5)
	}

	function cO(e) {
		return Math.pow(e - 1, 5) + 1
	}

	function lO(e) {
		return (e /= .5) < 1 ? .5 * Math.pow(e, 5) : .5 * (Math.pow(e - 2, 5) + 2)
	}

	function fO(e) {
		return -Math.cos(e * (Math.PI / 2)) + 1
	}

	function dO(e) {
		return Math.sin(e * (Math.PI / 2))
	}

	function pO(e) {
		return -.5 * (Math.cos(Math.PI * e) - 1)
	}

	function gO(e) {
		return e === 0 ? 0 : Math.pow(2, 10 * (e - 1))
	}

	function hO(e) {
		return e === 1 ? 1 : -Math.pow(2, -10 * e) + 1
	}

	function vO(e) {
		return e === 0 ? 0 : e === 1 ? 1 : (e /= .5) < 1 ? .5 * Math.pow(2, 10 * (e - 1)) : .5 * (-Math.pow(2, -10 * --e) + 2)
	}

	function mO(e) {
		return -(Math.sqrt(1 - e * e) - 1)
	}

	function yO(e) {
		return Math.sqrt(1 - Math.pow(e - 1, 2))
	}

	function EO(e) {
		return (e /= .5) < 1 ? -.5 * (Math.sqrt(1 - e * e) - 1) : .5 * (Math.sqrt(1 - (e -= 2) * e) + 1)
	}

	function _O(e) {
		return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
	}

	function IO(e) {
		let t = st;
		return e * e * ((t + 1) * e - t)
	}

	function bO(e) {
		let t = st;
		return (e -= 1) * e * ((t + 1) * e + t) + 1
	}

	function TO(e) {
		let t = st;
		return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2)
	}

	function wO(e) {
		let t = st,
			n = 0,
			r = 1;
		return e === 0 ? 0 : e === 1 ? 1 : (n || (n = .3), r < 1 ? (r = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / r), -(r * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)))
	}

	function xO(e) {
		let t = st,
			n = 0,
			r = 1;
		return e === 0 ? 0 : e === 1 ? 1 : (n || (n = .3), r < 1 ? (r = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / r), r * Math.pow(2, -10 * e) * Math.sin((e - t) * (2 * Math.PI) / n) + 1)
	}

	function AO(e) {
		let t = st,
			n = 0,
			r = 1;
		return e === 0 ? 0 : (e /= 1 / 2) === 2 ? 1 : (n || (n = .3 * 1.5), r < 1 ? (r = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / r), e < 1 ? -.5 * (r * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)) : r * Math.pow(2, -10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n) * .5 + 1)
	}

	function OO(e) {
		let t = st;
		return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2)
	}

	function SO(e) {
		let t = st;
		return e * e * ((t + 1) * e - t)
	}

	function RO(e) {
		let t = st;
		return (e -= 1) * e * ((t + 1) * e + t) + 1
	}

	function CO(e) {
		return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
	}

	function LO(e) {
		return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + .75) : e < 2.5 / 2.75 ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + .9375) : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + .984375)
	}
	var _n, st, YA, QA, $A, ZA, no = ye(() => {
		"use strict";
		_n = ge(to()), st = 1.70158, YA = (0, _n.default)(.25, .1, .25, 1), QA = (0, _n.default)(.42, 0, 1, 1), $A = (0, _n.default)(0, 0, .58, 1), ZA = (0, _n.default)(.42, 0, .58, 1)
	});
	var dd = {};
	Fe(dd, {
		applyEasing: () => NO,
		createBezierEasing: () => PO,
		optimizeFloat: () => bn
	});

	function bn(e, t = 5, n = 10) {
		let r = Math.pow(n, t),
			i = Number(Math.round(e * r) / r);
		return Math.abs(i) > 1e-4 ? i : 0
	}

	function PO(e) {
		return (0, fd.default)(...e)
	}

	function NO(e, t, n) {
		return t === 0 ? 0 : t === 1 ? 1 : bn(n ? t > 0 ? n(t) : t : t > 0 && e && In[e] ? In[e](t) : t)
	}
	var fd, ro = ye(() => {
		"use strict";
		no();
		fd = ge(to())
	});
	var hd = {};
	Fe(hd, {
		createElementState: () => gd,
		ixElements: () => jO,
		mergeActionState: () => io
	});

	function gd(e, t, n, r, i) {
		let o = n === DO ? (0, Ut.getIn)(i, ["config", "target", "objectId"]) : null;
		return (0, Ut.mergeIn)(e, [r], {
			id: r,
			ref: t,
			refId: o,
			refType: n
		})
	}

	function io(e, t, n, r, i) {
		let o = YO(i);
		return (0, Ut.mergeIn)(e, [t, zO, n], r, o)
	}

	function YO(e) {
		let {
			config: t
		} = e;
		return KO.reduce((n, r) => {
			let i = r[0],
				o = r[1],
				s = t[i],
				a = t[o];
			return s != null && a != null && (n[o] = a), n
		}, {})
	}
	var Ut, nk, DO, rk, MO, FO, qO, kO, GO, VO, XO, UO, WO, HO, BO, pd, zO, jO, KO, vd = ye(() => {
		"use strict";
		Ut = ge(Nt());
		qe();
		({
			HTML_ELEMENT: nk,
			PLAIN_OBJECT: DO,
			ABSTRACT_NODE: rk,
			CONFIG_X_VALUE: MO,
			CONFIG_Y_VALUE: FO,
			CONFIG_Z_VALUE: qO,
			CONFIG_VALUE: kO,
			CONFIG_X_UNIT: GO,
			CONFIG_Y_UNIT: VO,
			CONFIG_Z_UNIT: XO,
			CONFIG_UNIT: UO
		} = Se), {
			IX2_SESSION_STOPPED: WO,
			IX2_INSTANCE_ADDED: HO,
			IX2_ELEMENT_STATE_CHANGED: BO
		} = we, pd = {}, zO = "refState", jO = (e = pd, t = {}) => {
			switch (t.type) {
				case WO:
					return pd;
				case HO: {
					let {
						elementId: n,
						element: r,
						origin: i,
						actionItem: o,
						refType: s
					} = t.payload, {
						actionTypeId: a
					} = o, u = e;
					return (0, Ut.getIn)(u, [n, r]) !== r && (u = gd(u, r, s, n, o)), io(u, n, a, i, o)
				}
				case BO: {
					let {
						elementId: n,
						actionTypeId: r,
						current: i,
						actionItem: o
					} = t.payload;
					return io(e, n, r, i, o)
				}
				default:
					return e
			}
		};
		KO = [
			[MO, GO],
			[FO, VO],
			[qO, XO],
			[kO, UO]
		]
	});
	var md = g(oo => {
		"use strict";
		Object.defineProperty(oo, "__esModule", {
			value: !0
		});

		function QO(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		QO(oo, {
			clearPlugin: function() {
				return rS
			},
			createPluginInstance: function() {
				return tS
			},
			getPluginConfig: function() {
				return $O
			},
			getPluginDestination: function() {
				return eS
			},
			getPluginDuration: function() {
				return ZO
			},
			getPluginOrigin: function() {
				return JO
			},
			renderPlugin: function() {
				return nS
			}
		});
		var $O = e => e.value,
			ZO = (e, t) => {
				if (t.config.duration !== "auto") return null;
				let n = parseFloat(e.getAttribute("data-duration"));
				return n > 0 ? n * 1e3 : parseFloat(e.getAttribute("data-default-duration")) * 1e3
			},
			JO = e => e || {
				value: 0
			},
			eS = e => ({
				value: e.value
			}),
			tS = e => {
				let t = window.Webflow.require("lottie").createInstance(e);
				return t.stop(), t.setSubframe(!0), t
			},
			nS = (e, t, n) => {
				if (!e) return;
				let r = t[n.actionTypeId].value / 100;
				e.goToFrame(e.frames * r)
			},
			rS = e => {
				window.Webflow.require("lottie").createInstance(e).stop()
			}
	});
	var Ed = g(ao => {
		"use strict";
		Object.defineProperty(ao, "__esModule", {
			value: !0
		});

		function iS(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		iS(ao, {
			clearPlugin: function() {
				return gS
			},
			createPluginInstance: function() {
				return dS
			},
			getPluginConfig: function() {
				return uS
			},
			getPluginDestination: function() {
				return fS
			},
			getPluginDuration: function() {
				return cS
			},
			getPluginOrigin: function() {
				return lS
			},
			renderPlugin: function() {
				return pS
			}
		});
		var oS = e => document.querySelector(`[data-w-id="${e}"]`),
			aS = () => window.Webflow.require("spline"),
			sS = (e, t) => e.filter(n => !t.includes(n)),
			uS = (e, t) => e.value[t],
			cS = () => null,
			yd = Object.freeze({
				positionX: 0,
				positionY: 0,
				positionZ: 0,
				rotationX: 0,
				rotationY: 0,
				rotationZ: 0,
				scaleX: 1,
				scaleY: 1,
				scaleZ: 1
			}),
			lS = (e, t) => {
				let n = t.config.value,
					r = Object.keys(n);
				if (e) {
					let o = Object.keys(e),
						s = sS(r, o);
					return s.length ? s.reduce((u, l) => (u[l] = yd[l], u), e) : e
				}
				return r.reduce((o, s) => (o[s] = yd[s], o), {})
			},
			fS = e => e.value,
			dS = (e, t) => {
				let n = t?.config?.target?.pluginElement;
				return n ? oS(n) : null
			},
			pS = (e, t, n) => {
				let r = aS(),
					i = r.getInstance(e),
					o = n.config.target.objectId,
					s = a => {
						if (!a) throw new Error("Invalid spline app passed to renderSpline");
						let u = o && a.findObjectById(o);
						if (!u) return;
						let {
							PLUGIN_SPLINE: l
						} = t;
						l.positionX != null && (u.position.x = l.positionX), l.positionY != null && (u.position.y = l.positionY), l.positionZ != null && (u.position.z = l.positionZ), l.rotationX != null && (u.rotation.x = l.rotationX), l.rotationY != null && (u.rotation.y = l.rotationY), l.rotationZ != null && (u.rotation.z = l.rotationZ), l.scaleX != null && (u.scale.x = l.scaleX), l.scaleY != null && (u.scale.y = l.scaleY), l.scaleZ != null && (u.scale.z = l.scaleZ)
					};
				i ? s(i.spline) : r.setLoadHandler(e, s)
			},
			gS = () => null
	});
	var _d = g(co => {
		"use strict";
		Object.defineProperty(co, "__esModule", {
			value: !0
		});

		function hS(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		hS(co, {
			clearPlugin: function() {
				return wS
			},
			createPluginInstance: function() {
				return bS
			},
			getPluginConfig: function() {
				return yS
			},
			getPluginDestination: function() {
				return IS
			},
			getPluginDuration: function() {
				return ES
			},
			getPluginOrigin: function() {
				return _S
			},
			renderPlugin: function() {
				return TS
			}
		});
		var so = "--wf-rive-fit",
			uo = "--wf-rive-alignment",
			vS = e => document.querySelector(`[data-w-id="${e}"]`),
			mS = () => window.Webflow.require("rive"),
			yS = (e, t) => e.value.inputs[t],
			ES = () => null,
			_S = (e, t) => {
				if (e) return e;
				let n = {},
					{
						inputs: r = {}
					} = t.config.value;
				for (let i in r) r[i] == null && (n[i] = 0);
				return n
			},
			IS = e => e.value.inputs ?? {},
			bS = (e, t) => {
				if ((t.config?.target?.selectorGuids || []).length > 0) return e;
				let r = t?.config?.target?.pluginElement;
				return r ? vS(r) : null
			},
			TS = (e, {
				PLUGIN_RIVE: t
			}, n) => {
				let r = mS(),
					i = r.getInstance(e),
					o = r.rive.StateMachineInputType,
					{
						name: s,
						inputs: a = {}
					} = n.config.value || {};

				function u(l) {
					if (l.loaded) _();
					else {
						let d = () => {
							_(), l?.off("load", d)
						};
						l?.on("load", d)
					}

					function _() {
						let d = l.stateMachineInputs(s);
						if (d != null) {
							if (l.isPlaying || l.play(s, !1), so in a || uo in a) {
								let m = l.layout,
									v = a[so] ?? m.fit,
									E = a[uo] ?? m.alignment;
								(v !== m.fit || E !== m.alignment) && (l.layout = m.copyWith({
									fit: v,
									alignment: E
								}))
							}
							for (let m in a) {
								if (m === so || m === uo) continue;
								let v = d.find(E => E.name === m);
								if (v != null) switch (v.type) {
									case o.Boolean: {
										if (a[m] != null) {
											let E = !!a[m];
											v.value = E
										}
										break
									}
									case o.Number: {
										let E = t[m];
										E != null && (v.value = E);
										break
									}
									case o.Trigger: {
										a[m] && v.fire();
										break
									}
								}
							}
						}
					}
				}
				i?.rive ? u(i.rive) : r.setLoadHandler(e, u)
			},
			wS = (e, t) => null
	});
	var fo = g(lo => {
		"use strict";
		Object.defineProperty(lo, "__esModule", {
			value: !0
		});
		Object.defineProperty(lo, "normalizeColor", {
			enumerable: !0,
			get: function() {
				return xS
			}
		});
		var Id = {
			aliceblue: "#F0F8FF",
			antiquewhite: "#FAEBD7",
			aqua: "#00FFFF",
			aquamarine: "#7FFFD4",
			azure: "#F0FFFF",
			beige: "#F5F5DC",
			bisque: "#FFE4C4",
			black: "#000000",
			blanchedalmond: "#FFEBCD",
			blue: "#0000FF",
			blueviolet: "#8A2BE2",
			brown: "#A52A2A",
			burlywood: "#DEB887",
			cadetblue: "#5F9EA0",
			chartreuse: "#7FFF00",
			chocolate: "#D2691E",
			coral: "#FF7F50",
			cornflowerblue: "#6495ED",
			cornsilk: "#FFF8DC",
			crimson: "#DC143C",
			cyan: "#00FFFF",
			darkblue: "#00008B",
			darkcyan: "#008B8B",
			darkgoldenrod: "#B8860B",
			darkgray: "#A9A9A9",
			darkgreen: "#006400",
			darkgrey: "#A9A9A9",
			darkkhaki: "#BDB76B",
			darkmagenta: "#8B008B",
			darkolivegreen: "#556B2F",
			darkorange: "#FF8C00",
			darkorchid: "#9932CC",
			darkred: "#8B0000",
			darksalmon: "#E9967A",
			darkseagreen: "#8FBC8F",
			darkslateblue: "#483D8B",
			darkslategray: "#2F4F4F",
			darkslategrey: "#2F4F4F",
			darkturquoise: "#00CED1",
			darkviolet: "#9400D3",
			deeppink: "#FF1493",
			deepskyblue: "#00BFFF",
			dimgray: "#696969",
			dimgrey: "#696969",
			dodgerblue: "#1E90FF",
			firebrick: "#B22222",
			floralwhite: "#FFFAF0",
			forestgreen: "#228B22",
			fuchsia: "#FF00FF",
			gainsboro: "#DCDCDC",
			ghostwhite: "#F8F8FF",
			gold: "#FFD700",
			goldenrod: "#DAA520",
			gray: "#808080",
			green: "#008000",
			greenyellow: "#ADFF2F",
			grey: "#808080",
			honeydew: "#F0FFF0",
			hotpink: "#FF69B4",
			indianred: "#CD5C5C",
			indigo: "#4B0082",
			ivory: "#FFFFF0",
			khaki: "#F0E68C",
			lavender: "#E6E6FA",
			lavenderblush: "#FFF0F5",
			lawngreen: "#7CFC00",
			lemonchiffon: "#FFFACD",
			lightblue: "#ADD8E6",
			lightcoral: "#F08080",
			lightcyan: "#E0FFFF",
			lightgoldenrodyellow: "#FAFAD2",
			lightgray: "#D3D3D3",
			lightgreen: "#90EE90",
			lightgrey: "#D3D3D3",
			lightpink: "#FFB6C1",
			lightsalmon: "#FFA07A",
			lightseagreen: "#20B2AA",
			lightskyblue: "#87CEFA",
			lightslategray: "#778899",
			lightslategrey: "#778899",
			lightsteelblue: "#B0C4DE",
			lightyellow: "#FFFFE0",
			lime: "#00FF00",
			limegreen: "#32CD32",
			linen: "#FAF0E6",
			magenta: "#FF00FF",
			maroon: "#800000",
			mediumaquamarine: "#66CDAA",
			mediumblue: "#0000CD",
			mediumorchid: "#BA55D3",
			mediumpurple: "#9370DB",
			mediumseagreen: "#3CB371",
			mediumslateblue: "#7B68EE",
			mediumspringgreen: "#00FA9A",
			mediumturquoise: "#48D1CC",
			mediumvioletred: "#C71585",
			midnightblue: "#191970",
			mintcream: "#F5FFFA",
			mistyrose: "#FFE4E1",
			moccasin: "#FFE4B5",
			navajowhite: "#FFDEAD",
			navy: "#000080",
			oldlace: "#FDF5E6",
			olive: "#808000",
			olivedrab: "#6B8E23",
			orange: "#FFA500",
			orangered: "#FF4500",
			orchid: "#DA70D6",
			palegoldenrod: "#EEE8AA",
			palegreen: "#98FB98",
			paleturquoise: "#AFEEEE",
			palevioletred: "#DB7093",
			papayawhip: "#FFEFD5",
			peachpuff: "#FFDAB9",
			peru: "#CD853F",
			pink: "#FFC0CB",
			plum: "#DDA0DD",
			powderblue: "#B0E0E6",
			purple: "#800080",
			rebeccapurple: "#663399",
			red: "#FF0000",
			rosybrown: "#BC8F8F",
			royalblue: "#4169E1",
			saddlebrown: "#8B4513",
			salmon: "#FA8072",
			sandybrown: "#F4A460",
			seagreen: "#2E8B57",
			seashell: "#FFF5EE",
			sienna: "#A0522D",
			silver: "#C0C0C0",
			skyblue: "#87CEEB",
			slateblue: "#6A5ACD",
			slategray: "#708090",
			slategrey: "#708090",
			snow: "#FFFAFA",
			springgreen: "#00FF7F",
			steelblue: "#4682B4",
			tan: "#D2B48C",
			teal: "#008080",
			thistle: "#D8BFD8",
			tomato: "#FF6347",
			turquoise: "#40E0D0",
			violet: "#EE82EE",
			wheat: "#F5DEB3",
			white: "#FFFFFF",
			whitesmoke: "#F5F5F5",
			yellow: "#FFFF00",
			yellowgreen: "#9ACD32"
		};

		function xS(e) {
			let t, n, r, i = 1,
				o = e.replace(/\s/g, "").toLowerCase(),
				a = (typeof Id[o] == "string" ? Id[o].toLowerCase() : null) || o;
			if (a.startsWith("#")) {
				let u = a.substring(1);
				u.length === 3 || u.length === 4 ? (t = parseInt(u[0] + u[0], 16), n = parseInt(u[1] + u[1], 16), r = parseInt(u[2] + u[2], 16), u.length === 4 && (i = parseInt(u[3] + u[3], 16) / 255)) : (u.length === 6 || u.length === 8) && (t = parseInt(u.substring(0, 2), 16), n = parseInt(u.substring(2, 4), 16), r = parseInt(u.substring(4, 6), 16), u.length === 8 && (i = parseInt(u.substring(6, 8), 16) / 255))
			} else if (a.startsWith("rgba")) {
				let u = a.match(/rgba\(([^)]+)\)/)[1].split(",");
				t = parseInt(u[0], 10), n = parseInt(u[1], 10), r = parseInt(u[2], 10), i = parseFloat(u[3])
			} else if (a.startsWith("rgb")) {
				let u = a.match(/rgb\(([^)]+)\)/)[1].split(",");
				t = parseInt(u[0], 10), n = parseInt(u[1], 10), r = parseInt(u[2], 10)
			} else if (a.startsWith("hsla")) {
				let u = a.match(/hsla\(([^)]+)\)/)[1].split(","),
					l = parseFloat(u[0]),
					_ = parseFloat(u[1].replace("%", "")) / 100,
					d = parseFloat(u[2].replace("%", "")) / 100;
				i = parseFloat(u[3]);
				let m = (1 - Math.abs(2 * d - 1)) * _,
					v = m * (1 - Math.abs(l / 60 % 2 - 1)),
					E = d - m / 2,
					b, x, T;
				l >= 0 && l < 60 ? (b = m, x = v, T = 0) : l >= 60 && l < 120 ? (b = v, x = m, T = 0) : l >= 120 && l < 180 ? (b = 0, x = m, T = v) : l >= 180 && l < 240 ? (b = 0, x = v, T = m) : l >= 240 && l < 300 ? (b = v, x = 0, T = m) : (b = m, x = 0, T = v), t = Math.round((b + E) * 255), n = Math.round((x + E) * 255), r = Math.round((T + E) * 255)
			} else if (a.startsWith("hsl")) {
				let u = a.match(/hsl\(([^)]+)\)/)[1].split(","),
					l = parseFloat(u[0]),
					_ = parseFloat(u[1].replace("%", "")) / 100,
					d = parseFloat(u[2].replace("%", "")) / 100,
					m = (1 - Math.abs(2 * d - 1)) * _,
					v = m * (1 - Math.abs(l / 60 % 2 - 1)),
					E = d - m / 2,
					b, x, T;
				l >= 0 && l < 60 ? (b = m, x = v, T = 0) : l >= 60 && l < 120 ? (b = v, x = m, T = 0) : l >= 120 && l < 180 ? (b = 0, x = m, T = v) : l >= 180 && l < 240 ? (b = 0, x = v, T = m) : l >= 240 && l < 300 ? (b = v, x = 0, T = m) : (b = m, x = 0, T = v), t = Math.round((b + E) * 255), n = Math.round((x + E) * 255), r = Math.round((T + E) * 255)
			}
			if (Number.isNaN(t) || Number.isNaN(n) || Number.isNaN(r)) throw new Error(`Invalid color in [ix2/shared/utils/normalizeColor.js] '${e}'`);
			return {
				red: t,
				green: n,
				blue: r,
				alpha: i
			}
		}
	});
	var bd = g(po => {
		"use strict";
		Object.defineProperty(po, "__esModule", {
			value: !0
		});

		function AS(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		AS(po, {
			clearPlugin: function() {
				return MS
			},
			createPluginInstance: function() {
				return PS
			},
			getPluginConfig: function() {
				return SS
			},
			getPluginDestination: function() {
				return LS
			},
			getPluginDuration: function() {
				return RS
			},
			getPluginOrigin: function() {
				return CS
			},
			renderPlugin: function() {
				return DS
			}
		});
		var OS = fo(),
			SS = (e, t) => e.value[t],
			RS = () => null,
			CS = (e, t) => {
				if (e) return e;
				let n = t.config.value,
					r = t.config.target.objectId,
					i = getComputedStyle(document.documentElement).getPropertyValue(r);
				if (n.size != null) return {
					size: parseInt(i, 10)
				};
				if (n.unit === "%" || n.unit === "-") return {
					size: parseFloat(i)
				};
				if (n.red != null && n.green != null && n.blue != null) return (0, OS.normalizeColor)(i)
			},
			LS = e => e.value,
			PS = () => null,
			NS = {
				color: {
					match: ({
						red: e,
						green: t,
						blue: n,
						alpha: r
					}) => [e, t, n, r].every(i => i != null),
					getValue: ({
						red: e,
						green: t,
						blue: n,
						alpha: r
					}) => `rgba(${e}, ${t}, ${n}, ${r})`
				},
				size: {
					match: ({
						size: e
					}) => e != null,
					getValue: ({
						size: e
					}, t) => {
						switch (t) {
							case "-":
								return e;
							default:
								return `${e}${t}`
						}
					}
				}
			},
			DS = (e, t, n) => {
				let {
					target: {
						objectId: r
					},
					value: {
						unit: i
					}
				} = n.config, o = t.PLUGIN_VARIABLE, s = Object.values(NS).find(a => a.match(o, i));
				s && document.documentElement.style.setProperty(r, s.getValue(o, i))
			},
			MS = (e, t) => {
				let n = t.config.target.objectId;
				document.documentElement.style.removeProperty(n)
			}
	});
	var wd = g(go => {
		"use strict";
		Object.defineProperty(go, "__esModule", {
			value: !0
		});
		Object.defineProperty(go, "pluginMethodMap", {
			enumerable: !0,
			get: function() {
				return VS
			}
		});
		var Er = (qe(), $e(Os)),
			FS = _r(md()),
			qS = _r(Ed()),
			kS = _r(_d()),
			GS = _r(bd());

		function Td(e) {
			if (typeof WeakMap != "function") return null;
			var t = new WeakMap,
				n = new WeakMap;
			return (Td = function(r) {
				return r ? n : t
			})(e)
		}

		function _r(e, t) {
			if (!t && e && e.__esModule) return e;
			if (e === null || typeof e != "object" && typeof e != "function") return {
				default: e
			};
			var n = Td(t);
			if (n && n.has(e)) return n.get(e);
			var r = {
					__proto__: null
				},
				i = Object.defineProperty && Object.getOwnPropertyDescriptor;
			for (var o in e)
				if (o !== "default" && Object.prototype.hasOwnProperty.call(e, o)) {
					var s = i ? Object.getOwnPropertyDescriptor(e, o) : null;
					s && (s.get || s.set) ? Object.defineProperty(r, o, s) : r[o] = e[o]
				} return r.default = e, n && n.set(e, r), r
		}
		var VS = new Map([
			[Er.ActionTypeConsts.PLUGIN_LOTTIE, {
				...FS
			}],
			[Er.ActionTypeConsts.PLUGIN_SPLINE, {
				...qS
			}],
			[Er.ActionTypeConsts.PLUGIN_RIVE, {
				...kS
			}],
			[Er.ActionTypeConsts.PLUGIN_VARIABLE, {
				...GS
			}]
		])
	});
	var xd = {};
	Fe(xd, {
		clearPlugin: () => _o,
		createPluginInstance: () => US,
		getPluginConfig: () => vo,
		getPluginDestination: () => yo,
		getPluginDuration: () => XS,
		getPluginOrigin: () => mo,
		isPluginType: () => bt,
		renderPlugin: () => Eo
	});

	function bt(e) {
		return ho.pluginMethodMap.has(e)
	}
	var ho, Tt, vo, mo, XS, yo, US, Eo, _o, Io = ye(() => {
		"use strict";
		vr();
		ho = ge(wd());
		Tt = e => t => {
			if (!Ke) return () => null;
			let n = ho.pluginMethodMap.get(t);
			if (!n) throw new Error(`IX2 no plugin configured for: ${t}`);
			let r = n[e];
			if (!r) throw new Error(`IX2 invalid plugin method: ${e}`);
			return r
		}, vo = Tt("getPluginConfig"), mo = Tt("getPluginOrigin"), XS = Tt("getPluginDuration"), yo = Tt("getPluginDestination"), US = Tt("createPluginInstance"), Eo = Tt("renderPlugin"), _o = Tt("clearPlugin")
	});
	var Od = g((fk, Ad) => {
		function WS(e, t) {
			return e == null || e !== e ? t : e
		}
		Ad.exports = WS
	});
	var Rd = g((dk, Sd) => {
		function HS(e, t, n, r) {
			var i = -1,
				o = e == null ? 0 : e.length;
			for (r && o && (n = e[++i]); ++i < o;) n = t(n, e[i], i, e);
			return n
		}
		Sd.exports = HS
	});
	var Ld = g((pk, Cd) => {
		function BS(e) {
			return function(t, n, r) {
				for (var i = -1, o = Object(t), s = r(t), a = s.length; a--;) {
					var u = s[e ? a : ++i];
					if (n(o[u], u, o) === !1) break
				}
				return t
			}
		}
		Cd.exports = BS
	});
	var Nd = g((gk, Pd) => {
		var zS = Ld(),
			jS = zS();
		Pd.exports = jS
	});
	var bo = g((hk, Dd) => {
		var KS = Nd(),
			YS = vn();

		function QS(e, t) {
			return e && KS(e, t, YS)
		}
		Dd.exports = QS
	});
	var Fd = g((vk, Md) => {
		var $S = _t();

		function ZS(e, t) {
			return function(n, r) {
				if (n == null) return n;
				if (!$S(n)) return e(n, r);
				for (var i = n.length, o = t ? i : -1, s = Object(n);
					(t ? o-- : ++o < i) && r(s[o], o, s) !== !1;);
				return n
			}
		}
		Md.exports = ZS
	});
	var To = g((mk, qd) => {
		var JS = bo(),
			eR = Fd(),
			tR = eR(JS);
		qd.exports = tR
	});
	var Gd = g((yk, kd) => {
		function nR(e, t, n, r, i) {
			return i(e, function(o, s, a) {
				n = r ? (r = !1, o) : t(n, o, s, a)
			}), n
		}
		kd.exports = nR
	});
	var Xd = g((Ek, Vd) => {
		var rR = Rd(),
			iR = To(),
			oR = gt(),
			aR = Gd(),
			sR = Ae();

		function uR(e, t, n) {
			var r = sR(e) ? rR : aR,
				i = arguments.length < 3;
			return r(e, oR(t, 4), n, i, iR)
		}
		Vd.exports = uR
	});
	var Wd = g((_k, Ud) => {
		var cR = $i(),
			lR = gt(),
			fR = Zi(),
			dR = Math.max,
			pR = Math.min;

		function gR(e, t, n) {
			var r = e == null ? 0 : e.length;
			if (!r) return -1;
			var i = r - 1;
			return n !== void 0 && (i = fR(n), i = n < 0 ? dR(r + i, 0) : pR(i, r - 1)), cR(e, lR(t, 3), i, !0)
		}
		Ud.exports = gR
	});
	var Bd = g((Ik, Hd) => {
		var hR = Qi(),
			vR = Wd(),
			mR = hR(vR);
		Hd.exports = mR
	});

	function zd(e, t) {
		return e === t ? e !== 0 || t !== 0 || 1 / e === 1 / t : e !== e && t !== t
	}

	function yR(e, t) {
		if (zd(e, t)) return !0;
		if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
		let n = Object.keys(e),
			r = Object.keys(t);
		if (n.length !== r.length) return !1;
		for (let i = 0; i < n.length; i++)
			if (!Object.hasOwn(t, n[i]) || !zd(e[n[i]], t[n[i]])) return !1;
		return !0
	}
	var wo, jd = ye(() => {
		"use strict";
		wo = yR
	});
	var fp = {};
	Fe(fp, {
		cleanupHTMLElement: () => hC,
		clearAllStyles: () => gC,
		clearObjectCache: () => MR,
		getActionListProgress: () => mC,
		getAffectedElements: () => Ro,
		getComputedStyle: () => WR,
		getDestinationValues: () => QR,
		getElementId: () => GR,
		getInstanceId: () => qR,
		getInstanceOrigin: () => zR,
		getItemConfigByKey: () => YR,
		getMaxDurationItemIndex: () => lp,
		getNamespacedParameterId: () => _C,
		getRenderType: () => sp,
		getStyleProp: () => $R,
		mediaQueriesEqual: () => bC,
		observeStore: () => UR,
		reduceListToGroup: () => yC,
		reifyState: () => VR,
		renderHTMLElement: () => ZR,
		shallowEqual: () => wo,
		shouldAllowMediaQuery: () => IC,
		shouldNamespaceEventParameter: () => EC,
		stringifyTarget: () => TC
	});

	function MR() {
		Ir.clear()
	}

	function qR() {
		return "i" + FR++
	}

	function GR(e, t) {
		for (let n in e) {
			let r = e[n];
			if (r && r.ref === t) return r.id
		}
		return "e" + kR++
	}

	function VR({
		events: e,
		actionLists: t,
		site: n
	} = {}) {
		let r = (0, xr.default)(e, (s, a) => {
				let {
					eventTypeId: u
				} = a;
				return s[u] || (s[u] = {}), s[u][a.id] = a, s
			}, {}),
			i = n && n.mediaQueries,
			o = [];
		return i ? o = i.map(s => s.key) : (i = [], console.warn("IX2 missing mediaQueries in site data")), {
			ixData: {
				events: e,
				actionLists: t,
				eventTypeMap: r,
				mediaQueries: i,
				mediaQueryKeys: o
			}
		}
	}

	function UR({
		store: e,
		select: t,
		onChange: n,
		comparator: r = XR
	}) {
		let {
			getState: i,
			subscribe: o
		} = e, s = o(u), a = t(i());

		function u() {
			let l = t(i());
			if (l == null) {
				s();
				return
			}
			r(l, a) || (a = l, n(a, e))
		}
		return s
	}

	function Qd(e) {
		let t = typeof e;
		if (t === "string") return {
			id: e
		};
		if (e != null && t === "object") {
			let {
				id: n,
				objectId: r,
				selector: i,
				selectorGuids: o,
				appliesTo: s,
				useEventTarget: a
			} = e;
			return {
				id: n,
				objectId: r,
				selector: i,
				selectorGuids: o,
				appliesTo: s,
				useEventTarget: a
			}
		}
		return {}
	}

	function Ro({
		config: e,
		event: t,
		eventTarget: n,
		elementRoot: r,
		elementApi: i
	}) {
		if (!i) throw new Error("IX2 missing elementApi");
		let {
			targets: o
		} = e;
		if (Array.isArray(o) && o.length > 0) return o.reduce((V, S) => V.concat(Ro({
			config: {
				target: S
			},
			event: t,
			eventTarget: n,
			elementRoot: r,
			elementApi: i
		})), []);
		let {
			getValidDocument: s,
			getQuerySelector: a,
			queryDocument: u,
			getChildElements: l,
			getSiblingElements: _,
			matchSelector: d,
			elementContains: m,
			isSiblingNode: v
		} = i, {
			target: E
		} = e;
		if (!E) return [];
		let {
			id: b,
			objectId: x,
			selector: T,
			selectorGuids: L,
			appliesTo: P,
			useEventTarget: D
		} = Qd(E);
		if (x) return [Ir.has(x) ? Ir.get(x) : Ir.set(x, {}).get(x)];
		if (P === bi.PAGE) {
			let V = s(b);
			return V ? [V] : []
		}
		let M = (t?.action?.config?.affectedElements ?? {})[b || T] || {},
			Y = !!(M.id || M.selector),
			K, Q, ee, ne = t && a(Qd(t.target));
		if (Y ? (K = M.limitAffectedElements, Q = ne, ee = a(M)) : Q = ee = a({
				id: b,
				selector: T,
				selectorGuids: L
			}), t && D) {
			let V = n && (ee || D === !0) ? [n] : u(ne);
			if (ee) {
				if (D === PR) return u(ee).filter(S => V.some(q => m(S, q)));
				if (D === Kd) return u(ee).filter(S => V.some(q => m(q, S)));
				if (D === Yd) return u(ee).filter(S => V.some(q => v(q, S)))
			}
			return V
		}
		return Q == null || ee == null ? [] : Ke && r ? u(ee).filter(V => r.contains(V)) : K === Kd ? u(Q, ee) : K === LR ? l(u(Q)).filter(d(ee)) : K === Yd ? _(u(Q)).filter(d(ee)) : u(ee)
	}

	function WR({
		element: e,
		actionItem: t
	}) {
		if (!Ke) return {};
		let {
			actionTypeId: n
		} = t;
		switch (n) {
			case jt:
			case Kt:
			case Yt:
			case Qt:
			case Or:
				return window.getComputedStyle(e);
			default:
				return {}
		}
	}

	function zR(e, t = {}, n = {}, r, i) {
		let {
			getStyle: o
		} = i, {
			actionTypeId: s
		} = r;
		if (bt(s)) return mo(s)(t[s], r);
		switch (r.actionTypeId) {
			case Ht:
			case Bt:
			case zt:
			case An:
				return t[r.actionTypeId] || Co[r.actionTypeId];
			case On:
				return HR(t[r.actionTypeId], r.config.filters);
			case Sn:
				return BR(t[r.actionTypeId], r.config.fontVariations);
			case ip:
				return {
					value: (0, ut.default)(parseFloat(o(e, Tr)), 1)
				};
			case jt: {
				let a = o(e, nt),
					u = o(e, rt),
					l, _;
				return r.config.widthUnit === vt ? l = $d.test(a) ? parseFloat(a) : parseFloat(n.width) : l = (0, ut.default)(parseFloat(a), parseFloat(n.width)), r.config.heightUnit === vt ? _ = $d.test(u) ? parseFloat(u) : parseFloat(n.height) : _ = (0, ut.default)(parseFloat(u), parseFloat(n.height)), {
					widthValue: l,
					heightValue: _
				}
			}
			case Kt:
			case Yt:
			case Qt:
				return fC({
					element: e,
					actionTypeId: r.actionTypeId,
					computedStyle: n,
					getStyle: o
				});
			case Or:
				return {
					value: (0, ut.default)(o(e, wr), n.display)
				};
			case DR:
				return t[r.actionTypeId] || {
					value: 0
				};
			default:
				return
		}
	}

	function QR({
		element: e,
		actionItem: t,
		elementApi: n
	}) {
		if (bt(t.actionTypeId)) return yo(t.actionTypeId)(t.config);
		switch (t.actionTypeId) {
			case Ht:
			case Bt:
			case zt:
			case An: {
				let {
					xValue: r,
					yValue: i,
					zValue: o
				} = t.config;
				return {
					xValue: r,
					yValue: i,
					zValue: o
				}
			}
			case jt: {
				let {
					getStyle: r,
					setStyle: i,
					getProperty: o
				} = n, {
					widthUnit: s,
					heightUnit: a
				} = t.config, {
					widthValue: u,
					heightValue: l
				} = t.config;
				if (!Ke) return {
					widthValue: u,
					heightValue: l
				};
				if (s === vt) {
					let _ = r(e, nt);
					i(e, nt, ""), u = o(e, "offsetWidth"), i(e, nt, _)
				}
				if (a === vt) {
					let _ = r(e, rt);
					i(e, rt, ""), l = o(e, "offsetHeight"), i(e, rt, _)
				}
				return {
					widthValue: u,
					heightValue: l
				}
			}
			case Kt:
			case Yt:
			case Qt: {
				let {
					rValue: r,
					gValue: i,
					bValue: o,
					aValue: s,
					globalSwatchId: a
				} = t.config;
				if (a && a.startsWith("--")) {
					let {
						getStyle: u
					} = n, l = u(e, a), _ = (0, ep.normalizeColor)(l);
					return {
						rValue: _.red,
						gValue: _.green,
						bValue: _.blue,
						aValue: _.alpha
					}
				}
				return {
					rValue: r,
					gValue: i,
					bValue: o,
					aValue: s
				}
			}
			case On:
				return t.config.filters.reduce(jR, {});
			case Sn:
				return t.config.fontVariations.reduce(KR, {});
			default: {
				let {
					value: r
				} = t.config;
				return {
					value: r
				}
			}
		}
	}

	function sp(e) {
		if (/^TRANSFORM_/.test(e)) return np;
		if (/^STYLE_/.test(e)) return Oo;
		if (/^GENERAL_/.test(e)) return Ao;
		if (/^PLUGIN_/.test(e)) return rp
	}

	function $R(e, t) {
		return e === Oo ? t.replace("STYLE_", "").toLowerCase() : null
	}

	function ZR(e, t, n, r, i, o, s, a, u) {
		switch (a) {
			case np:
				return rC(e, t, n, i, s);
			case Oo:
				return dC(e, t, n, i, o, s);
			case Ao:
				return pC(e, i, s);
			case rp: {
				let {
					actionTypeId: l
				} = i;
				if (bt(l)) return Eo(l)(u, t, i)
			}
		}
	}

	function rC(e, t, n, r, i) {
		let o = nC.map(a => {
				let u = Co[a],
					{
						xValue: l = u.xValue,
						yValue: _ = u.yValue,
						zValue: d = u.zValue,
						xUnit: m = "",
						yUnit: v = "",
						zUnit: E = ""
					} = t[a] || {};
				switch (a) {
					case Ht:
						return `${IR}(${l}${m}, ${_}${v}, ${d}${E})`;
					case Bt:
						return `${bR}(${l}${m}, ${_}${v}, ${d}${E})`;
					case zt:
						return `${TR}(${l}${m}) ${wR}(${_}${v}) ${xR}(${d}${E})`;
					case An:
						return `${AR}(${l}${m}, ${_}${v})`;
					default:
						return ""
				}
			}).join(" "),
			{
				setStyle: s
			} = i;
		wt(e, ht, i), s(e, ht, o), aC(r, n) && s(e, hr, OR)
	}

	function iC(e, t, n, r) {
		let i = (0, xr.default)(t, (s, a, u) => `${s} ${u}(${a}${tC(u,n)})`, ""),
			{
				setStyle: o
			} = r;
		wt(e, Tn, r), o(e, Tn, i)
	}

	function oC(e, t, n, r) {
		let i = (0, xr.default)(t, (s, a, u) => (s.push(`"${u}" ${a}`), s), []).join(", "),
			{
				setStyle: o
			} = r;
		wt(e, wn, r), o(e, wn, i)
	}

	function aC({
		actionTypeId: e
	}, {
		xValue: t,
		yValue: n,
		zValue: r
	}) {
		return e === Ht && r !== void 0 || e === Bt && r !== void 0 || e === zt && (t !== void 0 || n !== void 0)
	}

	function lC(e, t) {
		let n = e.exec(t);
		return n ? n[1] : ""
	}

	function fC({
		element: e,
		actionTypeId: t,
		computedStyle: n,
		getStyle: r
	}) {
		let i = So[t],
			o = r(e, i),
			s = uC.test(o) ? o : n[i],
			a = lC(cC, s).split(xn);
		return {
			rValue: (0, ut.default)(parseInt(a[0], 10), 255),
			gValue: (0, ut.default)(parseInt(a[1], 10), 255),
			bValue: (0, ut.default)(parseInt(a[2], 10), 255),
			aValue: (0, ut.default)(parseFloat(a[3]), 1)
		}
	}

	function dC(e, t, n, r, i, o) {
		let {
			setStyle: s
		} = o;
		switch (r.actionTypeId) {
			case jt: {
				let {
					widthUnit: a = "",
					heightUnit: u = ""
				} = r.config, {
					widthValue: l,
					heightValue: _
				} = n;
				l !== void 0 && (a === vt && (a = "px"), wt(e, nt, o), s(e, nt, l + a)), _ !== void 0 && (u === vt && (u = "px"), wt(e, rt, o), s(e, rt, _ + u));
				break
			}
			case On: {
				iC(e, n, r.config, o);
				break
			}
			case Sn: {
				oC(e, n, r.config, o);
				break
			}
			case Kt:
			case Yt:
			case Qt: {
				let a = So[r.actionTypeId],
					u = Math.round(n.rValue),
					l = Math.round(n.gValue),
					_ = Math.round(n.bValue),
					d = n.aValue;
				wt(e, a, o), s(e, a, d >= 1 ? `rgb(${u},${l},${_})` : `rgba(${u},${l},${_},${d})`);
				break
			}
			default: {
				let {
					unit: a = ""
				} = r.config;
				wt(e, i, o), s(e, i, n.value + a);
				break
			}
		}
	}

	function pC(e, t, n) {
		let {
			setStyle: r
		} = n;
		switch (t.actionTypeId) {
			case Or: {
				let {
					value: i
				} = t.config;
				i === SR && Ke ? r(e, wr, eo) : r(e, wr, i);
				return
			}
		}
	}

	function wt(e, t, n) {
		if (!Ke) return;
		let r = ap[t];
		if (!r) return;
		let {
			getStyle: i,
			setStyle: o
		} = n, s = i(e, Wt);
		if (!s) {
			o(e, Wt, r);
			return
		}
		let a = s.split(xn).map(op);
		a.indexOf(r) === -1 && o(e, Wt, a.concat(r).join(xn))
	}

	function up(e, t, n) {
		if (!Ke) return;
		let r = ap[t];
		if (!r) return;
		let {
			getStyle: i,
			setStyle: o
		} = n, s = i(e, Wt);
		!s || s.indexOf(r) === -1 || o(e, Wt, s.split(xn).map(op).filter(a => a !== r).join(xn))
	}

	function gC({
		store: e,
		elementApi: t
	}) {
		let {
			ixData: n
		} = e.getState(), {
			events: r = {},
			actionLists: i = {}
		} = n;
		Object.keys(r).forEach(o => {
			let s = r[o],
				{
					config: a
				} = s.action,
				{
					actionListId: u
				} = a,
				l = i[u];
			l && Zd({
				actionList: l,
				event: s,
				elementApi: t
			})
		}), Object.keys(i).forEach(o => {
			Zd({
				actionList: i[o],
				elementApi: t
			})
		})
	}

	function Zd({
		actionList: e = {},
		event: t,
		elementApi: n
	}) {
		let {
			actionItemGroups: r,
			continuousParameterGroups: i
		} = e;
		r && r.forEach(o => {
			Jd({
				actionGroup: o,
				event: t,
				elementApi: n
			})
		}), i && i.forEach(o => {
			let {
				continuousActionGroups: s
			} = o;
			s.forEach(a => {
				Jd({
					actionGroup: a,
					event: t,
					elementApi: n
				})
			})
		})
	}

	function Jd({
		actionGroup: e,
		event: t,
		elementApi: n
	}) {
		let {
			actionItems: r
		} = e;
		r.forEach(i => {
			let {
				actionTypeId: o,
				config: s
			} = i, a;
			bt(o) ? a = u => _o(o)(u, i) : a = cp({
				effect: vC,
				actionTypeId: o,
				elementApi: n
			}), Ro({
				config: s,
				event: t,
				elementApi: n
			}).forEach(a)
		})
	}

	function hC(e, t, n) {
		let {
			setStyle: r,
			getStyle: i
		} = n, {
			actionTypeId: o
		} = t;
		if (o === jt) {
			let {
				config: s
			} = t;
			s.widthUnit === vt && r(e, nt, ""), s.heightUnit === vt && r(e, rt, "")
		}
		i(e, Wt) && cp({
			effect: up,
			actionTypeId: o,
			elementApi: n
		})(e)
	}

	function vC(e, t, n) {
		let {
			setStyle: r
		} = n;
		up(e, t, n), r(e, t, ""), t === ht && r(e, hr, "")
	}

	function lp(e) {
		let t = 0,
			n = 0;
		return e.forEach((r, i) => {
			let {
				config: o
			} = r, s = o.delay + o.duration;
			s >= t && (t = s, n = i)
		}), n
	}

	function mC(e, t) {
		let {
			actionItemGroups: n,
			useFirstGroupAsInitialState: r
		} = e, {
			actionItem: i,
			verboseTimeElapsed: o = 0
		} = t, s = 0, a = 0;
		return n.forEach((u, l) => {
			if (r && l === 0) return;
			let {
				actionItems: _
			} = u, d = _[lp(_)], {
				config: m,
				actionTypeId: v
			} = d;
			i.id === d.id && (a = s + o);
			let E = sp(v) === Ao ? 0 : m.duration;
			s += m.delay + E
		}), s > 0 ? bn(a / s) : 0
	}

	function yC({
		actionList: e,
		actionItemId: t,
		rawData: n
	}) {
		let {
			actionItemGroups: r,
			continuousParameterGroups: i
		} = e, o = [], s = a => (o.push((0, Ar.mergeIn)(a, ["config"], {
			delay: 0,
			duration: 0
		})), a.id === t);
		return r && r.some(({
			actionItems: a
		}) => a.some(s)), i && i.some(a => {
			let {
				continuousActionGroups: u
			} = a;
			return u.some(({
				actionItems: l
			}) => l.some(s))
		}), (0, Ar.setIn)(n, ["actionLists"], {
			[e.id]: {
				id: e.id,
				actionItemGroups: [{
					actionItems: o
				}]
			}
		})
	}

	function EC(e, {
		basedOn: t
	}) {
		return e === je.SCROLLING_IN_VIEW && (t === et.ELEMENT || t == null) || e === je.MOUSE_MOVE && t === et.ELEMENT
	}

	function _C(e, t) {
		return e + NR + t
	}

	function IC(e, t) {
		return t == null ? !0 : e.indexOf(t) !== -1
	}

	function bC(e, t) {
		return wo(e && e.sort(), t && t.sort())
	}

	function TC(e) {
		if (typeof e == "string") return e;
		if (e.pluginElement && e.objectId) return e.pluginElement + xo + e.objectId;
		if (e.objectId) return e.objectId;
		let {
			id: t = "",
			selector: n = "",
			useEventTarget: r = ""
		} = e;
		return t + xo + n + xo + r
	}
	var ut, xr, br, Ar, ep, ER, _R, IR, bR, TR, wR, xR, AR, OR, SR, Tr, Tn, wn, nt, rt, tp, RR, CR, Kd, LR, Yd, PR, wr, Wt, vt, xn, NR, xo, np, Ao, Oo, rp, Ht, Bt, zt, An, ip, On, Sn, jt, Kt, Yt, Qt, Or, DR, op, So, ap, Ir, FR, kR, XR, $d, HR, BR, jR, KR, YR, Co, JR, eC, tC, nC, sC, uC, cC, cp, dp = ye(() => {
		"use strict";
		ut = ge(Od()), xr = ge(Xd()), br = ge(Bd()), Ar = ge(Nt());
		qe();
		jd();
		ro();
		ep = ge(fo());
		Io();
		vr();
		({
			BACKGROUND: ER,
			TRANSFORM: _R,
			TRANSLATE_3D: IR,
			SCALE_3D: bR,
			ROTATE_X: TR,
			ROTATE_Y: wR,
			ROTATE_Z: xR,
			SKEW: AR,
			PRESERVE_3D: OR,
			FLEX: SR,
			OPACITY: Tr,
			FILTER: Tn,
			FONT_VARIATION_SETTINGS: wn,
			WIDTH: nt,
			HEIGHT: rt,
			BACKGROUND_COLOR: tp,
			BORDER_COLOR: RR,
			COLOR: CR,
			CHILDREN: Kd,
			IMMEDIATE_CHILDREN: LR,
			SIBLINGS: Yd,
			PARENT: PR,
			DISPLAY: wr,
			WILL_CHANGE: Wt,
			AUTO: vt,
			COMMA_DELIMITER: xn,
			COLON_DELIMITER: NR,
			BAR_DELIMITER: xo,
			RENDER_TRANSFORM: np,
			RENDER_GENERAL: Ao,
			RENDER_STYLE: Oo,
			RENDER_PLUGIN: rp
		} = Se), {
			TRANSFORM_MOVE: Ht,
			TRANSFORM_SCALE: Bt,
			TRANSFORM_ROTATE: zt,
			TRANSFORM_SKEW: An,
			STYLE_OPACITY: ip,
			STYLE_FILTER: On,
			STYLE_FONT_VARIATION: Sn,
			STYLE_SIZE: jt,
			STYLE_BACKGROUND_COLOR: Kt,
			STYLE_BORDER: Yt,
			STYLE_TEXT_COLOR: Qt,
			GENERAL_DISPLAY: Or,
			OBJECT_VALUE: DR
		} = Pe, op = e => e.trim(), So = Object.freeze({
			[Kt]: tp,
			[Yt]: RR,
			[Qt]: CR
		}), ap = Object.freeze({
			[ht]: _R,
			[tp]: ER,
			[Tr]: Tr,
			[Tn]: Tn,
			[nt]: nt,
			[rt]: rt,
			[wn]: wn
		}), Ir = new Map;
		FR = 1;
		kR = 1;
		XR = (e, t) => e === t;
		$d = /px/, HR = (e, t) => t.reduce((n, r) => (n[r.type] == null && (n[r.type] = JR[r.type]), n), e || {}), BR = (e, t) => t.reduce((n, r) => (n[r.type] == null && (n[r.type] = eC[r.type] || r.defaultValue || 0), n), e || {});
		jR = (e, t) => (t && (e[t.type] = t.value || 0), e), KR = (e, t) => (t && (e[t.type] = t.value || 0), e), YR = (e, t, n) => {
			if (bt(e)) return vo(e)(n, t);
			switch (e) {
				case On: {
					let r = (0, br.default)(n.filters, ({
						type: i
					}) => i === t);
					return r ? r.value : 0
				}
				case Sn: {
					let r = (0, br.default)(n.fontVariations, ({
						type: i
					}) => i === t);
					return r ? r.value : 0
				}
				default:
					return n[t]
			}
		};
		Co = {
			[Ht]: Object.freeze({
				xValue: 0,
				yValue: 0,
				zValue: 0
			}),
			[Bt]: Object.freeze({
				xValue: 1,
				yValue: 1,
				zValue: 1
			}),
			[zt]: Object.freeze({
				xValue: 0,
				yValue: 0,
				zValue: 0
			}),
			[An]: Object.freeze({
				xValue: 0,
				yValue: 0
			})
		}, JR = Object.freeze({
			blur: 0,
			"hue-rotate": 0,
			invert: 0,
			grayscale: 0,
			saturate: 100,
			sepia: 0,
			contrast: 100,
			brightness: 100
		}), eC = Object.freeze({
			wght: 0,
			opsz: 0,
			wdth: 0,
			slnt: 0
		}), tC = (e, t) => {
			let n = (0, br.default)(t.filters, ({
				type: r
			}) => r === e);
			if (n && n.unit) return n.unit;
			switch (e) {
				case "blur":
					return "px";
				case "hue-rotate":
					return "deg";
				default:
					return "%"
			}
		}, nC = Object.keys(Co);
		sC = "\\(([^)]+)\\)", uC = /^rgb/, cC = RegExp(`rgba?${sC}`);
		cp = ({
			effect: e,
			actionTypeId: t,
			elementApi: n
		}) => r => {
			switch (t) {
				case Ht:
				case Bt:
				case zt:
				case An:
					e(r, ht, n);
					break;
				case On:
					e(r, Tn, n);
					break;
				case Sn:
					e(r, wn, n);
					break;
				case ip:
					e(r, Tr, n);
					break;
				case jt:
					e(r, nt, n), e(r, rt, n);
					break;
				case Kt:
				case Yt:
				case Qt:
					e(r, So[t], n);
					break;
				case Or:
					e(r, wr, n);
					break
			}
		}
	});
	var xt = g(Lo => {
		"use strict";
		Object.defineProperty(Lo, "__esModule", {
			value: !0
		});

		function wC(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		wC(Lo, {
			IX2BrowserSupport: function() {
				return xC
			},
			IX2EasingUtils: function() {
				return OC
			},
			IX2Easings: function() {
				return AC
			},
			IX2ElementsReducer: function() {
				return SC
			},
			IX2VanillaPlugins: function() {
				return RC
			},
			IX2VanillaUtils: function() {
				return CC
			}
		});
		var xC = $t((vr(), $e(od))),
			AC = $t((no(), $e(In))),
			OC = $t((ro(), $e(dd))),
			SC = $t((vd(), $e(hd))),
			RC = $t((Io(), $e(xd))),
			CC = $t((dp(), $e(fp)));

		function pp(e) {
			if (typeof WeakMap != "function") return null;
			var t = new WeakMap,
				n = new WeakMap;
			return (pp = function(r) {
				return r ? n : t
			})(e)
		}

		function $t(e, t) {
			if (!t && e && e.__esModule) return e;
			if (e === null || typeof e != "object" && typeof e != "function") return {
				default: e
			};
			var n = pp(t);
			if (n && n.has(e)) return n.get(e);
			var r = {
					__proto__: null
				},
				i = Object.defineProperty && Object.getOwnPropertyDescriptor;
			for (var o in e)
				if (o !== "default" && Object.prototype.hasOwnProperty.call(e, o)) {
					var s = i ? Object.getOwnPropertyDescriptor(e, o) : null;
					s && (s.get || s.set) ? Object.defineProperty(r, o, s) : r[o] = e[o]
				} return r.default = e, n && n.set(e, r), r
		}
	});
	var Rr, ct, LC, PC, NC, DC, MC, FC, Sr, gp, qC, kC, Po, GC, VC, XC, UC, hp, vp = ye(() => {
		"use strict";
		qe();
		Rr = ge(xt()), ct = ge(Nt()), {
			IX2_RAW_DATA_IMPORTED: LC,
			IX2_SESSION_STOPPED: PC,
			IX2_INSTANCE_ADDED: NC,
			IX2_INSTANCE_STARTED: DC,
			IX2_INSTANCE_REMOVED: MC,
			IX2_ANIMATION_FRAME_CHANGED: FC
		} = we, {
			optimizeFloat: Sr,
			applyEasing: gp,
			createBezierEasing: qC
		} = Rr.IX2EasingUtils, {
			RENDER_GENERAL: kC
		} = Se, {
			getItemConfigByKey: Po,
			getRenderType: GC,
			getStyleProp: VC
		} = Rr.IX2VanillaUtils, XC = (e, t) => {
			let {
				position: n,
				parameterId: r,
				actionGroups: i,
				destinationKeys: o,
				smoothing: s,
				restingValue: a,
				actionTypeId: u,
				customEasingFn: l,
				skipMotion: _,
				skipToValue: d
			} = e, {
				parameters: m
			} = t.payload, v = Math.max(1 - s, .01), E = m[r];
			E == null && (v = 1, E = a);
			let b = Math.max(E, 0) || 0,
				x = Sr(b - n),
				T = _ ? d : Sr(n + x * v),
				L = T * 100;
			if (T === n && e.current) return e;
			let P, D, F, M;
			for (let K = 0, {
					length: Q
				} = i; K < Q; K++) {
				let {
					keyframe: ee,
					actionItems: ne
				} = i[K];
				if (K === 0 && (P = ne[0]), L >= ee) {
					P = ne[0];
					let V = i[K + 1],
						S = V && L !== ee;
					D = S ? V.actionItems[0] : null, S && (F = ee / 100, M = (V.keyframe - ee) / 100)
				}
			}
			let Y = {};
			if (P && !D)
				for (let K = 0, {
						length: Q
					} = o; K < Q; K++) {
					let ee = o[K];
					Y[ee] = Po(u, ee, P.config)
				} else if (P && D && F !== void 0 && M !== void 0) {
					let K = (T - F) / M,
						Q = P.config.easing,
						ee = gp(Q, K, l);
					for (let ne = 0, {
							length: V
						} = o; ne < V; ne++) {
						let S = o[ne],
							q = Po(u, S, P.config),
							te = (Po(u, S, D.config) - q) * ee + q;
						Y[S] = te
					}
				} return (0, ct.merge)(e, {
				position: T,
				current: Y
			})
		}, UC = (e, t) => {
			let {
				active: n,
				origin: r,
				start: i,
				immediate: o,
				renderType: s,
				verbose: a,
				actionItem: u,
				destination: l,
				destinationKeys: _,
				pluginDuration: d,
				instanceDelay: m,
				customEasingFn: v,
				skipMotion: E
			} = e, b = u.config.easing, {
				duration: x,
				delay: T
			} = u.config;
			d != null && (x = d), T = m ?? T, s === kC ? x = 0 : (o || E) && (x = T = 0);
			let {
				now: L
			} = t.payload;
			if (n && r) {
				let P = L - (i + T);
				if (a) {
					let K = L - i,
						Q = x + T,
						ee = Sr(Math.min(Math.max(0, K / Q), 1));
					e = (0, ct.set)(e, "verboseTimeElapsed", Q * ee)
				}
				if (P < 0) return e;
				let D = Sr(Math.min(Math.max(0, P / x), 1)),
					F = gp(b, D, v),
					M = {},
					Y = null;
				return _.length && (Y = _.reduce((K, Q) => {
					let ee = l[Q],
						ne = parseFloat(r[Q]) || 0,
						S = (parseFloat(ee) - ne) * F + ne;
					return K[Q] = S, K
				}, {})), M.current = Y, M.position = D, D === 1 && (M.active = !1, M.complete = !0), (0, ct.merge)(e, M)
			}
			return e
		}, hp = (e = Object.freeze({}), t) => {
			switch (t.type) {
				case LC:
					return t.payload.ixInstances || Object.freeze({});
				case PC:
					return Object.freeze({});
				case NC: {
					let {
						instanceId: n,
						elementId: r,
						actionItem: i,
						eventId: o,
						eventTarget: s,
						eventStateKey: a,
						actionListId: u,
						groupIndex: l,
						isCarrier: _,
						origin: d,
						destination: m,
						immediate: v,
						verbose: E,
						continuous: b,
						parameterId: x,
						actionGroups: T,
						smoothing: L,
						restingValue: P,
						pluginInstance: D,
						pluginDuration: F,
						instanceDelay: M,
						skipMotion: Y,
						skipToValue: K
					} = t.payload, {
						actionTypeId: Q
					} = i, ee = GC(Q), ne = VC(ee, Q), V = Object.keys(m).filter(q => m[q] != null && typeof m[q] != "string"), {
						easing: S
					} = i.config;
					return (0, ct.set)(e, n, {
						id: n,
						elementId: r,
						active: !1,
						position: 0,
						start: 0,
						origin: d,
						destination: m,
						destinationKeys: V,
						immediate: v,
						verbose: E,
						current: null,
						actionItem: i,
						actionTypeId: Q,
						eventId: o,
						eventTarget: s,
						eventStateKey: a,
						actionListId: u,
						groupIndex: l,
						renderType: ee,
						isCarrier: _,
						styleProp: ne,
						continuous: b,
						parameterId: x,
						actionGroups: T,
						smoothing: L,
						restingValue: P,
						pluginInstance: D,
						pluginDuration: F,
						instanceDelay: M,
						skipMotion: Y,
						skipToValue: K,
						customEasingFn: Array.isArray(S) && S.length === 4 ? qC(S) : void 0
					})
				}
				case DC: {
					let {
						instanceId: n,
						time: r
					} = t.payload;
					return (0, ct.mergeIn)(e, [n], {
						active: !0,
						complete: !1,
						start: r
					})
				}
				case MC: {
					let {
						instanceId: n
					} = t.payload;
					if (!e[n]) return e;
					let r = {},
						i = Object.keys(e),
						{
							length: o
						} = i;
					for (let s = 0; s < o; s++) {
						let a = i[s];
						a !== n && (r[a] = e[a])
					}
					return r
				}
				case FC: {
					let n = e,
						r = Object.keys(e),
						{
							length: i
						} = r;
					for (let o = 0; o < i; o++) {
						let s = r[o],
							a = e[s],
							u = a.continuous ? XC : UC;
						n = (0, ct.set)(n, s, u(a, t))
					}
					return n
				}
				default:
					return e
			}
		}
	});
	var WC, HC, BC, mp, yp = ye(() => {
		"use strict";
		qe();
		({
			IX2_RAW_DATA_IMPORTED: WC,
			IX2_SESSION_STOPPED: HC,
			IX2_PARAMETER_CHANGED: BC
		} = we), mp = (e = {}, t) => {
			switch (t.type) {
				case WC:
					return t.payload.ixParameters || {};
				case HC:
					return {};
				case BC: {
					let {
						key: n,
						value: r
					} = t.payload;
					return e[n] = r, e
				}
				default:
					return e
			}
		}
	});
	var Ip = {};
	Fe(Ip, {
		default: () => jC
	});
	var Ep, _p, zC, jC, bp = ye(() => {
		"use strict";
		Ep = ge(Ii());
		Rs();
		Qs();
		Js();
		_p = ge(xt());
		vp();
		yp();
		({
			ixElements: zC
		} = _p.IX2ElementsReducer), jC = (0, Ep.combineReducers)({
			ixData: Ss,
			ixRequest: Ys,
			ixSession: Zs,
			ixElements: zC,
			ixInstances: hp,
			ixParameters: mp
		})
	});
	var wp = g((Gk, Tp) => {
		var KC = dt(),
			YC = Ae(),
			QC = at(),
			$C = "[object String]";

		function ZC(e) {
			return typeof e == "string" || !YC(e) && QC(e) && KC(e) == $C
		}
		Tp.exports = ZC
	});
	var Ap = g((Vk, xp) => {
		var JC = Yi(),
			eL = JC("length");
		xp.exports = eL
	});
	var Sp = g((Xk, Op) => {
		var tL = "\\ud800-\\udfff",
			nL = "\\u0300-\\u036f",
			rL = "\\ufe20-\\ufe2f",
			iL = "\\u20d0-\\u20ff",
			oL = nL + rL + iL,
			aL = "\\ufe0e\\ufe0f",
			sL = "\\u200d",
			uL = RegExp("[" + sL + tL + oL + aL + "]");

		function cL(e) {
			return uL.test(e)
		}
		Op.exports = cL
	});
	var qp = g((Uk, Fp) => {
		var Cp = "\\ud800-\\udfff",
			lL = "\\u0300-\\u036f",
			fL = "\\ufe20-\\ufe2f",
			dL = "\\u20d0-\\u20ff",
			pL = lL + fL + dL,
			gL = "\\ufe0e\\ufe0f",
			hL = "[" + Cp + "]",
			No = "[" + pL + "]",
			Do = "\\ud83c[\\udffb-\\udfff]",
			vL = "(?:" + No + "|" + Do + ")",
			Lp = "[^" + Cp + "]",
			Pp = "(?:\\ud83c[\\udde6-\\uddff]){2}",
			Np = "[\\ud800-\\udbff][\\udc00-\\udfff]",
			mL = "\\u200d",
			Dp = vL + "?",
			Mp = "[" + gL + "]?",
			yL = "(?:" + mL + "(?:" + [Lp, Pp, Np].join("|") + ")" + Mp + Dp + ")*",
			EL = Mp + Dp + yL,
			_L = "(?:" + [Lp + No + "?", No, Pp, Np, hL].join("|") + ")",
			Rp = RegExp(Do + "(?=" + Do + ")|" + _L + EL, "g");

		function IL(e) {
			for (var t = Rp.lastIndex = 0; Rp.test(e);) ++t;
			return t
		}
		Fp.exports = IL
	});
	var Gp = g((Wk, kp) => {
		var bL = Ap(),
			TL = Sp(),
			wL = qp();

		function xL(e) {
			return TL(e) ? wL(e) : bL(e)
		}
		kp.exports = xL
	});
	var Xp = g((Hk, Vp) => {
		var AL = ar(),
			OL = sr(),
			SL = _t(),
			RL = wp(),
			CL = Gp(),
			LL = "[object Map]",
			PL = "[object Set]";

		function NL(e) {
			if (e == null) return 0;
			if (SL(e)) return RL(e) ? CL(e) : e.length;
			var t = OL(e);
			return t == LL || t == PL ? e.size : AL(e).length
		}
		Vp.exports = NL
	});
	var Wp = g((Bk, Up) => {
		var DL = "Expected a function";

		function ML(e) {
			if (typeof e != "function") throw new TypeError(DL);
			return function() {
				var t = arguments;
				switch (t.length) {
					case 0:
						return !e.call(this);
					case 1:
						return !e.call(this, t[0]);
					case 2:
						return !e.call(this, t[0], t[1]);
					case 3:
						return !e.call(this, t[0], t[1], t[2])
				}
				return !e.apply(this, t)
			}
		}
		Up.exports = ML
	});
	var Mo = g((zk, Hp) => {
		var FL = pt(),
			qL = function() {
				try {
					var e = FL(Object, "defineProperty");
					return e({}, "", {}), e
				} catch {}
			}();
		Hp.exports = qL
	});
	var Fo = g((jk, zp) => {
		var Bp = Mo();

		function kL(e, t, n) {
			t == "__proto__" && Bp ? Bp(e, t, {
				configurable: !0,
				enumerable: !0,
				value: n,
				writable: !0
			}) : e[t] = n
		}
		zp.exports = kL
	});
	var Kp = g((Kk, jp) => {
		var GL = Fo(),
			VL = Qn(),
			XL = Object.prototype,
			UL = XL.hasOwnProperty;

		function WL(e, t, n) {
			var r = e[t];
			(!(UL.call(e, t) && VL(r, n)) || n === void 0 && !(t in e)) && GL(e, t, n)
		}
		jp.exports = WL
	});
	var $p = g((Yk, Qp) => {
		var HL = Kp(),
			BL = yn(),
			zL = nr(),
			Yp = tt(),
			jL = Xt();

		function KL(e, t, n, r) {
			if (!Yp(e)) return e;
			t = BL(t, e);
			for (var i = -1, o = t.length, s = o - 1, a = e; a != null && ++i < o;) {
				var u = jL(t[i]),
					l = n;
				if (u === "__proto__" || u === "constructor" || u === "prototype") return e;
				if (i != s) {
					var _ = a[u];
					l = r ? r(_, u, a) : void 0, l === void 0 && (l = Yp(_) ? _ : zL(t[i + 1]) ? [] : {})
				}
				HL(a, u, l), a = a[u]
			}
			return e
		}
		Qp.exports = KL
	});
	var Jp = g((Qk, Zp) => {
		var YL = lr(),
			QL = $p(),
			$L = yn();

		function ZL(e, t, n) {
			for (var r = -1, i = t.length, o = {}; ++r < i;) {
				var s = t[r],
					a = YL(e, s);
				n(a, s) && QL(o, $L(s, e), a)
			}
			return o
		}
		Zp.exports = ZL
	});
	var tg = g(($k, eg) => {
		var JL = er(),
			eP = ui(),
			tP = Di(),
			nP = Ni(),
			rP = Object.getOwnPropertySymbols,
			iP = rP ? function(e) {
				for (var t = []; e;) JL(t, tP(e)), e = eP(e);
				return t
			} : nP;
		eg.exports = iP
	});
	var rg = g((Zk, ng) => {
		function oP(e) {
			var t = [];
			if (e != null)
				for (var n in Object(e)) t.push(n);
			return t
		}
		ng.exports = oP
	});
	var og = g((Jk, ig) => {
		var aP = tt(),
			sP = or(),
			uP = rg(),
			cP = Object.prototype,
			lP = cP.hasOwnProperty;

		function fP(e) {
			if (!aP(e)) return uP(e);
			var t = sP(e),
				n = [];
			for (var r in e) r == "constructor" && (t || !lP.call(e, r)) || n.push(r);
			return n
		}
		ig.exports = fP
	});
	var sg = g((eG, ag) => {
		var dP = Fi(),
			pP = og(),
			gP = _t();

		function hP(e) {
			return gP(e) ? dP(e, !0) : pP(e)
		}
		ag.exports = hP
	});
	var cg = g((tG, ug) => {
		var vP = Pi(),
			mP = tg(),
			yP = sg();

		function EP(e) {
			return vP(e, yP, mP)
		}
		ug.exports = EP
	});
	var fg = g((nG, lg) => {
		var _P = Ki(),
			IP = gt(),
			bP = Jp(),
			TP = cg();

		function wP(e, t) {
			if (e == null) return {};
			var n = _P(TP(e), function(r) {
				return [r]
			});
			return t = IP(t), bP(e, n, function(r, i) {
				return t(r, i[0])
			})
		}
		lg.exports = wP
	});
	var pg = g((rG, dg) => {
		var xP = gt(),
			AP = Wp(),
			OP = fg();

		function SP(e, t) {
			return OP(e, AP(xP(t)))
		}
		dg.exports = SP
	});
	var hg = g((iG, gg) => {
		var RP = ar(),
			CP = sr(),
			LP = dn(),
			PP = Ae(),
			NP = _t(),
			DP = tr(),
			MP = or(),
			FP = ir(),
			qP = "[object Map]",
			kP = "[object Set]",
			GP = Object.prototype,
			VP = GP.hasOwnProperty;

		function XP(e) {
			if (e == null) return !0;
			if (NP(e) && (PP(e) || typeof e == "string" || typeof e.splice == "function" || DP(e) || FP(e) || LP(e))) return !e.length;
			var t = CP(e);
			if (t == qP || t == kP) return !e.size;
			if (MP(e)) return !RP(e).length;
			for (var n in e)
				if (VP.call(e, n)) return !1;
			return !0
		}
		gg.exports = XP
	});
	var mg = g((oG, vg) => {
		var UP = Fo(),
			WP = bo(),
			HP = gt();

		function BP(e, t) {
			var n = {};
			return t = HP(t, 3), WP(e, function(r, i, o) {
				UP(n, i, t(r, i, o))
			}), n
		}
		vg.exports = BP
	});
	var Eg = g((aG, yg) => {
		function zP(e, t) {
			for (var n = -1, r = e == null ? 0 : e.length; ++n < r && t(e[n], n, e) !== !1;);
			return e
		}
		yg.exports = zP
	});
	var Ig = g((sG, _g) => {
		var jP = dr();

		function KP(e) {
			return typeof e == "function" ? e : jP
		}
		_g.exports = KP
	});
	var Tg = g((uG, bg) => {
		var YP = Eg(),
			QP = To(),
			$P = Ig(),
			ZP = Ae();

		function JP(e, t) {
			var n = ZP(e) ? YP : QP;
			return n(e, $P(t))
		}
		bg.exports = JP
	});
	var xg = g((cG, wg) => {
		var eN = ze(),
			tN = function() {
				return eN.Date.now()
			};
		wg.exports = tN
	});
	var Sg = g((lG, Og) => {
		var nN = tt(),
			qo = xg(),
			Ag = pr(),
			rN = "Expected a function",
			iN = Math.max,
			oN = Math.min;

		function aN(e, t, n) {
			var r, i, o, s, a, u, l = 0,
				_ = !1,
				d = !1,
				m = !0;
			if (typeof e != "function") throw new TypeError(rN);
			t = Ag(t) || 0, nN(n) && (_ = !!n.leading, d = "maxWait" in n, o = d ? iN(Ag(n.maxWait) || 0, t) : o, m = "trailing" in n ? !!n.trailing : m);

			function v(M) {
				var Y = r,
					K = i;
				return r = i = void 0, l = M, s = e.apply(K, Y), s
			}

			function E(M) {
				return l = M, a = setTimeout(T, t), _ ? v(M) : s
			}

			function b(M) {
				var Y = M - u,
					K = M - l,
					Q = t - Y;
				return d ? oN(Q, o - K) : Q
			}

			function x(M) {
				var Y = M - u,
					K = M - l;
				return u === void 0 || Y >= t || Y < 0 || d && K >= o
			}

			function T() {
				var M = qo();
				if (x(M)) return L(M);
				a = setTimeout(T, b(M))
			}

			function L(M) {
				return a = void 0, m && r ? v(M) : (r = i = void 0, s)
			}

			function P() {
				a !== void 0 && clearTimeout(a), l = 0, r = u = i = a = void 0
			}

			function D() {
				return a === void 0 ? s : L(qo())
			}

			function F() {
				var M = qo(),
					Y = x(M);
				if (r = arguments, i = this, u = M, Y) {
					if (a === void 0) return E(u);
					if (d) return clearTimeout(a), a = setTimeout(T, t), v(u)
				}
				return a === void 0 && (a = setTimeout(T, t)), s
			}
			return F.cancel = P, F.flush = D, F
		}
		Og.exports = aN
	});
	var Cg = g((fG, Rg) => {
		var sN = Sg(),
			uN = tt(),
			cN = "Expected a function";

		function lN(e, t, n) {
			var r = !0,
				i = !0;
			if (typeof e != "function") throw new TypeError(cN);
			return uN(n) && (r = "leading" in n ? !!n.leading : r, i = "trailing" in n ? !!n.trailing : i), sN(e, t, {
				leading: r,
				maxWait: t,
				trailing: i
			})
		}
		Rg.exports = lN
	});
	var Pg = {};
	Fe(Pg, {
		actionListPlaybackChanged: () => Jt,
		animationFrameChanged: () => Lr,
		clearRequested: () => MN,
		elementStateChanged: () => Bo,
		eventListenerAdded: () => Cr,
		eventStateChanged: () => Uo,
		instanceAdded: () => Wo,
		instanceRemoved: () => Ho,
		instanceStarted: () => Pr,
		mediaQueriesDefined: () => jo,
		parameterChanged: () => Zt,
		playbackRequested: () => NN,
		previewRequested: () => PN,
		rawDataImported: () => ko,
		sessionInitialized: () => Go,
		sessionStarted: () => Vo,
		sessionStopped: () => Xo,
		stopRequested: () => DN,
		testFrameRendered: () => FN,
		viewportWidthChanged: () => zo
	});
	var Lg, fN, dN, pN, gN, hN, vN, mN, yN, EN, _N, IN, bN, TN, wN, xN, AN, ON, SN, RN, CN, LN, ko, Go, Vo, Xo, PN, NN, DN, MN, Cr, FN, Uo, Lr, Zt, Wo, Pr, Ho, Bo, Jt, zo, jo, Nr = ye(() => {
		"use strict";
		qe();
		Lg = ge(xt()), {
			IX2_RAW_DATA_IMPORTED: fN,
			IX2_SESSION_INITIALIZED: dN,
			IX2_SESSION_STARTED: pN,
			IX2_SESSION_STOPPED: gN,
			IX2_PREVIEW_REQUESTED: hN,
			IX2_PLAYBACK_REQUESTED: vN,
			IX2_STOP_REQUESTED: mN,
			IX2_CLEAR_REQUESTED: yN,
			IX2_EVENT_LISTENER_ADDED: EN,
			IX2_TEST_FRAME_RENDERED: _N,
			IX2_EVENT_STATE_CHANGED: IN,
			IX2_ANIMATION_FRAME_CHANGED: bN,
			IX2_PARAMETER_CHANGED: TN,
			IX2_INSTANCE_ADDED: wN,
			IX2_INSTANCE_STARTED: xN,
			IX2_INSTANCE_REMOVED: AN,
			IX2_ELEMENT_STATE_CHANGED: ON,
			IX2_ACTION_LIST_PLAYBACK_CHANGED: SN,
			IX2_VIEWPORT_WIDTH_CHANGED: RN,
			IX2_MEDIA_QUERIES_DEFINED: CN
		} = we, {
			reifyState: LN
		} = Lg.IX2VanillaUtils, ko = e => ({
			type: fN,
			payload: {
				...LN(e)
			}
		}), Go = ({
			hasBoundaryNodes: e,
			reducedMotion: t
		}) => ({
			type: dN,
			payload: {
				hasBoundaryNodes: e,
				reducedMotion: t
			}
		}), Vo = () => ({
			type: pN
		}), Xo = () => ({
			type: gN
		}), PN = ({
			rawData: e,
			defer: t
		}) => ({
			type: hN,
			payload: {
				defer: t,
				rawData: e
			}
		}), NN = ({
			actionTypeId: e = Pe.GENERAL_START_ACTION,
			actionListId: t,
			actionItemId: n,
			eventId: r,
			allowEvents: i,
			immediate: o,
			testManual: s,
			verbose: a,
			rawData: u
		}) => ({
			type: vN,
			payload: {
				actionTypeId: e,
				actionListId: t,
				actionItemId: n,
				testManual: s,
				eventId: r,
				allowEvents: i,
				immediate: o,
				verbose: a,
				rawData: u
			}
		}), DN = e => ({
			type: mN,
			payload: {
				actionListId: e
			}
		}), MN = () => ({
			type: yN
		}), Cr = (e, t) => ({
			type: EN,
			payload: {
				target: e,
				listenerParams: t
			}
		}), FN = (e = 1) => ({
			type: _N,
			payload: {
				step: e
			}
		}), Uo = (e, t) => ({
			type: IN,
			payload: {
				stateKey: e,
				newState: t
			}
		}), Lr = (e, t) => ({
			type: bN,
			payload: {
				now: e,
				parameters: t
			}
		}), Zt = (e, t) => ({
			type: TN,
			payload: {
				key: e,
				value: t
			}
		}), Wo = e => ({
			type: wN,
			payload: {
				...e
			}
		}), Pr = (e, t) => ({
			type: xN,
			payload: {
				instanceId: e,
				time: t
			}
		}), Ho = e => ({
			type: AN,
			payload: {
				instanceId: e
			}
		}), Bo = (e, t, n, r) => ({
			type: ON,
			payload: {
				elementId: e,
				actionTypeId: t,
				current: n,
				actionItem: r
			}
		}), Jt = ({
			actionListId: e,
			isPlaying: t
		}) => ({
			type: SN,
			payload: {
				actionListId: e,
				isPlaying: t
			}
		}), zo = ({
			width: e,
			mediaQueries: t
		}) => ({
			type: RN,
			payload: {
				width: e,
				mediaQueries: t
			}
		}), jo = () => ({
			type: CN
		})
	});
	var De = {};
	Fe(De, {
		elementContains: () => Qo,
		getChildElements: () => zN,
		getClosestElement: () => Rn,
		getProperty: () => XN,
		getQuerySelector: () => Yo,
		getRefType: () => $o,
		getSiblingElements: () => jN,
		getStyle: () => VN,
		getValidDocument: () => WN,
		isSiblingNode: () => BN,
		matchSelector: () => UN,
		queryDocument: () => HN,
		setStyle: () => GN
	});

	function GN(e, t, n) {
		e.style[t] = n
	}

	function VN(e, t) {
		if (t.startsWith("--")) return window.getComputedStyle(document.documentElement).getPropertyValue(t);
		if (e.style instanceof CSSStyleDeclaration) return e.style[t]
	}

	function XN(e, t) {
		return e[t]
	}

	function UN(e) {
		return t => t[Ko](e)
	}

	function Yo({
		id: e,
		selector: t
	}) {
		if (e) {
			let n = e;
			if (e.indexOf(Ng) !== -1) {
				let r = e.split(Ng),
					i = r[0];
				if (n = r[1], i !== document.documentElement.getAttribute(Mg)) return null
			}
			return `[data-w-id="${n}"], [data-w-id^="${n}_instance"]`
		}
		return t
	}

	function WN(e) {
		return e == null || e === document.documentElement.getAttribute(Mg) ? document : null
	}

	function HN(e, t) {
		return Array.prototype.slice.call(document.querySelectorAll(t ? e + " " + t : e))
	}

	function Qo(e, t) {
		return e.contains(t)
	}

	function BN(e, t) {
		return e !== t && e.parentNode === t.parentNode
	}

	function zN(e) {
		let t = [];
		for (let n = 0, {
				length: r
			} = e || []; n < r; n++) {
			let {
				children: i
			} = e[n], {
				length: o
			} = i;
			if (o)
				for (let s = 0; s < o; s++) t.push(i[s])
		}
		return t
	}

	function jN(e = []) {
		let t = [],
			n = [];
		for (let r = 0, {
				length: i
			} = e; r < i; r++) {
			let {
				parentNode: o
			} = e[r];
			if (!o || !o.children || !o.children.length || n.indexOf(o) !== -1) continue;
			n.push(o);
			let s = o.firstElementChild;
			for (; s != null;) e.indexOf(s) === -1 && t.push(s), s = s.nextElementSibling
		}
		return t
	}

	function $o(e) {
		return e != null && typeof e == "object" ? e instanceof Element ? qN : kN : null
	}
	var Dg, Ko, Ng, qN, kN, Mg, Rn, Fg = ye(() => {
		"use strict";
		Dg = ge(xt());
		qe();
		({
			ELEMENT_MATCHES: Ko
		} = Dg.IX2BrowserSupport), {
			IX2_ID_DELIMITER: Ng,
			HTML_ELEMENT: qN,
			PLAIN_OBJECT: kN,
			WF_PAGE: Mg
		} = Se;
		Rn = Element.prototype.closest ? (e, t) => document.documentElement.contains(e) ? e.closest(t) : null : (e, t) => {
			if (!document.documentElement.contains(e)) return null;
			let n = e;
			do {
				if (n[Ko] && n[Ko](t)) return n;
				n = n.parentNode
			} while (n != null);
			return null
		}
	});
	var Zo = g((gG, kg) => {
		var KN = tt(),
			qg = Object.create,
			YN = function() {
				function e() {}
				return function(t) {
					if (!KN(t)) return {};
					if (qg) return qg(t);
					e.prototype = t;
					var n = new e;
					return e.prototype = void 0, n
				}
			}();
		kg.exports = YN
	});
	var Dr = g((hG, Gg) => {
		function QN() {}
		Gg.exports = QN
	});
	var Fr = g((vG, Vg) => {
		var $N = Zo(),
			ZN = Dr();

		function Mr(e, t) {
			this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!t, this.__index__ = 0, this.__values__ = void 0
		}
		Mr.prototype = $N(ZN.prototype);
		Mr.prototype.constructor = Mr;
		Vg.exports = Mr
	});
	var Hg = g((mG, Wg) => {
		var Xg = Ct(),
			JN = dn(),
			eD = Ae(),
			Ug = Xg ? Xg.isConcatSpreadable : void 0;

		function tD(e) {
			return eD(e) || JN(e) || !!(Ug && e && e[Ug])
		}
		Wg.exports = tD
	});
	var jg = g((yG, zg) => {
		var nD = er(),
			rD = Hg();

		function Bg(e, t, n, r, i) {
			var o = -1,
				s = e.length;
			for (n || (n = rD), i || (i = []); ++o < s;) {
				var a = e[o];
				t > 0 && n(a) ? t > 1 ? Bg(a, t - 1, n, r, i) : nD(i, a) : r || (i[i.length] = a)
			}
			return i
		}
		zg.exports = Bg
	});
	var Yg = g((EG, Kg) => {
		var iD = jg();

		function oD(e) {
			var t = e == null ? 0 : e.length;
			return t ? iD(e, 1) : []
		}
		Kg.exports = oD
	});
	var $g = g((_G, Qg) => {
		function aD(e, t, n) {
			switch (n.length) {
				case 0:
					return e.call(t);
				case 1:
					return e.call(t, n[0]);
				case 2:
					return e.call(t, n[0], n[1]);
				case 3:
					return e.call(t, n[0], n[1], n[2])
			}
			return e.apply(t, n)
		}
		Qg.exports = aD
	});
	var eh = g((IG, Jg) => {
		var sD = $g(),
			Zg = Math.max;

		function uD(e, t, n) {
			return t = Zg(t === void 0 ? e.length - 1 : t, 0),
				function() {
					for (var r = arguments, i = -1, o = Zg(r.length - t, 0), s = Array(o); ++i < o;) s[i] = r[t + i];
					i = -1;
					for (var a = Array(t + 1); ++i < t;) a[i] = r[i];
					return a[t] = n(s), sD(e, this, a)
				}
		}
		Jg.exports = uD
	});
	var nh = g((bG, th) => {
		function cD(e) {
			return function() {
				return e
			}
		}
		th.exports = cD
	});
	var oh = g((TG, ih) => {
		var lD = nh(),
			rh = Mo(),
			fD = dr(),
			dD = rh ? function(e, t) {
				return rh(e, "toString", {
					configurable: !0,
					enumerable: !1,
					value: lD(t),
					writable: !0
				})
			} : fD;
		ih.exports = dD
	});
	var sh = g((wG, ah) => {
		var pD = 800,
			gD = 16,
			hD = Date.now;

		function vD(e) {
			var t = 0,
				n = 0;
			return function() {
				var r = hD(),
					i = gD - (r - n);
				if (n = r, i > 0) {
					if (++t >= pD) return arguments[0]
				} else t = 0;
				return e.apply(void 0, arguments)
			}
		}
		ah.exports = vD
	});
	var ch = g((xG, uh) => {
		var mD = oh(),
			yD = sh(),
			ED = yD(mD);
		uh.exports = ED
	});
	var fh = g((AG, lh) => {
		var _D = Yg(),
			ID = eh(),
			bD = ch();

		function TD(e) {
			return bD(ID(e, void 0, _D), e + "")
		}
		lh.exports = TD
	});
	var gh = g((OG, ph) => {
		var dh = qi(),
			wD = dh && new dh;
		ph.exports = wD
	});
	var vh = g((SG, hh) => {
		function xD() {}
		hh.exports = xD
	});
	var Jo = g((RG, yh) => {
		var mh = gh(),
			AD = vh(),
			OD = mh ? function(e) {
				return mh.get(e)
			} : AD;
		yh.exports = OD
	});
	var _h = g((CG, Eh) => {
		var SD = {};
		Eh.exports = SD
	});
	var ea = g((LG, bh) => {
		var Ih = _h(),
			RD = Object.prototype,
			CD = RD.hasOwnProperty;

		function LD(e) {
			for (var t = e.name + "", n = Ih[t], r = CD.call(Ih, t) ? n.length : 0; r--;) {
				var i = n[r],
					o = i.func;
				if (o == null || o == e) return i.name
			}
			return t
		}
		bh.exports = LD
	});
	var kr = g((PG, Th) => {
		var PD = Zo(),
			ND = Dr(),
			DD = 4294967295;

		function qr(e) {
			this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = DD, this.__views__ = []
		}
		qr.prototype = PD(ND.prototype);
		qr.prototype.constructor = qr;
		Th.exports = qr
	});
	var xh = g((NG, wh) => {
		function MD(e, t) {
			var n = -1,
				r = e.length;
			for (t || (t = Array(r)); ++n < r;) t[n] = e[n];
			return t
		}
		wh.exports = MD
	});
	var Oh = g((DG, Ah) => {
		var FD = kr(),
			qD = Fr(),
			kD = xh();

		function GD(e) {
			if (e instanceof FD) return e.clone();
			var t = new qD(e.__wrapped__, e.__chain__);
			return t.__actions__ = kD(e.__actions__), t.__index__ = e.__index__, t.__values__ = e.__values__, t
		}
		Ah.exports = GD
	});
	var Ch = g((MG, Rh) => {
		var VD = kr(),
			Sh = Fr(),
			XD = Dr(),
			UD = Ae(),
			WD = at(),
			HD = Oh(),
			BD = Object.prototype,
			zD = BD.hasOwnProperty;

		function Gr(e) {
			if (WD(e) && !UD(e) && !(e instanceof VD)) {
				if (e instanceof Sh) return e;
				if (zD.call(e, "__wrapped__")) return HD(e)
			}
			return new Sh(e)
		}
		Gr.prototype = XD.prototype;
		Gr.prototype.constructor = Gr;
		Rh.exports = Gr
	});
	var Ph = g((FG, Lh) => {
		var jD = kr(),
			KD = Jo(),
			YD = ea(),
			QD = Ch();

		function $D(e) {
			var t = YD(e),
				n = QD[t];
			if (typeof n != "function" || !(t in jD.prototype)) return !1;
			if (e === n) return !0;
			var r = KD(n);
			return !!r && e === r[0]
		}
		Lh.exports = $D
	});
	var Fh = g((qG, Mh) => {
		var Nh = Fr(),
			ZD = fh(),
			JD = Jo(),
			ta = ea(),
			eM = Ae(),
			Dh = Ph(),
			tM = "Expected a function",
			nM = 8,
			rM = 32,
			iM = 128,
			oM = 256;

		function aM(e) {
			return ZD(function(t) {
				var n = t.length,
					r = n,
					i = Nh.prototype.thru;
				for (e && t.reverse(); r--;) {
					var o = t[r];
					if (typeof o != "function") throw new TypeError(tM);
					if (i && !s && ta(o) == "wrapper") var s = new Nh([], !0)
				}
				for (r = s ? r : n; ++r < n;) {
					o = t[r];
					var a = ta(o),
						u = a == "wrapper" ? JD(o) : void 0;
					u && Dh(u[0]) && u[1] == (iM | nM | rM | oM) && !u[4].length && u[9] == 1 ? s = s[ta(u[0])].apply(s, u[3]) : s = o.length == 1 && Dh(o) ? s[a]() : s.thru(o)
				}
				return function() {
					var l = arguments,
						_ = l[0];
					if (s && l.length == 1 && eM(_)) return s.plant(_).value();
					for (var d = 0, m = n ? t[d].apply(this, l) : _; ++d < n;) m = t[d].call(this, m);
					return m
				}
			})
		}
		Mh.exports = aM
	});
	var kh = g((kG, qh) => {
		var sM = Fh(),
			uM = sM();
		qh.exports = uM
	});
	var Vh = g((GG, Gh) => {
		function cM(e, t, n) {
			return e === e && (n !== void 0 && (e = e <= n ? e : n), t !== void 0 && (e = e >= t ? e : t)), e
		}
		Gh.exports = cM
	});
	var Uh = g((VG, Xh) => {
		var lM = Vh(),
			na = pr();

		function fM(e, t, n) {
			return n === void 0 && (n = t, t = void 0), n !== void 0 && (n = na(n), n = n === n ? n : 0), t !== void 0 && (t = na(t), t = t === t ? t : 0), lM(na(e), t, n)
		}
		Xh.exports = fM
	});
	var $h, Zh, Jh, ev, dM, pM, gM, hM, vM, mM, yM, EM, _M, IM, bM, TM, wM, xM, AM, tv, nv, OM, SM, RM, rv, CM, LM, iv, PM, ra, ov, Wh, Hh, av, Ln, NM, it, sv, DM, Ge, Ye, Pn, uv, ia, Bh, oa, MM, Cn, FM, qM, kM, cv, zh, GM, jh, VM, XM, UM, Kh, Vr, Xr, Yh, Qh, lv, fv = ye(() => {
		"use strict";
		$h = ge(kh()), Zh = ge(fr()), Jh = ge(Uh());
		qe();
		aa();
		Nr();
		ev = ge(xt()), {
			MOUSE_CLICK: dM,
			MOUSE_SECOND_CLICK: pM,
			MOUSE_DOWN: gM,
			MOUSE_UP: hM,
			MOUSE_OVER: vM,
			MOUSE_OUT: mM,
			DROPDOWN_CLOSE: yM,
			DROPDOWN_OPEN: EM,
			SLIDER_ACTIVE: _M,
			SLIDER_INACTIVE: IM,
			TAB_ACTIVE: bM,
			TAB_INACTIVE: TM,
			NAVBAR_CLOSE: wM,
			NAVBAR_OPEN: xM,
			MOUSE_MOVE: AM,
			PAGE_SCROLL_DOWN: tv,
			SCROLL_INTO_VIEW: nv,
			SCROLL_OUT_OF_VIEW: OM,
			PAGE_SCROLL_UP: SM,
			SCROLLING_IN_VIEW: RM,
			PAGE_FINISH: rv,
			ECOMMERCE_CART_CLOSE: CM,
			ECOMMERCE_CART_OPEN: LM,
			PAGE_START: iv,
			PAGE_SCROLL: PM
		} = je, ra = "COMPONENT_ACTIVE", ov = "COMPONENT_INACTIVE", {
			COLON_DELIMITER: Wh
		} = Se, {
			getNamespacedParameterId: Hh
		} = ev.IX2VanillaUtils, av = e => t => typeof t == "object" && e(t) ? !0 : t, Ln = av(({
			element: e,
			nativeEvent: t
		}) => e === t.target), NM = av(({
			element: e,
			nativeEvent: t
		}) => e.contains(t.target)), it = (0, $h.default)([Ln, NM]), sv = (e, t) => {
			if (t) {
				let {
					ixData: n
				} = e.getState(), {
					events: r
				} = n, i = r[t];
				if (i && !MM[i.eventTypeId]) return i
			}
			return null
		}, DM = ({
			store: e,
			event: t
		}) => {
			let {
				action: n
			} = t, {
				autoStopEventId: r
			} = n.config;
			return !!sv(e, r)
		}, Ge = ({
			store: e,
			event: t,
			element: n,
			eventStateKey: r
		}, i) => {
			let {
				action: o,
				id: s
			} = t, {
				actionListId: a,
				autoStopEventId: u
			} = o.config, l = sv(e, u);
			return l && en({
				store: e,
				eventId: u,
				eventTarget: n,
				eventStateKey: u + Wh + r.split(Wh)[1],
				actionListId: (0, Zh.default)(l, "action.config.actionListId")
			}), en({
				store: e,
				eventId: s,
				eventTarget: n,
				eventStateKey: r,
				actionListId: a
			}), Nn({
				store: e,
				eventId: s,
				eventTarget: n,
				eventStateKey: r,
				actionListId: a
			}), i
		}, Ye = (e, t) => (n, r) => e(n, r) === !0 ? t(n, r) : r, Pn = {
			handler: Ye(it, Ge)
		}, uv = {
			...Pn,
			types: [ra, ov].join(" ")
		}, ia = [{
			target: window,
			types: "resize orientationchange",
			throttle: !0
		}, {
			target: document,
			types: "scroll wheel readystatechange IX2_PAGE_UPDATE",
			throttle: !0
		}], Bh = "mouseover mouseout", oa = {
			types: ia
		}, MM = {
			PAGE_START: iv,
			PAGE_FINISH: rv
		}, Cn = (() => {
			let e = window.pageXOffset !== void 0,
				n = document.compatMode === "CSS1Compat" ? document.documentElement : document.body;
			return () => ({
				scrollLeft: e ? window.pageXOffset : n.scrollLeft,
				scrollTop: e ? window.pageYOffset : n.scrollTop,
				stiffScrollTop: (0, Jh.default)(e ? window.pageYOffset : n.scrollTop, 0, n.scrollHeight - window.innerHeight),
				scrollWidth: n.scrollWidth,
				scrollHeight: n.scrollHeight,
				clientWidth: n.clientWidth,
				clientHeight: n.clientHeight,
				innerWidth: window.innerWidth,
				innerHeight: window.innerHeight
			})
		})(), FM = (e, t) => !(e.left > t.right || e.right < t.left || e.top > t.bottom || e.bottom < t.top), qM = ({
			element: e,
			nativeEvent: t
		}) => {
			let {
				type: n,
				target: r,
				relatedTarget: i
			} = t, o = e.contains(r);
			if (n === "mouseover" && o) return !0;
			let s = e.contains(i);
			return !!(n === "mouseout" && o && s)
		}, kM = e => {
			let {
				element: t,
				event: {
					config: n
				}
			} = e, {
				clientWidth: r,
				clientHeight: i
			} = Cn(), o = n.scrollOffsetValue, u = n.scrollOffsetUnit === "PX" ? o : i * (o || 0) / 100;
			return FM(t.getBoundingClientRect(), {
				left: 0,
				top: u,
				right: r,
				bottom: i - u
			})
		}, cv = e => (t, n) => {
			let {
				type: r
			} = t.nativeEvent, i = [ra, ov].indexOf(r) !== -1 ? r === ra : n.isActive, o = {
				...n,
				isActive: i
			};
			return (!n || o.isActive !== n.isActive) && e(t, o) || o
		}, zh = e => (t, n) => {
			let r = {
				elementHovered: qM(t)
			};
			return (n ? r.elementHovered !== n.elementHovered : r.elementHovered) && e(t, r) || r
		}, GM = e => (t, n) => {
			let r = {
				...n,
				elementVisible: kM(t)
			};
			return (n ? r.elementVisible !== n.elementVisible : r.elementVisible) && e(t, r) || r
		}, jh = e => (t, n = {}) => {
			let {
				stiffScrollTop: r,
				scrollHeight: i,
				innerHeight: o
			} = Cn(), {
				event: {
					config: s,
					eventTypeId: a
				}
			} = t, {
				scrollOffsetValue: u,
				scrollOffsetUnit: l
			} = s, _ = l === "PX", d = i - o, m = Number((r / d).toFixed(2));
			if (n && n.percentTop === m) return n;
			let v = (_ ? u : o * (u || 0) / 100) / d,
				E, b, x = 0;
			n && (E = m > n.percentTop, b = n.scrollingDown !== E, x = b ? m : n.anchorTop);
			let T = a === tv ? m >= x + v : m <= x - v,
				L = {
					...n,
					percentTop: m,
					inBounds: T,
					anchorTop: x,
					scrollingDown: E
				};
			return n && T && (b || L.inBounds !== n.inBounds) && e(t, L) || L
		}, VM = (e, t) => e.left > t.left && e.left < t.right && e.top > t.top && e.top < t.bottom, XM = e => (t, n) => {
			let r = {
				finished: document.readyState === "complete"
			};
			return r.finished && !(n && n.finshed) && e(t), r
		}, UM = e => (t, n) => {
			let r = {
				started: !0
			};
			return n || e(t), r
		}, Kh = e => (t, n = {
			clickCount: 0
		}) => {
			let r = {
				clickCount: n.clickCount % 2 + 1
			};
			return r.clickCount !== n.clickCount && e(t, r) || r
		}, Vr = (e = !0) => ({
			...uv,
			handler: Ye(e ? it : Ln, cv((t, n) => n.isActive ? Pn.handler(t, n) : n))
		}), Xr = (e = !0) => ({
			...uv,
			handler: Ye(e ? it : Ln, cv((t, n) => n.isActive ? n : Pn.handler(t, n)))
		}), Yh = {
			...oa,
			handler: GM((e, t) => {
				let {
					elementVisible: n
				} = t, {
					event: r,
					store: i
				} = e, {
					ixData: o
				} = i.getState(), {
					events: s
				} = o;
				return !s[r.action.config.autoStopEventId] && t.triggered ? t : r.eventTypeId === nv === n ? (Ge(e), {
					...t,
					triggered: !0
				}) : t
			})
		}, Qh = .05, lv = {
			[_M]: Vr(),
			[IM]: Xr(),
			[EM]: Vr(),
			[yM]: Xr(),
			[xM]: Vr(!1),
			[wM]: Xr(!1),
			[bM]: Vr(),
			[TM]: Xr(),
			[LM]: {
				types: "ecommerce-cart-open",
				handler: Ye(it, Ge)
			},
			[CM]: {
				types: "ecommerce-cart-close",
				handler: Ye(it, Ge)
			},
			[dM]: {
				types: "click",
				handler: Ye(it, Kh((e, {
					clickCount: t
				}) => {
					DM(e) ? t === 1 && Ge(e) : Ge(e)
				}))
			},
			[pM]: {
				types: "click",
				handler: Ye(it, Kh((e, {
					clickCount: t
				}) => {
					t === 2 && Ge(e)
				}))
			},
			[gM]: {
				...Pn,
				types: "mousedown"
			},
			[hM]: {
				...Pn,
				types: "mouseup"
			},
			[vM]: {
				types: Bh,
				handler: Ye(it, zh((e, t) => {
					t.elementHovered && Ge(e)
				}))
			},
			[mM]: {
				types: Bh,
				handler: Ye(it, zh((e, t) => {
					t.elementHovered || Ge(e)
				}))
			},
			[AM]: {
				types: "mousemove mouseout scroll",
				handler: ({
					store: e,
					element: t,
					eventConfig: n,
					nativeEvent: r,
					eventStateKey: i
				}, o = {
					clientX: 0,
					clientY: 0,
					pageX: 0,
					pageY: 0
				}) => {
					let {
						basedOn: s,
						selectedAxis: a,
						continuousParameterGroupId: u,
						reverse: l,
						restingState: _ = 0
					} = n, {
						clientX: d = o.clientX,
						clientY: m = o.clientY,
						pageX: v = o.pageX,
						pageY: E = o.pageY
					} = r, b = a === "X_AXIS", x = r.type === "mouseout", T = _ / 100, L = u, P = !1;
					switch (s) {
						case et.VIEWPORT: {
							T = b ? Math.min(d, window.innerWidth) / window.innerWidth : Math.min(m, window.innerHeight) / window.innerHeight;
							break
						}
						case et.PAGE: {
							let {
								scrollLeft: D,
								scrollTop: F,
								scrollWidth: M,
								scrollHeight: Y
							} = Cn();
							T = b ? Math.min(D + v, M) / M : Math.min(F + E, Y) / Y;
							break
						}
						case et.ELEMENT:
						default: {
							L = Hh(i, u);
							let D = r.type.indexOf("mouse") === 0;
							if (D && it({
									element: t,
									nativeEvent: r
								}) !== !0) break;
							let F = t.getBoundingClientRect(),
								{
									left: M,
									top: Y,
									width: K,
									height: Q
								} = F;
							if (!D && !VM({
									left: d,
									top: m
								}, F)) break;
							P = !0, T = b ? (d - M) / K : (m - Y) / Q;
							break
						}
					}
					return x && (T > 1 - Qh || T < Qh) && (T = Math.round(T)), (s !== et.ELEMENT || P || P !== o.elementHovered) && (T = l ? 1 - T : T, e.dispatch(Zt(L, T))), {
						elementHovered: P,
						clientX: d,
						clientY: m,
						pageX: v,
						pageY: E
					}
				}
			},
			[PM]: {
				types: ia,
				handler: ({
					store: e,
					eventConfig: t
				}) => {
					let {
						continuousParameterGroupId: n,
						reverse: r
					} = t, {
						scrollTop: i,
						scrollHeight: o,
						clientHeight: s
					} = Cn(), a = i / (o - s);
					a = r ? 1 - a : a, e.dispatch(Zt(n, a))
				}
			},
			[RM]: {
				types: ia,
				handler: ({
					element: e,
					store: t,
					eventConfig: n,
					eventStateKey: r
				}, i = {
					scrollPercent: 0
				}) => {
					let {
						scrollLeft: o,
						scrollTop: s,
						scrollWidth: a,
						scrollHeight: u,
						clientHeight: l
					} = Cn(), {
						basedOn: _,
						selectedAxis: d,
						continuousParameterGroupId: m,
						startsEntering: v,
						startsExiting: E,
						addEndOffset: b,
						addStartOffset: x,
						addOffsetValue: T = 0,
						endOffsetValue: L = 0
					} = n, P = d === "X_AXIS";
					if (_ === et.VIEWPORT) {
						let D = P ? o / a : s / u;
						return D !== i.scrollPercent && t.dispatch(Zt(m, D)), {
							scrollPercent: D
						}
					} else {
						let D = Hh(r, m),
							F = e.getBoundingClientRect(),
							M = (x ? T : 0) / 100,
							Y = (b ? L : 0) / 100;
						M = v ? M : 1 - M, Y = E ? Y : 1 - Y;
						let K = F.top + Math.min(F.height * M, l),
							ee = F.top + F.height * Y - K,
							ne = Math.min(l + ee, u),
							S = Math.min(Math.max(0, l - K), ne) / ne;
						return S !== i.scrollPercent && t.dispatch(Zt(D, S)), {
							scrollPercent: S
						}
					}
				}
			},
			[nv]: Yh,
			[OM]: Yh,
			[tv]: {
				...oa,
				handler: jh((e, t) => {
					t.scrollingDown && Ge(e)
				})
			},
			[SM]: {
				...oa,
				handler: jh((e, t) => {
					t.scrollingDown || Ge(e)
				})
			},
			[rv]: {
				types: "readystatechange IX2_PAGE_UPDATE",
				handler: Ye(Ln, XM(Ge))
			},
			[iv]: {
				types: "readystatechange IX2_PAGE_UPDATE",
				handler: Ye(Ln, UM(Ge))
			}
		}
	});
	var Sv = {};
	Fe(Sv, {
		observeRequests: () => uF,
		startActionGroup: () => Nn,
		startEngine: () => jr,
		stopActionGroup: () => en,
		stopAllActionGroups: () => xv,
		stopEngine: () => Kr
	});

	function uF(e) {
		At({
			store: e,
			select: ({
				ixRequest: t
			}) => t.preview,
			onChange: fF
		}), At({
			store: e,
			select: ({
				ixRequest: t
			}) => t.playback,
			onChange: dF
		}), At({
			store: e,
			select: ({
				ixRequest: t
			}) => t.stop,
			onChange: pF
		}), At({
			store: e,
			select: ({
				ixRequest: t
			}) => t.clear,
			onChange: gF
		})
	}

	function cF(e) {
		At({
			store: e,
			select: ({
				ixSession: t
			}) => t.mediaQueryKey,
			onChange: () => {
				Kr(e), Iv({
					store: e,
					elementApi: De
				}), jr({
					store: e,
					allowEvents: !0
				}), bv()
			}
		})
	}

	function lF(e, t) {
		let n = At({
			store: e,
			select: ({
				ixSession: r
			}) => r.tick,
			onChange: r => {
				t(r), n()
			}
		})
	}

	function fF({
		rawData: e,
		defer: t
	}, n) {
		let r = () => {
			jr({
				store: n,
				rawData: e,
				allowEvents: !0
			}), bv()
		};
		t ? setTimeout(r, 0) : r()
	}

	function bv() {
		document.dispatchEvent(new CustomEvent("IX2_PAGE_UPDATE"))
	}

	function dF(e, t) {
		let {
			actionTypeId: n,
			actionListId: r,
			actionItemId: i,
			eventId: o,
			allowEvents: s,
			immediate: a,
			testManual: u,
			verbose: l = !0
		} = e, {
			rawData: _
		} = e;
		if (r && i && _ && a) {
			let d = _.actionLists[r];
			d && (_ = $M({
				actionList: d,
				actionItemId: i,
				rawData: _
			}))
		}
		if (jr({
				store: t,
				rawData: _,
				allowEvents: s,
				testManual: u
			}), r && n === Pe.GENERAL_START_ACTION || sa(n)) {
			en({
				store: t,
				actionListId: r
			}), wv({
				store: t,
				actionListId: r,
				eventId: o
			});
			let d = Nn({
				store: t,
				eventId: o,
				actionListId: r,
				immediate: a,
				verbose: l
			});
			l && d && t.dispatch(Jt({
				actionListId: r,
				isPlaying: !a
			}))
		}
	}

	function pF({
		actionListId: e
	}, t) {
		e ? en({
			store: t,
			actionListId: e
		}) : xv({
			store: t
		}), Kr(t)
	}

	function gF(e, t) {
		Kr(t), Iv({
			store: t,
			elementApi: De
		})
	}

	function jr({
		store: e,
		rawData: t,
		allowEvents: n,
		testManual: r
	}) {
		let {
			ixSession: i
		} = e.getState();
		t && e.dispatch(ko(t)), i.active || (e.dispatch(Go({
			hasBoundaryNodes: !!document.querySelector(Wr),
			reducedMotion: document.body.hasAttribute("data-wf-ix-vacation") && window.matchMedia("(prefers-reduced-motion)").matches
		})), n && (_F(e), hF(), e.getState().ixSession.hasDefinedMediaQueries && cF(e)), e.dispatch(Vo()), vF(e, r))
	}

	function hF() {
		let {
			documentElement: e
		} = document;
		e.className.indexOf(dv) === -1 && (e.className += ` ${dv}`)
	}

	function vF(e, t) {
		let n = r => {
			let {
				ixSession: i,
				ixParameters: o
			} = e.getState();
			i.active && (e.dispatch(Lr(r, o)), t ? lF(e, n) : requestAnimationFrame(n))
		};
		n(window.performance.now())
	}

	function Kr(e) {
		let {
			ixSession: t
		} = e.getState();
		if (t.active) {
			let {
				eventListeners: n
			} = t;
			n.forEach(mF), tF(), e.dispatch(Xo())
		}
	}

	function mF({
		target: e,
		listenerParams: t
	}) {
		e.removeEventListener.apply(e, t)
	}

	function yF({
		store: e,
		eventStateKey: t,
		eventTarget: n,
		eventId: r,
		eventConfig: i,
		actionListId: o,
		parameterGroup: s,
		smoothing: a,
		restingValue: u
	}) {
		let {
			ixData: l,
			ixSession: _
		} = e.getState(), {
			events: d
		} = l, m = d[r], {
			eventTypeId: v
		} = m, E = {}, b = {}, x = [], {
			continuousActionGroups: T
		} = s, {
			id: L
		} = s;
		ZM(v, i) && (L = JM(t, L));
		let P = _.hasBoundaryNodes && n ? Rn(n, Wr) : null;
		T.forEach(D => {
			let {
				keyframe: F,
				actionItems: M
			} = D;
			M.forEach(Y => {
				let {
					actionTypeId: K
				} = Y, {
					target: Q
				} = Y.config;
				if (!Q) return;
				let ee = Q.boundaryMode ? P : null,
					ne = nF(Q) + ua + K;
				if (b[ne] = EF(b[ne], F, Y), !E[ne]) {
					E[ne] = !0;
					let {
						config: V
					} = Y;
					Hr({
						config: V,
						event: m,
						eventTarget: n,
						elementRoot: ee,
						elementApi: De
					}).forEach(S => {
						x.push({
							element: S,
							key: ne
						})
					})
				}
			})
		}), x.forEach(({
			element: D,
			key: F
		}) => {
			let M = b[F],
				Y = (0, lt.default)(M, "[0].actionItems[0]", {}),
				{
					actionTypeId: K
				} = Y,
				ee = (K === Pe.PLUGIN_RIVE ? (Y.config?.target?.selectorGuids || []).length === 0 : zr(K)) ? la(K)(D, Y) : null,
				ne = ca({
					element: D,
					actionItem: Y,
					elementApi: De
				}, ee);
			fa({
				store: e,
				element: D,
				eventId: r,
				actionListId: o,
				actionItem: Y,
				destination: ne,
				continuous: !0,
				parameterId: L,
				actionGroups: M,
				smoothing: a,
				restingValue: u,
				pluginInstance: ee
			})
		})
	}

	function EF(e = [], t, n) {
		let r = [...e],
			i;
		return r.some((o, s) => o.keyframe === t ? (i = s, !0) : !1), i == null && (i = r.length, r.push({
			keyframe: t,
			actionItems: []
		})), r[i].actionItems.push(n), r
	}

	function _F(e) {
		let {
			ixData: t
		} = e.getState(), {
			eventTypeMap: n
		} = t;
		Tv(e), (0, tn.default)(n, (i, o) => {
			let s = lv[o];
			if (!s) {
				console.warn(`IX2 event type not configured: ${o}`);
				return
			}
			AF({
				logic: s,
				store: e,
				events: i
			})
		});
		let {
			ixSession: r
		} = e.getState();
		r.eventListeners.length && bF(e)
	}

	function bF(e) {
		let t = () => {
			Tv(e)
		};
		IF.forEach(n => {
			window.addEventListener(n, t), e.dispatch(Cr(window, [n, t]))
		}), t()
	}

	function Tv(e) {
		let {
			ixSession: t,
			ixData: n
		} = e.getState(), r = window.innerWidth;
		if (r !== t.viewportWidth) {
			let {
				mediaQueries: i
			} = n;
			e.dispatch(zo({
				width: r,
				mediaQueries: i
			}))
		}
	}

	function AF({
		logic: e,
		store: t,
		events: n
	}) {
		OF(n);
		let {
			types: r,
			handler: i
		} = e, {
			ixData: o
		} = t.getState(), {
			actionLists: s
		} = o, a = TF(n, xF);
		if (!(0, hv.default)(a)) return;
		(0, tn.default)(a, (d, m) => {
			let v = n[m],
				{
					action: E,
					id: b,
					mediaQueries: x = o.mediaQueryKeys
				} = v,
				{
					actionListId: T
				} = E.config;
			rF(x, o.mediaQueryKeys) || t.dispatch(jo()), E.actionTypeId === Pe.GENERAL_CONTINUOUS_ACTION && (Array.isArray(v.config) ? v.config : [v.config]).forEach(P => {
				let {
					continuousParameterGroupId: D
				} = P, F = (0, lt.default)(s, `${T}.continuousParameterGroups`, []), M = (0, gv.default)(F, ({
					id: Q
				}) => Q === D), Y = (P.smoothing || 0) / 100, K = (P.restingState || 0) / 100;
				M && d.forEach((Q, ee) => {
					let ne = b + ua + ee;
					yF({
						store: t,
						eventStateKey: ne,
						eventTarget: Q,
						eventId: b,
						eventConfig: P,
						actionListId: T,
						parameterGroup: M,
						smoothing: Y,
						restingValue: K
					})
				})
			}), (E.actionTypeId === Pe.GENERAL_START_ACTION || sa(E.actionTypeId)) && wv({
				store: t,
				actionListId: T,
				eventId: b
			})
		});
		let u = d => {
				let {
					ixSession: m
				} = t.getState();
				wF(a, (v, E, b) => {
					let x = n[E],
						T = m.eventState[b],
						{
							action: L,
							mediaQueries: P = o.mediaQueryKeys
						} = x;
					if (!Br(P, m.mediaQueryKey)) return;
					let D = (F = {}) => {
						let M = i({
							store: t,
							element: v,
							event: x,
							eventConfig: F,
							nativeEvent: d,
							eventStateKey: b
						}, T);
						iF(M, T) || t.dispatch(Uo(b, M))
					};
					L.actionTypeId === Pe.GENERAL_CONTINUOUS_ACTION ? (Array.isArray(x.config) ? x.config : [x.config]).forEach(D) : D()
				})
			},
			l = (0, Ev.default)(u, sF),
			_ = ({
				target: d = document,
				types: m,
				throttle: v
			}) => {
				m.split(" ").filter(Boolean).forEach(E => {
					let b = v ? l : u;
					d.addEventListener(E, b), t.dispatch(Cr(d, [E, b]))
				})
			};
		Array.isArray(r) ? r.forEach(_) : typeof r == "string" && _(e)
	}

	function OF(e) {
		if (!aF) return;
		let t = {},
			n = "";
		for (let r in e) {
			let {
				eventTypeId: i,
				target: o
			} = e[r], s = Yo(o);
			t[s] || (i === je.MOUSE_CLICK || i === je.MOUSE_SECOND_CLICK) && (t[s] = !0, n += s + "{cursor: pointer;touch-action: manipulation;}")
		}
		if (n) {
			let r = document.createElement("style");
			r.textContent = n, document.body.appendChild(r)
		}
	}

	function wv({
		store: e,
		actionListId: t,
		eventId: n
	}) {
		let {
			ixData: r,
			ixSession: i
		} = e.getState(), {
			actionLists: o,
			events: s
		} = r, a = s[n], u = o[t];
		if (u && u.useFirstGroupAsInitialState) {
			let l = (0, lt.default)(u, "actionItemGroups[0].actionItems", []),
				_ = (0, lt.default)(a, "mediaQueries", r.mediaQueryKeys);
			if (!Br(_, i.mediaQueryKey)) return;
			l.forEach(d => {
				let {
					config: m,
					actionTypeId: v
				} = d, E = m?.target?.useEventTarget === !0 && m?.target?.objectId == null ? {
					target: a.target,
					targets: a.targets
				} : m, b = Hr({
					config: E,
					event: a,
					elementApi: De
				}), x = zr(v);
				b.forEach(T => {
					let L = x ? la(v)(T, d) : null;
					fa({
						destination: ca({
							element: T,
							actionItem: d,
							elementApi: De
						}, L),
						immediate: !0,
						store: e,
						element: T,
						eventId: n,
						actionItem: d,
						actionListId: t,
						pluginInstance: L
					})
				})
			})
		}
	}

	function xv({
		store: e
	}) {
		let {
			ixInstances: t
		} = e.getState();
		(0, tn.default)(t, n => {
			if (!n.continuous) {
				let {
					actionListId: r,
					verbose: i
				} = n;
				da(n, e), i && e.dispatch(Jt({
					actionListId: r,
					isPlaying: !1
				}))
			}
		})
	}

	function en({
		store: e,
		eventId: t,
		eventTarget: n,
		eventStateKey: r,
		actionListId: i
	}) {
		let {
			ixInstances: o,
			ixSession: s
		} = e.getState(), a = s.hasBoundaryNodes && n ? Rn(n, Wr) : null;
		(0, tn.default)(o, u => {
			let l = (0, lt.default)(u, "actionItem.config.target.boundaryMode"),
				_ = r ? u.eventStateKey === r : !0;
			if (u.actionListId === i && u.eventId === t && _) {
				if (a && l && !Qo(a, u.element)) return;
				da(u, e), u.verbose && e.dispatch(Jt({
					actionListId: i,
					isPlaying: !1
				}))
			}
		})
	}

	function Nn({
		store: e,
		eventId: t,
		eventTarget: n,
		eventStateKey: r,
		actionListId: i,
		groupIndex: o = 0,
		immediate: s,
		verbose: a
	}) {
		let {
			ixData: u,
			ixSession: l
		} = e.getState(), {
			events: _
		} = u, d = _[t] || {}, {
			mediaQueries: m = u.mediaQueryKeys
		} = d, v = (0, lt.default)(u, `actionLists.${i}`, {}), {
			actionItemGroups: E,
			useFirstGroupAsInitialState: b
		} = v;
		if (!E || !E.length) return !1;
		o >= E.length && (0, lt.default)(d, "config.loop") && (o = 0), o === 0 && b && o++;
		let T = (o === 0 || o === 1 && b) && sa(d.action?.actionTypeId) ? d.config.delay : void 0,
			L = (0, lt.default)(E, [o, "actionItems"], []);
		if (!L.length || !Br(m, l.mediaQueryKey)) return !1;
		let P = l.hasBoundaryNodes && n ? Rn(n, Wr) : null,
			D = KM(L),
			F = !1;
		return L.forEach((M, Y) => {
			let {
				config: K,
				actionTypeId: Q
			} = M, ee = zr(Q), {
				target: ne
			} = K;
			if (!ne) return;
			let V = ne.boundaryMode ? P : null;
			Hr({
				config: K,
				event: d,
				eventTarget: n,
				elementRoot: V,
				elementApi: De
			}).forEach((q, z) => {
				let W = ee ? la(Q)(q, M) : null,
					te = ee ? oF(Q)(q, M) : null;
				F = !0;
				let re = D === Y && z === 0,
					ce = YM({
						element: q,
						actionItem: M
					}),
					fe = ca({
						element: q,
						actionItem: M,
						elementApi: De
					}, W);
				fa({
					store: e,
					element: q,
					actionItem: M,
					eventId: t,
					eventTarget: n,
					eventStateKey: r,
					actionListId: i,
					groupIndex: o,
					isCarrier: re,
					computedStyle: ce,
					destination: fe,
					immediate: s,
					verbose: a,
					pluginInstance: W,
					pluginDuration: te,
					instanceDelay: T
				})
			})
		}), F
	}

	function fa(e) {
		let {
			store: t,
			computedStyle: n,
			...r
		} = e, {
			element: i,
			actionItem: o,
			immediate: s,
			pluginInstance: a,
			continuous: u,
			restingValue: l,
			eventId: _
		} = r, d = !u, m = zM(), {
			ixElements: v,
			ixSession: E,
			ixData: b
		} = t.getState(), x = BM(v, i), {
			refState: T
		} = v[x] || {}, L = $o(i), P = E.reducedMotion && wi[o.actionTypeId], D;
		if (P && u) switch (b.events[_]?.eventTypeId) {
			case je.MOUSE_MOVE:
			case je.MOUSE_MOVE_IN_VIEWPORT:
				D = l;
				break;
			default:
				D = .5;
				break
		}
		let F = QM(i, T, n, o, De, a);
		if (t.dispatch(Wo({
				instanceId: m,
				elementId: x,
				origin: F,
				refType: L,
				skipMotion: P,
				skipToValue: D,
				...r
			})), Av(document.body, "ix2-animation-started", m), s) {
			SF(t, m);
			return
		}
		At({
			store: t,
			select: ({
				ixInstances: M
			}) => M[m],
			onChange: Ov
		}), d && t.dispatch(Pr(m, E.tick))
	}

	function da(e, t) {
		Av(document.body, "ix2-animation-stopping", {
			instanceId: e.id,
			state: t.getState()
		});
		let {
			elementId: n,
			actionItem: r
		} = e, {
			ixElements: i
		} = t.getState(), {
			ref: o,
			refType: s
		} = i[n] || {};
		s === _v && eF(o, r, De), t.dispatch(Ho(e.id))
	}

	function Av(e, t, n) {
		let r = document.createEvent("CustomEvent");
		r.initCustomEvent(t, !0, !0, n), e.dispatchEvent(r)
	}

	function SF(e, t) {
		let {
			ixParameters: n
		} = e.getState();
		e.dispatch(Pr(t, 0)), e.dispatch(Lr(performance.now(), n));
		let {
			ixInstances: r
		} = e.getState();
		Ov(r[t], e)
	}

	function Ov(e, t) {
		let {
			active: n,
			continuous: r,
			complete: i,
			elementId: o,
			actionItem: s,
			actionTypeId: a,
			renderType: u,
			current: l,
			groupIndex: _,
			eventId: d,
			eventTarget: m,
			eventStateKey: v,
			actionListId: E,
			isCarrier: b,
			styleProp: x,
			verbose: T,
			pluginInstance: L
		} = e, {
			ixData: P,
			ixSession: D
		} = t.getState(), {
			events: F
		} = P, M = F && F[d] ? F[d] : {}, {
			mediaQueries: Y = P.mediaQueryKeys
		} = M;
		if (Br(Y, D.mediaQueryKey) && (r || n || i)) {
			if (l || u === HM && i) {
				t.dispatch(Bo(o, a, l, s));
				let {
					ixElements: K
				} = t.getState(), {
					ref: Q,
					refType: ee,
					refState: ne
				} = K[o] || {}, V = ne && ne[a];
				(ee === _v || zr(a)) && jM(Q, ne, V, d, s, x, De, u, L)
			}
			if (i) {
				if (b) {
					let K = Nn({
						store: t,
						eventId: d,
						eventTarget: m,
						eventStateKey: v,
						actionListId: E,
						groupIndex: _ + 1,
						verbose: T
					});
					T && !K && t.dispatch(Jt({
						actionListId: E,
						isPlaying: !1
					}))
				}
				da(e, t)
			}
		}
	}
	var gv, lt, hv, vv, mv, yv, tn, Ev, Ur, WM, sa, ua, Wr, _v, HM, dv, Hr, BM, ca, At, zM, jM, Iv, KM, YM, QM, $M, ZM, JM, Br, eF, tF, nF, rF, iF, zr, la, oF, pv, aF, sF, IF, TF, wF, xF, aa = ye(() => {
		"use strict";
		gv = ge(Ji()), lt = ge(fr()), hv = ge(Xp()), vv = ge(pg()), mv = ge(hg()), yv = ge(mg()), tn = ge(Tg()), Ev = ge(Cg());
		qe();
		Ur = ge(xt());
		Nr();
		Fg();
		fv();
		WM = Object.keys(Wn), sa = e => WM.includes(e), {
			COLON_DELIMITER: ua,
			BOUNDARY_SELECTOR: Wr,
			HTML_ELEMENT: _v,
			RENDER_GENERAL: HM,
			W_MOD_IX: dv
		} = Se, {
			getAffectedElements: Hr,
			getElementId: BM,
			getDestinationValues: ca,
			observeStore: At,
			getInstanceId: zM,
			renderHTMLElement: jM,
			clearAllStyles: Iv,
			getMaxDurationItemIndex: KM,
			getComputedStyle: YM,
			getInstanceOrigin: QM,
			reduceListToGroup: $M,
			shouldNamespaceEventParameter: ZM,
			getNamespacedParameterId: JM,
			shouldAllowMediaQuery: Br,
			cleanupHTMLElement: eF,
			clearObjectCache: tF,
			stringifyTarget: nF,
			mediaQueriesEqual: rF,
			shallowEqual: iF
		} = Ur.IX2VanillaUtils, {
			isPluginType: zr,
			createPluginInstance: la,
			getPluginDuration: oF
		} = Ur.IX2VanillaPlugins, pv = navigator.userAgent, aF = pv.match(/iPad/i) || pv.match(/iPhone/), sF = 12;
		IF = ["resize", "orientationchange"];
		TF = (e, t) => (0, vv.default)((0, yv.default)(e, t), mv.default), wF = (e, t) => {
			(0, tn.default)(e, (n, r) => {
				n.forEach((i, o) => {
					let s = r + ua + o;
					t(i, r, s)
				})
			})
		}, xF = e => {
			let t = {
				target: e.target,
				targets: e.targets
			};
			return Hr({
				config: t,
				elementApi: De
			})
		}
	});
	var Lv = g(ga => {
		"use strict";
		Object.defineProperty(ga, "__esModule", {
			value: !0
		});

		function RF(e, t) {
			for (var n in t) Object.defineProperty(e, n, {
				enumerable: !0,
				get: t[n]
			})
		}
		RF(ga, {
			actions: function() {
				return PF
			},
			destroy: function() {
				return Cv
			},
			init: function() {
				return FF
			},
			setEnv: function() {
				return MF
			},
			store: function() {
				return Yr
			}
		});
		var CF = Ii(),
			LF = NF((bp(), $e(Ip))),
			pa = (aa(), $e(Sv)),
			PF = DF((Nr(), $e(Pg)));

		function NF(e) {
			return e && e.__esModule ? e : {
				default: e
			}
		}

		function Rv(e) {
			if (typeof WeakMap != "function") return null;
			var t = new WeakMap,
				n = new WeakMap;
			return (Rv = function(r) {
				return r ? n : t
			})(e)
		}

		function DF(e, t) {
			if (!t && e && e.__esModule) return e;
			if (e === null || typeof e != "object" && typeof e != "function") return {
				default: e
			};
			var n = Rv(t);
			if (n && n.has(e)) return n.get(e);
			var r = {
					__proto__: null
				},
				i = Object.defineProperty && Object.getOwnPropertyDescriptor;
			for (var o in e)
				if (o !== "default" && Object.prototype.hasOwnProperty.call(e, o)) {
					var s = i ? Object.getOwnPropertyDescriptor(e, o) : null;
					s && (s.get || s.set) ? Object.defineProperty(r, o, s) : r[o] = e[o]
				} return r.default = e, n && n.set(e, r), r
		}
		var Yr = (0, CF.createStore)(LF.default);

		function MF(e) {
			e() && (0, pa.observeRequests)(Yr)
		}

		function FF(e) {
			Cv(), (0, pa.startEngine)({
				store: Yr,
				rawData: e,
				allowEvents: !0
			})
		}

		function Cv() {
			(0, pa.stopEngine)(Yr)
		}
	});
	var Mv = g((QG, Dv) => {
		"use strict";
		var Pv = Le(),
			Nv = Lv();
		Nv.setEnv(Pv.env);
		Pv.define("ix2", Dv.exports = function() {
			return Nv
		})
	});
	var qv = g(($G, Fv) => {
		"use strict";
		var nn = Le();
		nn.define("links", Fv.exports = function(e, t) {
			var n = {},
				r = e(window),
				i, o = nn.env(),
				s = window.location,
				a = document.createElement("a"),
				u = "w--current",
				l = /index\.(html|php)$/,
				_ = /\/$/,
				d, m;
			n.ready = n.design = n.preview = v;

			function v() {
				i = o && nn.env("design"), m = nn.env("slug") || s.pathname || "", nn.scroll.off(b), d = [];
				for (var T = document.links, L = 0; L < T.length; ++L) E(T[L]);
				d.length && (nn.scroll.on(b), b())
			}

			function E(T) {
				if (!T.getAttribute("hreflang")) {
					var L = i && T.getAttribute("href-disabled") || T.getAttribute("href");
					if (a.href = L, !(L.indexOf(":") >= 0)) {
						var P = e(T);
						if (a.hash.length > 1 && a.host + a.pathname === s.host + s.pathname) {
							if (!/^#[a-zA-Z0-9\-\_]+$/.test(a.hash)) return;
							var D = e(a.hash);
							D.length && d.push({
								link: P,
								sec: D,
								active: !1
							});
							return
						}
						if (!(L === "#" || L === "")) {
							var F = a.href === s.href || L === m || l.test(L) && _.test(m);
							x(P, u, F)
						}
					}
				}
			}

			function b() {
				var T = r.scrollTop(),
					L = r.height();
				t.each(d, function(P) {
					if (!P.link.attr("hreflang")) {
						var D = P.link,
							F = P.sec,
							M = F.offset().top,
							Y = F.outerHeight(),
							K = L * .5,
							Q = F.is(":visible") && M + Y - K >= T && M + K <= T + L;
						P.active !== Q && (P.active = Q, x(D, u, Q))
					}
				})
			}

			function x(T, L, P) {
				var D = T.hasClass(L);
				P && D || !P && !D || (P ? T.addClass(L) : T.removeClass(L))
			}
			return n
		})
	});
	var Gv = g((ZG, kv) => {
		"use strict";
		var Qr = Le();
		Qr.define("scroll", kv.exports = function(e) {
			var t = {
					WF_CLICK_EMPTY: "click.wf-empty-link",
					WF_CLICK_SCROLL: "click.wf-scroll"
				},
				n = window.location,
				r = E() ? null : window.history,
				i = e(window),
				o = e(document),
				s = e(document.body),
				a = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || function(V) {
					window.setTimeout(V, 15)
				},
				u = Qr.env("editor") ? ".w-editor-body" : "body",
				l = "header, " + u + " > .header, " + u + " > .w-nav:not([data-no-scroll])",
				_ = 'a[href="#"]',
				d = 'a[href*="#"]:not(.w-tab-link):not(' + _ + ")",
				m = '.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}',
				v = document.createElement("style");
			v.appendChild(document.createTextNode(m));

			function E() {
				try {
					return !!window.frameElement
				} catch {
					return !0
				}
			}
			var b = /^#[a-zA-Z0-9][\w:.-]*$/;

			function x(V) {
				return b.test(V.hash) && V.host + V.pathname === n.host + n.pathname
			}
			let T = typeof window.matchMedia == "function" && window.matchMedia("(prefers-reduced-motion: reduce)");

			function L() {
				return document.body.getAttribute("data-wf-scroll-motion") === "none" || T.matches
			}

			function P(V, S) {
				var q;
				switch (S) {
					case "add":
						q = V.attr("tabindex"), q ? V.attr("data-wf-tabindex-swap", q) : V.attr("tabindex", "-1");
						break;
					case "remove":
						q = V.attr("data-wf-tabindex-swap"), q ? (V.attr("tabindex", q), V.removeAttr("data-wf-tabindex-swap")) : V.removeAttr("tabindex");
						break
				}
				V.toggleClass("wf-force-outline-none", S === "add")
			}

			function D(V) {
				var S = V.currentTarget;
				if (!(Qr.env("design") || window.$.mobile && /(?:^|\s)ui-link(?:$|\s)/.test(S.className))) {
					var q = x(S) ? S.hash : "";
					if (q !== "") {
						var z = e(q);
						z.length && (V && (V.preventDefault(), V.stopPropagation()), F(q, V), window.setTimeout(function() {
							M(z, function() {
								P(z, "add"), z.get(0).focus({
									preventScroll: !0
								}), P(z, "remove")
							})
						}, V ? 0 : 300))
					}
				}
			}

			function F(V) {
				if (n.hash !== V && r && r.pushState && !(Qr.env.chrome && n.protocol === "file:")) {
					var S = r.state && r.state.hash;
					S !== V && r.pushState({
						hash: V
					}, "", V)
				}
			}

			function M(V, S) {
				var q = i.scrollTop(),
					z = Y(V);
				if (q !== z) {
					var W = K(V, q, z),
						te = Date.now(),
						re = function() {
							var ce = Date.now() - te;
							window.scroll(0, Q(q, z, ce, W)), ce <= W ? a(re) : typeof S == "function" && S()
						};
					a(re)
				}
			}

			function Y(V) {
				var S = e(l),
					q = S.css("position") === "fixed" ? S.outerHeight() : 0,
					z = V.offset().top - q;
				if (V.data("scroll") === "mid") {
					var W = i.height() - q,
						te = V.outerHeight();
					te < W && (z -= Math.round((W - te) / 2))
				}
				return z
			}

			function K(V, S, q) {
				if (L()) return 0;
				var z = 1;
				return s.add(V).each(function(W, te) {
					var re = parseFloat(te.getAttribute("data-scroll-time"));
					!isNaN(re) && re >= 0 && (z = re)
				}), (472.143 * Math.log(Math.abs(S - q) + 125) - 2e3) * z
			}

			function Q(V, S, q, z) {
				return q > z ? S : V + (S - V) * ee(q / z)
			}

			function ee(V) {
				return V < .5 ? 4 * V * V * V : (V - 1) * (2 * V - 2) * (2 * V - 2) + 1
			}

			function ne() {
				var {
					WF_CLICK_EMPTY: V,
					WF_CLICK_SCROLL: S
				} = t;
				o.on(S, d, D), o.on(V, _, function(q) {
					q.preventDefault()
				}), document.head.insertBefore(v, document.head.firstChild)
			}
			return {
				ready: ne
			}
		})
	});
	var Xv = g((JG, Vv) => {
		"use strict";
		var qF = Le();
		qF.define("touch", Vv.exports = function(e) {
			var t = {},
				n = window.getSelection;
			e.event.special.tap = {
				bindType: "click",
				delegateType: "click"
			}, t.init = function(o) {
				return o = typeof o == "string" ? e(o).get(0) : o, o ? new r(o) : null
			};

			function r(o) {
				var s = !1,
					a = !1,
					u = Math.min(Math.round(window.innerWidth * .04), 40),
					l, _;
				o.addEventListener("touchstart", d, !1), o.addEventListener("touchmove", m, !1), o.addEventListener("touchend", v, !1), o.addEventListener("touchcancel", E, !1), o.addEventListener("mousedown", d, !1), o.addEventListener("mousemove", m, !1), o.addEventListener("mouseup", v, !1), o.addEventListener("mouseout", E, !1);

				function d(x) {
					var T = x.touches;
					T && T.length > 1 || (s = !0, T ? (a = !0, l = T[0].clientX) : l = x.clientX, _ = l)
				}

				function m(x) {
					if (s) {
						if (a && x.type === "mousemove") {
							x.preventDefault(), x.stopPropagation();
							return
						}
						var T = x.touches,
							L = T ? T[0].clientX : x.clientX,
							P = L - _;
						_ = L, Math.abs(P) > u && n && String(n()) === "" && (i("swipe", x, {
							direction: P > 0 ? "right" : "left"
						}), E())
					}
				}

				function v(x) {
					if (s && (s = !1, a && x.type === "mouseup")) {
						x.preventDefault(), x.stopPropagation(), a = !1;
						return
					}
				}

				function E() {
					s = !1
				}

				function b() {
					o.removeEventListener("touchstart", d, !1), o.removeEventListener("touchmove", m, !1), o.removeEventListener("touchend", v, !1), o.removeEventListener("touchcancel", E, !1), o.removeEventListener("mousedown", d, !1), o.removeEventListener("mousemove", m, !1), o.removeEventListener("mouseup", v, !1), o.removeEventListener("mouseout", E, !1), o = null
				}
				this.destroy = b
			}

			function i(o, s, a) {
				var u = e.Event(o, {
					originalEvent: s
				});
				e(s.target).trigger(u, a)
			}
			return t.instance = t.init(document), t
		})
	});
	var Hv = g((eV, Wv) => {
		"use strict";
		var Ot = Le(),
			kF = on(),
			Qe = {
				ARROW_LEFT: 37,
				ARROW_UP: 38,
				ARROW_RIGHT: 39,
				ARROW_DOWN: 40,
				ESCAPE: 27,
				SPACE: 32,
				ENTER: 13,
				HOME: 36,
				END: 35
			},
			Uv = !0,
			GF = /^#[a-zA-Z0-9\-_]+$/;
		Ot.define("dropdown", Wv.exports = function(e, t) {
			var n = t.debounce,
				r = {},
				i = Ot.env(),
				o = !1,
				s, a = Ot.env.touch,
				u = ".w-dropdown",
				l = "w--open",
				_ = kF.triggers,
				d = 900,
				m = "focusout" + u,
				v = "keydown" + u,
				E = "mouseenter" + u,
				b = "mousemove" + u,
				x = "mouseleave" + u,
				T = (a ? "click" : "mouseup") + u,
				L = "w-close" + u,
				P = "setting" + u,
				D = e(document),
				F;
			r.ready = M, r.design = function() {
				o && S(), o = !1, M()
			}, r.preview = function() {
				o = !0, M()
			};

			function M() {
				s = i && Ot.env("design"), F = D.find(u), F.each(Y)
			}

			function Y(c, A) {
				var O = e(A),
					R = e.data(A, u);
				R || (R = e.data(A, u, {
					open: !1,
					el: O,
					config: {},
					selectedIdx: -1
				})), R.toggle = R.el.children(".w-dropdown-toggle"), R.list = R.el.children(".w-dropdown-list"), R.links = R.list.find("a:not(.w-dropdown .w-dropdown a)"), R.complete = W(R), R.mouseLeave = re(R), R.mouseUpOutside = z(R), R.mouseMoveOutside = ce(R), K(R);
				var U = R.toggle.attr("id"),
					J = R.list.attr("id");
				U || (U = "w-dropdown-toggle-" + c), J || (J = "w-dropdown-list-" + c), R.toggle.attr("id", U), R.toggle.attr("aria-controls", J), R.toggle.attr("aria-haspopup", "menu"), R.toggle.attr("aria-expanded", "false"), R.toggle.find(".w-icon-dropdown-toggle").attr("aria-hidden", "true"), R.toggle.prop("tagName") !== "BUTTON" && (R.toggle.attr("role", "button"), R.toggle.attr("tabindex") || R.toggle.attr("tabindex", "0")), R.list.attr("id", J), R.list.attr("aria-labelledby", U), R.links.each(function(h, X) {
					X.hasAttribute("tabindex") || X.setAttribute("tabindex", "0"), GF.test(X.hash) && X.addEventListener("click", V.bind(null, R))
				}), R.el.off(u), R.toggle.off(u), R.nav && R.nav.off(u);
				var H = ee(R, Uv);
				s && R.el.on(P, Q(R)), s || (i && (R.hovering = !1, V(R)), R.config.hover && R.toggle.on(E, te(R)), R.el.on(L, H), R.el.on(v, fe(R)), R.el.on(m, p(R)), R.toggle.on(T, H), R.toggle.on(v, y(R)), R.nav = R.el.closest(".w-nav"), R.nav.on(L, H))
			}

			function K(c) {
				var A = Number(c.el.css("z-index"));
				c.manageZ = A === d || A === d + 1, c.config = {
					hover: c.el.attr("data-hover") === "true" && !a,
					delay: c.el.attr("data-delay")
				}
			}

			function Q(c) {
				return function(A, O) {
					O = O || {}, K(c), O.open === !0 && ne(c), O.open === !1 && V(c, {
						immediate: !0
					})
				}
			}

			function ee(c, A) {
				return n(function(O) {
					if (c.open || O && O.type === "w-close") return V(c, {
						forceClose: A
					});
					ne(c)
				})
			}

			function ne(c) {
				if (!c.open) {
					q(c), c.open = !0, c.list.addClass(l), c.toggle.addClass(l), c.toggle.attr("aria-expanded", "true"), _.intro(0, c.el[0]), Ot.redraw.up(), c.manageZ && c.el.css("z-index", d + 1);
					var A = Ot.env("editor");
					s || D.on(T, c.mouseUpOutside), c.hovering && !A && c.el.on(x, c.mouseLeave), c.hovering && A && D.on(b, c.mouseMoveOutside), window.clearTimeout(c.delayId)
				}
			}

			function V(c, {
				immediate: A,
				forceClose: O
			} = {}) {
				if (c.open && !(c.config.hover && c.hovering && !O)) {
					c.toggle.attr("aria-expanded", "false"), c.open = !1;
					var R = c.config;
					if (_.outro(0, c.el[0]), D.off(T, c.mouseUpOutside), D.off(b, c.mouseMoveOutside), c.el.off(x, c.mouseLeave), window.clearTimeout(c.delayId), !R.delay || A) return c.complete();
					c.delayId = window.setTimeout(c.complete, R.delay)
				}
			}

			function S() {
				D.find(u).each(function(c, A) {
					e(A).triggerHandler(L)
				})
			}

			function q(c) {
				var A = c.el[0];
				F.each(function(O, R) {
					var U = e(R);
					U.is(A) || U.has(A).length || U.triggerHandler(L)
				})
			}

			function z(c) {
				return c.mouseUpOutside && D.off(T, c.mouseUpOutside), n(function(A) {
					if (c.open) {
						var O = e(A.target);
						if (!O.closest(".w-dropdown-toggle").length) {
							var R = e.inArray(c.el[0], O.parents(u)) === -1,
								U = Ot.env("editor");
							if (R) {
								if (U) {
									var J = O.parents().length === 1 && O.parents("svg").length === 1,
										H = O.parents(".w-editor-bem-EditorHoverControls").length;
									if (J || H) return
								}
								V(c)
							}
						}
					}
				})
			}

			function W(c) {
				return function() {
					c.list.removeClass(l), c.toggle.removeClass(l), c.manageZ && c.el.css("z-index", "")
				}
			}

			function te(c) {
				return function() {
					c.hovering = !0, ne(c)
				}
			}

			function re(c) {
				return function() {
					c.hovering = !1, c.links.is(":focus") || V(c)
				}
			}

			function ce(c) {
				return n(function(A) {
					if (c.open) {
						var O = e(A.target),
							R = e.inArray(c.el[0], O.parents(u)) === -1;
						if (R) {
							var U = O.parents(".w-editor-bem-EditorHoverControls").length,
								J = O.parents(".w-editor-bem-RTToolbar").length,
								H = e(".w-editor-bem-EditorOverlay"),
								h = H.find(".w-editor-edit-outline").length || H.find(".w-editor-bem-RTToolbar").length;
							if (U || J || h) return;
							c.hovering = !1, V(c)
						}
					}
				})
			}

			function fe(c) {
				return function(A) {
					if (!(s || !c.open)) switch (c.selectedIdx = c.links.index(document.activeElement), A.keyCode) {
						case Qe.HOME:
							return c.open ? (c.selectedIdx = 0, I(c), A.preventDefault()) : void 0;
						case Qe.END:
							return c.open ? (c.selectedIdx = c.links.length - 1, I(c), A.preventDefault()) : void 0;
						case Qe.ESCAPE:
							return V(c), c.toggle.focus(), A.stopPropagation();
						case Qe.ARROW_RIGHT:
						case Qe.ARROW_DOWN:
							return c.selectedIdx = Math.min(c.links.length - 1, c.selectedIdx + 1), I(c), A.preventDefault();
						case Qe.ARROW_LEFT:
						case Qe.ARROW_UP:
							return c.selectedIdx = Math.max(-1, c.selectedIdx - 1), I(c), A.preventDefault()
					}
				}
			}

			function I(c) {
				c.links[c.selectedIdx] && c.links[c.selectedIdx].focus()
			}

			function y(c) {
				var A = ee(c, Uv);
				return function(O) {
					if (!s) {
						if (!c.open) switch (O.keyCode) {
							case Qe.ARROW_UP:
							case Qe.ARROW_DOWN:
								return O.stopPropagation()
						}
						switch (O.keyCode) {
							case Qe.SPACE:
							case Qe.ENTER:
								return A(), O.stopPropagation(), O.preventDefault()
						}
					}
				}
			}

			function p(c) {
				return n(function(A) {
					var {
						relatedTarget: O,
						target: R
					} = A, U = c.el[0], J = U.contains(O) || U.contains(R);
					return J || V(c), A.stopPropagation()
				})
			}
			return r
		})
	});
	var Bv = g(ha => {
		"use strict";
		Object.defineProperty(ha, "__esModule", {
			value: !0
		});
		Object.defineProperty(ha, "default", {
			enumerable: !0,
			get: function() {
				return VF
			}
		});

		function VF(e, t, n, r, i, o, s, a, u, l, _, d, m) {
			return function(v) {
				e(v);
				var E = v.form,
					b = {
						name: E.attr("data-name") || E.attr("name") || "Untitled Form",
						pageId: E.attr("data-wf-page-id") || "",
						elementId: E.attr("data-wf-element-id") || "",
						source: t.href,
						test: n.env(),
						fields: {},
						fileUploads: {},
						dolphin: /pass[\s-_]?(word|code)|secret|login|credentials/i.test(E.html()),
						trackingCookies: r()
					};
				let x = E.attr("data-wf-flow");
				x && (b.wfFlow = x), i(v);
				var T = o(E, b.fields);
				if (T) return s(T);
				if (b.fileUploads = a(E), u(v), !l) {
					_(v);
					return
				}
				d.ajax({
					url: m,
					type: "POST",
					data: b,
					dataType: "json",
					crossDomain: !0
				}).done(function(L) {
					L && L.code === 200 && (v.success = !0), _(v)
				}).fail(function() {
					_(v)
				})
			}
		}
	});
	var jv = g((nV, zv) => {
		"use strict";
		var $r = Le(),
			XF = (e, t, n, r) => {
				let i = document.createElement("div");
				t.appendChild(i), turnstile.render(i, {
					sitekey: e,
					callback: function(o) {
						n(o)
					},
					"error-callback": function() {
						r()
					}
				})
			};
		$r.define("forms", zv.exports = function(e, t) {
			let n = "TURNSTILE_LOADED";
			var r = {},
				i = e(document),
				o, s = window.location,
				a = window.XDomainRequest && !window.atob,
				u = ".w-form",
				l, _ = /e(-)?mail/i,
				d = /^\S+@\S+$/,
				m = window.alert,
				v = $r.env(),
				E, b, x;
			let T = i.find("[data-turnstile-sitekey]").data("turnstile-sitekey"),
				L;
			var P = /list-manage[1-9]?.com/i,
				D = t.debounce(function() {
					m("Oops! This page has improperly configured forms. Please contact your website administrator to fix this issue.")
				}, 100);
			r.ready = r.design = r.preview = function() {
				M(), F(), !v && !E && K()
			};

		function F() {
			// DISABLED WEBFLOW API - Using custom PHP email handler instead
			// l = e("html").attr("data-wf-site"), b = "https://webflow.com/api/v1/form/" + l, a && b.indexOf("https://webflow.com") >= 0 && (b = b.replace("https://webflow.com", "https://formdata.webflow.com")), x = `${b}/signFile`, o = e(u + " form"), o.length && o.each(Y)
			
			// Prevent Webflow from handling forms - our custom handler in footer.php does it
			//console.log('Webflow form API disabled - using custom PHP email handler');
			return;
		}

			function M() {
				T && (L = document.createElement("script"), L.src = "https://challenges.cloudflare.com/turnstile/v0/api.js", document.head.appendChild(L), L.onload = () => {
					i.trigger(n)
				})
			}

		function Y(p, c) {
			// DISABLED WEBFLOW FORM PROCESSING - Using custom PHP email handler instead
			//console.log('Webflow form processing disabled for form:', c);
			return;
			
			/* ORIGINAL CODE DISABLED
			var A = e(c),
				O = e.data(c, u);
			O || (O = e.data(c, u, {
				form: A
			})), Q(O);
			var R = A.closest("div.w-form");
			O.done = R.find("> .w-form-done"), O.fail = R.find("> .w-form-fail"), O.fileUploads = R.find(".w-file-upload"), O.fileUploads.each(function(H) {
				fe(H, O)
			}), T && (O.wait = !1, ee(O), i.on(typeof turnstile < "u" ? "ready" : n, function() {
				XF(T, c, H => {
					O.turnstileToken = H, Q(O)
				}, () => {
					ee(O)
				})
			}));
			var U = O.form.attr("aria-label") || O.form.attr("data-name") || "Form";
			O.done.attr("aria-label") || O.form.attr("aria-label", U), O.done.attr("tabindex", "-1"), O.done.attr("role", "region"), O.done.attr("aria-label") || O.done.attr("aria-label", U + " success"), O.fail.attr("tabindex", "-1"), O.fail.attr("role", "region"), O.fail.attr("aria-label") || O.fail.attr("aria-label", U + " failure");
			var J = O.action = A.attr("action");
			if (O.handler = null, O.redirect = A.attr("data-redirect"), P.test(J)) {
				O.handler = te;
				return
			}
			if (!J) {
				if (l) {
					O.handler = (() => {
						let H = Bv().default;
						return H(Q, s, $r, q, ce, ne, m, V, ee, l, re, e, b)
					})();
					return
				}
				D()
			}
			*/
		}

		function K() {
			// DISABLED WEBFLOW SUBMIT HANDLER - Using custom PHP email handler instead
			//console.log('Webflow submit handler disabled - using custom PHP handler');
			return;
			
			/* ALL ORIGINAL CODE DISABLED
			E = !0, i.on("submit", u + " form", function(H) {
				var h = e.data(this, u);
				h.handler && (h.evt = H, h.handler(h))
			});
			let p = ".w-checkbox-input",
				c = ".w-radio-input",
				A = "w--redirected-checked",
				O = "w--redirected-focus",
				R = "w--redirected-focus-visible",
				U = ":focus-visible, [data-wf-focus-visible]",
				J = [
					["checkbox", p],
					["radio", c]
				];
			i.on("change", u + ' form input[type="checkbox"]:not(' + p + ")", H => {
				e(H.target).siblings(p).toggleClass(A)
			}), i.on("change", u + ' form input[type="radio"]', H => {
				e(`input[name="${H.target.name}"]:not(${p})`).map((X, Z) => e(Z).siblings(c).removeClass(A));
				let h = e(H.target);
				h.hasClass("w-radio-input") || h.siblings(c).addClass(A)
			}), J.forEach(([H, h]) => {
				i.on("focus", u + ` form input[type="${H}"]:not(` + h + ")", X => {
					e(X.target).siblings(h).addClass(O), e(X.target).filter(U).siblings(h).addClass(R)
				}), i.on("blur", u + ` form input[type="${H}"]:not(` + h + ")", X => {
					e(X.target).siblings(h).removeClass(`${O} ${R}`)
				})
			})
			*/
		}

			function Q(p) {
				var c = p.btn = p.form.find(':input[type="submit"]');
				p.wait = p.btn.attr("data-wait") || null, p.success = !1, c.prop("disabled", !!(T && !p.turnstileToken)), p.label && c.val(p.label)
			}

			function ee(p) {
				var c = p.btn,
					A = p.wait;
				c.prop("disabled", !0), A && (p.label = c.val(), c.val(A))
			}

			function ne(p, c) {
				var A = null;
				return c = c || {}, p.find(':input:not([type="submit"]):not([type="file"])').each(function(O, R) {
					var U = e(R),
						J = U.attr("type"),
						H = U.attr("data-name") || U.attr("name") || "Field " + (O + 1);
					H = encodeURIComponent(H);
					var h = U.val();
					if (J === "checkbox") h = U.is(":checked");
					else if (J === "radio") {
						if (c[H] === null || typeof c[H] == "string") return;
						h = p.find('input[name="' + U.attr("name") + '"]:checked').val() || null
					}
					typeof h == "string" && (h = e.trim(h)), c[H] = h, A = A || z(U, J, H, h)
				}), A
			}

			function V(p) {
				var c = {};
				return p.find(':input[type="file"]').each(function(A, O) {
					var R = e(O),
						U = R.attr("data-name") || R.attr("name") || "File " + (A + 1),
						J = R.attr("data-value");
					typeof J == "string" && (J = e.trim(J)), c[U] = J
				}), c
			}
			let S = {
				_mkto_trk: "marketo"
			};

			function q() {
				return document.cookie.split("; ").reduce(function(c, A) {
					let O = A.split("="),
						R = O[0];
					if (R in S) {
						let U = S[R],
							J = O.slice(1).join("=");
						c[U] = J
					}
					return c
				}, {})
			}

			function z(p, c, A, O) {
				var R = null;
				return c === "password" ? R = "Passwords cannot be submitted." : p.attr("required") ? O ? _.test(p.attr("type")) && (d.test(O) || (R = "Please enter a valid email address for: " + A)) : R = "Please fill out the required field: " + A : A === "g-recaptcha-response" && !O && (R = "Please confirm you\u2019re not a robot."), R
			}

			function W(p) {
				ce(p), re(p)
			}

			function te(p) {
				Q(p);
				var c = p.form,
					A = {};
				if (/^https/.test(s.href) && !/^https/.test(p.action)) {
					c.attr("method", "post");
					return
				}
				ce(p);
				var O = ne(c, A);
				if (O) return m(O);
				ee(p);
				var R;
				t.each(A, function(h, X) {
					_.test(X) && (A.EMAIL = h), /^((full[ _-]?)?name)$/i.test(X) && (R = h), /^(first[ _-]?name)$/i.test(X) && (A.FNAME = h), /^(last[ _-]?name)$/i.test(X) && (A.LNAME = h)
				}), R && !A.FNAME && (R = R.split(" "), A.FNAME = R[0], A.LNAME = A.LNAME || R[1]);
				var U = p.action.replace("/post?", "/post-json?") + "&c=?",
					J = U.indexOf("u=") + 2;
				J = U.substring(J, U.indexOf("&", J));
				var H = U.indexOf("id=") + 3;
				H = U.substring(H, U.indexOf("&", H)), A["b_" + J + "_" + H] = "", e.ajax({
					url: U,
					data: A,
					dataType: "jsonp"
				}).done(function(h) {
					p.success = h.result === "success" || /already/.test(h.msg), p.success || console.info("MailChimp error: " + h.msg), re(p)
				}).fail(function() {
					re(p)
				})
			}

			function re(p) {
				var c = p.form,
					A = p.redirect,
					O = p.success;
				if (O && A) {
					$r.location(A);
					return
				}
				p.done.toggle(O), p.fail.toggle(!O), O ? p.done.focus() : p.fail.focus(), c.toggle(!O), Q(p)
			}

			function ce(p) {
				p.evt && p.evt.preventDefault(), p.evt = null
			}

			function fe(p, c) {
				if (!c.fileUploads || !c.fileUploads[p]) return;
				var A, O = e(c.fileUploads[p]),
					R = O.find("> .w-file-upload-default"),
					U = O.find("> .w-file-upload-uploading"),
					J = O.find("> .w-file-upload-success"),
					H = O.find("> .w-file-upload-error"),
					h = R.find(".w-file-upload-input"),
					X = R.find(".w-file-upload-label"),
					Z = X.children(),
					j = H.find(".w-file-upload-error-msg"),
					de = J.find(".w-file-upload-file"),
					be = J.find(".w-file-remove-link"),
					xe = de.find(".w-file-upload-file-name"),
					f = j.attr("data-w-size-error"),
					w = j.attr("data-w-type-error"),
					C = j.attr("data-w-generic-error");
				if (v || X.on("click keydown", function(oe) {
						oe.type === "keydown" && oe.which !== 13 && oe.which !== 32 || (oe.preventDefault(), h.click())
					}), X.find(".w-icon-file-upload-icon").attr("aria-hidden", "true"), be.find(".w-icon-file-upload-remove").attr("aria-hidden", "true"), v) h.on("click", function(oe) {
					oe.preventDefault()
				}), X.on("click", function(oe) {
					oe.preventDefault()
				}), Z.on("click", function(oe) {
					oe.preventDefault()
				});
				else {
					be.on("click keydown", function(oe) {
						if (oe.type === "keydown") {
							if (oe.which !== 13 && oe.which !== 32) return;
							oe.preventDefault()
						}
						h.removeAttr("data-value"), h.val(""), xe.html(""), R.toggle(!0), J.toggle(!1), X.focus()
					}), h.on("change", function(oe) {
						A = oe.target && oe.target.files && oe.target.files[0], A && (R.toggle(!1), H.toggle(!1), U.toggle(!0), U.focus(), xe.text(A.name), se() || ee(c), c.fileUploads[p].uploading = !0, I(A, G))
					});
					var N = X.outerHeight();
					h.height(N), h.width(1)
				}

				function k(oe) {
					var B = oe.responseJSON && oe.responseJSON.msg,
						ue = C;
					typeof B == "string" && B.indexOf("InvalidFileTypeError") === 0 ? ue = w : typeof B == "string" && B.indexOf("MaxFileSizeError") === 0 && (ue = f), j.text(ue), h.removeAttr("data-value"), h.val(""), U.toggle(!1), R.toggle(!0), H.toggle(!0), H.focus(), c.fileUploads[p].uploading = !1, se() || Q(c)
				}

				function G(oe, B) {
					if (oe) return k(oe);
					var ue = B.fileName,
						le = B.postData,
						Ie = B.fileId,
						Ve = B.s3Url;
					h.attr("data-value", Ie), y(Ve, le, A, ue, ie)
				}

				function ie(oe) {
					if (oe) return k(oe);
					U.toggle(!1), J.css("display", "inline-block"), J.focus(), c.fileUploads[p].uploading = !1, se() || Q(c)
				}

				function se() {
					var oe = c.fileUploads && c.fileUploads.toArray() || [];
					return oe.some(function(B) {
						return B.uploading
					})
				}
			}

			function I(p, c) {
				var A = new URLSearchParams({
					name: p.name,
					size: p.size
				});
				e.ajax({
					type: "GET",
					url: `${x}?${A}`,
					crossDomain: !0
				}).done(function(O) {
					c(null, O)
				}).fail(function(O) {
					c(O)
				})
			}

			function y(p, c, A, O, R) {
				var U = new FormData;
				for (var J in c) U.append(J, c[J]);
				U.append("file", A, O), e.ajax({
					type: "POST",
					url: p,
					data: U,
					processData: !1,
					contentType: !1
				}).done(function() {
					R(null)
				}).fail(function(H) {
					R(H)
				})
			}
			return r
		})
	});
	var Qv = g((rV, Yv) => {
		"use strict";
		var va = Le(),
			Kv = "w-condition-invisible",
			UF = "." + Kv;

		function WF(e) {
			return e.filter(function(t) {
				return !Mn(t)
			})
		}

		function Mn(e) {
			return !!(e.$el && e.$el.closest(UF).length)
		}

		function ma(e, t) {
			for (var n = e; n >= 0; n--)
				if (!Mn(t[n])) return n;
			return -1
		}

		function ya(e, t) {
			for (var n = e; n <= t.length - 1; n++)
				if (!Mn(t[n])) return n;
			return -1
		}

		function HF(e, t) {
			return ma(e - 1, t) === -1
		}

		function BF(e, t) {
			return ya(e + 1, t) === -1
		}

		function Dn(e, t) {
			e.attr("aria-label") || e.attr("aria-label", t)
		}

		function zF(e, t, n, r) {
			var i = n.tram,
				o = Array.isArray,
				s = "w-lightbox",
				a = s + "-",
				u = /(^|\s+)/g,
				l = [],
				_, d, m, v = [];

			function E(y, p) {
				return l = o(y) ? y : [y], d || E.build(), WF(l).length > 1 && (d.items = d.empty, l.forEach(function(c, A) {
					var O = fe("thumbnail"),
						R = fe("item").prop("tabIndex", 0).attr("aria-controls", "w-lightbox-view").attr("role", "tab").append(O);
					Dn(R, `show item ${A+1} of ${l.length}`), Mn(c) && R.addClass(Kv), d.items = d.items.add(R), ee(c.thumbnailUrl || c.url, function(U) {
						U.prop("width") > U.prop("height") ? W(U, "wide") : W(U, "tall"), O.append(W(U, "thumbnail-image"))
					})
				}), d.strip.empty().append(d.items), W(d.content, "group")), i(te(d.lightbox, "hide").trigger("focus")).add("opacity .3s").start({
					opacity: 1
				}), W(d.html, "noscroll"), E.show(p || 0)
			}
			E.build = function() {
				return E.destroy(), d = {
					html: n(t.documentElement),
					empty: n()
				}, d.arrowLeft = fe("control left inactive").attr("role", "button").attr("aria-hidden", !0).attr("aria-controls", "w-lightbox-view"), d.arrowRight = fe("control right inactive").attr("role", "button").attr("aria-hidden", !0).attr("aria-controls", "w-lightbox-view"), d.close = fe("control close").attr("role", "button"), Dn(d.arrowLeft, "previous image"), Dn(d.arrowRight, "next image"), Dn(d.close, "close lightbox"), d.spinner = fe("spinner").attr("role", "progressbar").attr("aria-live", "polite").attr("aria-hidden", !1).attr("aria-busy", !0).attr("aria-valuemin", 0).attr("aria-valuemax", 100).attr("aria-valuenow", 0).attr("aria-valuetext", "Loading image"), d.strip = fe("strip").attr("role", "tablist"), m = new S(d.spinner, q("hide")), d.content = fe("content").append(d.spinner, d.arrowLeft, d.arrowRight, d.close), d.container = fe("container").append(d.content, d.strip), d.lightbox = fe("backdrop hide").append(d.container), d.strip.on("click", z("item"), P), d.content.on("swipe", D).on("click", z("left"), x).on("click", z("right"), T).on("click", z("close"), L).on("click", z("image, caption"), T), d.container.on("click", z("view"), L).on("dragstart", z("img"), M), d.lightbox.on("keydown", Y).on("focusin", F), n(r).append(d.lightbox), E
			}, E.destroy = function() {
				d && (te(d.html, "noscroll"), d.lightbox.remove(), d = void 0)
			}, E.show = function(y) {
				if (y !== _) {
					var p = l[y];
					if (!p) return E.hide();
					if (Mn(p)) {
						if (y < _) {
							var c = ma(y - 1, l);
							y = c > -1 ? c : y
						} else {
							var A = ya(y + 1, l);
							y = A > -1 ? A : y
						}
						p = l[y]
					}
					var O = _;
					_ = y, d.spinner.attr("aria-hidden", !1).attr("aria-busy", !0).attr("aria-valuenow", 0).attr("aria-valuetext", "Loading image"), m.show();
					var R = p.html && I(p.width, p.height) || p.url;
					return ee(R, function(U) {
						if (y !== _) return;
						var J = fe("figure", "figure").append(W(U, "image")),
							H = fe("frame").append(J),
							h = fe("view").prop("tabIndex", 0).attr("id", "w-lightbox-view").append(H),
							X, Z;
						p.html && (X = n(p.html), Z = X.is("iframe"), Z && X.on("load", j), J.append(W(X, "embed"))), p.caption && J.append(fe("caption", "figcaption").text(p.caption)), d.spinner.before(h), Z || j();

						function j() {
							if (d.spinner.attr("aria-hidden", !0).attr("aria-busy", !1).attr("aria-valuenow", 100).attr("aria-valuetext", "Loaded image"), m.hide(), y !== _) {
								h.remove();
								return
							}
							let de = HF(y, l);
							re(d.arrowLeft, "inactive", de), ce(d.arrowLeft, de), de && d.arrowLeft.is(":focus") && d.arrowRight.focus();
							let be = BF(y, l);
							if (re(d.arrowRight, "inactive", be), ce(d.arrowRight, be), be && d.arrowRight.is(":focus") && d.arrowLeft.focus(), d.view ? (i(d.view).add("opacity .3s").start({
									opacity: 0
								}).then(ne(d.view)), i(h).add("opacity .3s").add("transform .3s").set({
									x: y > O ? "80px" : "-80px"
								}).start({
									opacity: 1,
									x: 0
								})) : h.css("opacity", 1), d.view = h, d.view.prop("tabIndex", 0), d.items) {
								te(d.items, "active"), d.items.removeAttr("aria-selected");
								var xe = d.items.eq(y);
								W(xe, "active"), xe.attr("aria-selected", !0), V(xe)
							}
						}
					}), d.close.prop("tabIndex", 0), n(":focus").addClass("active-lightbox"), v.length === 0 && (n("body").children().each(function() {
						n(this).hasClass("w-lightbox-backdrop") || n(this).is("script") || (v.push({
							node: n(this),
							hidden: n(this).attr("aria-hidden"),
							tabIndex: n(this).attr("tabIndex")
						}), n(this).attr("aria-hidden", !0).attr("tabIndex", -1))
					}), d.close.focus()), E
				}
			}, E.hide = function() {
				return i(d.lightbox).add("opacity .3s").start({
					opacity: 0
				}).then(Q), E
			}, E.prev = function() {
				var y = ma(_ - 1, l);
				y > -1 && E.show(y)
			}, E.next = function() {
				var y = ya(_ + 1, l);
				y > -1 && E.show(y)
			};

			function b(y) {
				return function(p) {
					this === p.target && (p.stopPropagation(), p.preventDefault(), y())
				}
			}
			var x = b(E.prev),
				T = b(E.next),
				L = b(E.hide),
				P = function(y) {
					var p = n(this).index();
					y.preventDefault(), E.show(p)
				},
				D = function(y, p) {
					y.preventDefault(), p.direction === "left" ? E.next() : p.direction === "right" && E.prev()
				},
				F = function() {
					this.focus()
				};

			function M(y) {
				y.preventDefault()
			}

			function Y(y) {
				var p = y.keyCode;
				p === 27 || K(p, "close") ? E.hide() : p === 37 || K(p, "left") ? E.prev() : p === 39 || K(p, "right") ? E.next() : K(p, "item") && n(":focus").click()
			}

			function K(y, p) {
				if (y !== 13 && y !== 32) return !1;
				var c = n(":focus").attr("class"),
					A = q(p).trim();
				return c.includes(A)
			}

			function Q() {
				d && (d.strip.scrollLeft(0).empty(), te(d.html, "noscroll"), W(d.lightbox, "hide"), d.view && d.view.remove(), te(d.content, "group"), W(d.arrowLeft, "inactive"), W(d.arrowRight, "inactive"), _ = d.view = void 0, v.forEach(function(y) {
					var p = y.node;
					p && (y.hidden ? p.attr("aria-hidden", y.hidden) : p.removeAttr("aria-hidden"), y.tabIndex ? p.attr("tabIndex", y.tabIndex) : p.removeAttr("tabIndex"))
				}), v = [], n(".active-lightbox").removeClass("active-lightbox").focus())
			}

			function ee(y, p) {
				var c = fe("img", "img");
				return c.one("load", function() {
					p(c)
				}), c.attr("src", y), c
			}

			function ne(y) {
				return function() {
					y.remove()
				}
			}

			function V(y) {
				var p = y.get(0),
					c = d.strip.get(0),
					A = p.offsetLeft,
					O = p.clientWidth,
					R = c.scrollLeft,
					U = c.clientWidth,
					J = c.scrollWidth - U,
					H;
				A < R ? H = Math.max(0, A + O - U) : A + O > U + R && (H = Math.min(A, J)), H != null && i(d.strip).add("scroll-left 500ms").start({
					"scroll-left": H
				})
			}

			function S(y, p, c) {
				this.$element = y, this.className = p, this.delay = c || 200, this.hide()
			}
			S.prototype.show = function() {
				var y = this;
				y.timeoutId || (y.timeoutId = setTimeout(function() {
					y.$element.removeClass(y.className), delete y.timeoutId
				}, y.delay))
			}, S.prototype.hide = function() {
				var y = this;
				if (y.timeoutId) {
					clearTimeout(y.timeoutId), delete y.timeoutId;
					return
				}
				y.$element.addClass(y.className)
			};

			function q(y, p) {
				return y.replace(u, (p ? " ." : " ") + a)
			}

			function z(y) {
				return q(y, !0)
			}

			function W(y, p) {
				return y.addClass(q(p))
			}

			function te(y, p) {
				return y.removeClass(q(p))
			}

			function re(y, p, c) {
				return y.toggleClass(q(p), c)
			}

			function ce(y, p) {
				return y.attr("aria-hidden", p).attr("tabIndex", p ? -1 : 0)
			}

			function fe(y, p) {
				return W(n(t.createElement(p || "div")), y)
			}

			function I(y, p) {
				var c = '<svg xmlns="http://www.w3.org/2000/svg" width="' + y + '" height="' + p + '"/>';
				return "data:image/svg+xml;charset=utf-8," + encodeURI(c)
			}
			return function() {
				var y = e.navigator.userAgent,
					p = /(iPhone|iPad|iPod);[^OS]*OS (\d)/,
					c = y.match(p),
					A = y.indexOf("Android ") > -1 && y.indexOf("Chrome") === -1;
				if (!A && (!c || c[2] > 7)) return;
				var O = t.createElement("style");
				t.head.appendChild(O), e.addEventListener("resize", R, !0);

				function R() {
					var U = e.innerHeight,
						J = e.innerWidth,
						H = ".w-lightbox-content, .w-lightbox-view, .w-lightbox-view:before {height:" + U + "px}.w-lightbox-view {width:" + J + "px}.w-lightbox-group, .w-lightbox-group .w-lightbox-view, .w-lightbox-group .w-lightbox-view:before {height:" + .86 * U + "px}.w-lightbox-image {max-width:" + J + "px;max-height:" + U + "px}.w-lightbox-group .w-lightbox-image {max-height:" + .86 * U + "px}.w-lightbox-strip {padding: 0 " + .01 * U + "px}.w-lightbox-item {width:" + .1 * U + "px;padding:" + .02 * U + "px " + .01 * U + "px}.w-lightbox-thumbnail {height:" + .1 * U + "px}@media (min-width: 768px) {.w-lightbox-content, .w-lightbox-view, .w-lightbox-view:before {height:" + .96 * U + "px}.w-lightbox-content {margin-top:" + .02 * U + "px}.w-lightbox-group, .w-lightbox-group .w-lightbox-view, .w-lightbox-group .w-lightbox-view:before {height:" + .84 * U + "px}.w-lightbox-image {max-width:" + .96 * J + "px;max-height:" + .96 * U + "px}.w-lightbox-group .w-lightbox-image {max-width:" + .823 * J + "px;max-height:" + .84 * U + "px}}";
					O.textContent = H
				}
				R()
			}(), E
		}
		va.define("lightbox", Yv.exports = function(e) {
			var t = {},
				n = va.env(),
				r = zF(window, document, e, n ? "#lightbox-mountpoint" : "body"),
				i = e(document),
				o, s, a = ".w-lightbox",
				u;
			t.ready = t.design = t.preview = l;

			function l() {
				s = n && va.env("design"), r.destroy(), u = {}, o = i.find(a), o.webflowLightBox(), o.each(function() {
					Dn(e(this), "open lightbox"), e(this).attr("aria-haspopup", "dialog")
				})
			}
			jQuery.fn.extend({
				webflowLightBox: function() {
					var v = this;
					e.each(v, function(E, b) {
						var x = e.data(b, a);
						x || (x = e.data(b, a, {
							el: e(b),
							mode: "images",
							images: [],
							embed: ""
						})), x.el.off(a), _(x), s ? x.el.on("setting" + a, _.bind(null, x)) : x.el.on("click" + a, d(x)).on("click" + a, function(T) {
							T.preventDefault()
						})
					})
				}
			});

			function _(v) {
				var E = v.el.children(".w-json").html(),
					b, x;
				if (!E) {
					v.items = [];
					return
				}
				try {
					E = JSON.parse(E)
				} catch (T) {
					console.error("Malformed lightbox JSON configuration.", T)
				}
				m(E), E.items.forEach(function(T) {
					T.$el = v.el
				}), b = E.group, b ? (x = u[b], x || (x = u[b] = []), v.items = x, E.items.length && (v.index = x.length, x.push.apply(x, E.items))) : (v.items = E.items, v.index = 0)
			}

			function d(v) {
				return function() {
					v.items.length && r(v.items, v.index || 0)
				}
			}

			function m(v) {
				v.images && (v.images.forEach(function(E) {
					E.type = "image"
				}), v.items = v.images), v.embed && (v.embed.type = "video", v.items = [v.embed]), v.groupId && (v.group = v.groupId)
			}
			return t
		})
	});
	var Zv = g((iV, $v) => {
		"use strict";
		var mt = Le(),
			jF = on(),
			Oe = {
				ARROW_LEFT: 37,
				ARROW_UP: 38,
				ARROW_RIGHT: 39,
				ARROW_DOWN: 40,
				ESCAPE: 27,
				SPACE: 32,
				ENTER: 13,
				HOME: 36,
				END: 35
			};
		mt.define("navbar", $v.exports = function(e, t) {
			var n = {},
				r = e.tram,
				i = e(window),
				o = e(document),
				s = t.debounce,
				a, u, l, _, d = mt.env(),
				m = '<div class="w-nav-overlay" data-wf-ignore />',
				v = ".w-nav",
				E = "w--open",
				b = "w--nav-dropdown-open",
				x = "w--nav-dropdown-toggle-open",
				T = "w--nav-dropdown-list-open",
				L = "w--nav-link-open",
				P = jF.triggers,
				D = e();
			n.ready = n.design = n.preview = F, n.destroy = function() {
				D = e(), M(), u && u.length && u.each(ee)
			};

			function F() {
				l = d && mt.env("design"), _ = mt.env("editor"), a = e(document.body), u = o.find(v), u.length && (u.each(Q), M(), Y())
			}

			function M() {
				mt.resize.off(K)
			}

			function Y() {
				mt.resize.on(K)
			}

			function K() {
				u.each(p)
			}

			function Q(h, X) {
				var Z = e(X),
					j = e.data(X, v);
				j || (j = e.data(X, v, {
					open: !1,
					el: Z,
					config: {},
					selectedIdx: -1
				})), j.menu = Z.find(".w-nav-menu"), j.links = j.menu.find(".w-nav-link"), j.dropdowns = j.menu.find(".w-dropdown"), j.dropdownToggle = j.menu.find(".w-dropdown-toggle"), j.dropdownList = j.menu.find(".w-dropdown-list"), j.button = Z.find(".w-nav-button"), j.container = Z.find(".w-container"), j.overlayContainerId = "w-nav-overlay-" + h, j.outside = I(j);
				var de = Z.find(".w-nav-brand");
				de && de.attr("href") === "/" && de.attr("aria-label") == null && de.attr("aria-label", "home"), j.button.attr("style", "-webkit-user-select: text;"), j.button.attr("aria-label") == null && j.button.attr("aria-label", "menu"), j.button.attr("role", "button"), j.button.attr("tabindex", "0"), j.button.attr("aria-controls", j.overlayContainerId), j.button.attr("aria-haspopup", "menu"), j.button.attr("aria-expanded", "false"), j.el.off(v), j.button.off(v), j.menu.off(v), S(j), l ? (ne(j), j.el.on("setting" + v, q(j))) : (V(j), j.button.on("click" + v, ce(j)), j.menu.on("click" + v, "a", fe(j)), j.button.on("keydown" + v, z(j)), j.el.on("keydown" + v, W(j))), p(h, X)
			}

			function ee(h, X) {
				var Z = e.data(X, v);
				Z && (ne(Z), e.removeData(X, v))
			}

			function ne(h) {
				h.overlay && (H(h, !0), h.overlay.remove(), h.overlay = null)
			}

			function V(h) {
				h.overlay || (h.overlay = e(m).appendTo(h.el), h.overlay.attr("id", h.overlayContainerId), h.parent = h.menu.parent(), H(h, !0))
			}

			function S(h) {
				var X = {},
					Z = h.config || {},
					j = X.animation = h.el.attr("data-animation") || "default";
				X.animOver = /^over/.test(j), X.animDirect = /left$/.test(j) ? -1 : 1, Z.animation !== j && h.open && t.defer(re, h), X.easing = h.el.attr("data-easing") || "ease", X.easing2 = h.el.attr("data-easing2") || "ease";
				var de = h.el.attr("data-duration");
				X.duration = de != null ? Number(de) : 400, X.docHeight = h.el.attr("data-doc-height"), h.config = X
			}

			function q(h) {
				return function(X, Z) {
					Z = Z || {};
					var j = i.width();
					S(h), Z.open === !0 && U(h, !0), Z.open === !1 && H(h, !0), h.open && t.defer(function() {
						j !== i.width() && re(h)
					})
				}
			}

			function z(h) {
				return function(X) {
					switch (X.keyCode) {
						case Oe.SPACE:
						case Oe.ENTER:
							return ce(h)(), X.preventDefault(), X.stopPropagation();
						case Oe.ESCAPE:
							return H(h), X.preventDefault(), X.stopPropagation();
						case Oe.ARROW_RIGHT:
						case Oe.ARROW_DOWN:
						case Oe.HOME:
						case Oe.END:
							return h.open ? (X.keyCode === Oe.END ? h.selectedIdx = h.links.length - 1 : h.selectedIdx = 0, te(h), X.preventDefault(), X.stopPropagation()) : (X.preventDefault(), X.stopPropagation())
					}
				}
			}

			function W(h) {
				return function(X) {
					if (h.open) switch (h.selectedIdx = h.links.index(document.activeElement), X.keyCode) {
						case Oe.HOME:
						case Oe.END:
							return X.keyCode === Oe.END ? h.selectedIdx = h.links.length - 1 : h.selectedIdx = 0, te(h), X.preventDefault(), X.stopPropagation();
						case Oe.ESCAPE:
							return H(h), h.button.focus(), X.preventDefault(), X.stopPropagation();
						case Oe.ARROW_LEFT:
						case Oe.ARROW_UP:
							return h.selectedIdx = Math.max(-1, h.selectedIdx - 1), te(h), X.preventDefault(), X.stopPropagation();
						case Oe.ARROW_RIGHT:
						case Oe.ARROW_DOWN:
							return h.selectedIdx = Math.min(h.links.length - 1, h.selectedIdx + 1), te(h), X.preventDefault(), X.stopPropagation()
					}
				}
			}

			function te(h) {
				if (h.links[h.selectedIdx]) {
					var X = h.links[h.selectedIdx];
					X.focus(), fe(X)
				}
			}

			function re(h) {
				h.open && (H(h, !0), U(h, !0))
			}

			function ce(h) {
				return s(function() {
					h.open ? H(h) : U(h)
				})
			}

			function fe(h) {
				return function(X) {
					var Z = e(this),
						j = Z.attr("href");
					if (!mt.validClick(X.currentTarget)) {
						X.preventDefault();
						return
					}
					j && j.indexOf("#") === 0 && h.open && H(h)
				}
			}

			function I(h) {
				return h.outside && o.off("click" + v, h.outside),
					function(X) {
						var Z = e(X.target);
						_ && Z.closest(".w-editor-bem-EditorOverlay").length || y(h, Z)
					}
			}
			var y = s(function(h, X) {
				if (h.open) {
					var Z = X.closest(".w-nav-menu");
					h.menu.is(Z) || H(h)
				}
			});

			function p(h, X) {
				var Z = e.data(X, v),
					j = Z.collapsed = Z.button.css("display") !== "none";
				if (Z.open && !j && !l && H(Z, !0), Z.container.length) {
					var de = A(Z);
					Z.links.each(de), Z.dropdowns.each(de)
				}
				Z.open && J(Z)
			}
			var c = "max-width";

			function A(h) {
				var X = h.container.css(c);
				return X === "none" && (X = ""),
					function(Z, j) {
						j = e(j), j.css(c, ""), j.css(c) === "none" && j.css(c, X)
					}
			}

			function O(h, X) {
				X.setAttribute("data-nav-menu-open", "")
			}

			function R(h, X) {
				X.removeAttribute("data-nav-menu-open")
			}

			function U(h, X) {
				if (h.open) return;
				h.open = !0, h.menu.each(O), h.links.addClass(L), h.dropdowns.addClass(b), h.dropdownToggle.addClass(x), h.dropdownList.addClass(T), h.button.addClass(E);
				var Z = h.config,
					j = Z.animation;
				(j === "none" || !r.support.transform || Z.duration <= 0) && (X = !0);
				var de = J(h),
					be = h.menu.outerHeight(!0),
					xe = h.menu.outerWidth(!0),
					f = h.el.height(),
					w = h.el[0];
				if (p(0, w), P.intro(0, w), mt.redraw.up(), l || o.on("click" + v, h.outside), X) {
					k();
					return
				}
				var C = "transform " + Z.duration + "ms " + Z.easing;
				if (h.overlay && (D = h.menu.prev(), h.overlay.show().append(h.menu)), Z.animOver) {
					r(h.menu).add(C).set({
						x: Z.animDirect * xe,
						height: de
					}).start({
						x: 0
					}).then(k), h.overlay && h.overlay.width(xe);
					return
				}
				var N = f + be;
				r(h.menu).add(C).set({
					y: -N
				}).start({
					y: 0
				}).then(k);

				function k() {
					h.button.attr("aria-expanded", "true")
				}
			}

			function J(h) {
				var X = h.config,
					Z = X.docHeight ? o.height() : a.height();
				return X.animOver ? h.menu.height(Z) : h.el.css("position") !== "fixed" && (Z -= h.el.outerHeight(!0)), h.overlay && h.overlay.height(Z), Z
			}

			function H(h, X) {
				if (!h.open) return;
				h.open = !1, h.button.removeClass(E);
				var Z = h.config;
				if ((Z.animation === "none" || !r.support.transform || Z.duration <= 0) && (X = !0), P.outro(0, h.el[0]), o.off("click" + v, h.outside), X) {
					r(h.menu).stop(), w();
					return
				}
				var j = "transform " + Z.duration + "ms " + Z.easing2,
					de = h.menu.outerHeight(!0),
					be = h.menu.outerWidth(!0),
					xe = h.el.height();
				if (Z.animOver) {
					r(h.menu).add(j).start({
						x: be * Z.animDirect
					}).then(w);
					return
				}
				var f = xe + de;
				r(h.menu).add(j).start({
					y: -f
				}).then(w);

				function w() {
					h.menu.height(""), r(h.menu).set({
						x: 0,
						y: 0
					}), h.menu.each(R), h.links.removeClass(L), h.dropdowns.removeClass(b), h.dropdownToggle.removeClass(x), h.dropdownList.removeClass(T), h.overlay && h.overlay.children().length && (D.length ? h.menu.insertAfter(D) : h.menu.prependTo(h.parent), h.overlay.attr("style", "").hide()), h.el.triggerHandler("w-close"), h.button.attr("aria-expanded", "false")
				}
			}
			return n
		})
	});
	var tm = g((oV, em) => {
		"use strict";
		var yt = Le(),
			KF = on(),
			ot = {
				ARROW_LEFT: 37,
				ARROW_UP: 38,
				ARROW_RIGHT: 39,
				ARROW_DOWN: 40,
				SPACE: 32,
				ENTER: 13,
				HOME: 36,
				END: 35
			},
			Jv = 'a[href], area[href], [role="button"], input, select, textarea, button, iframe, object, embed, *[tabindex], *[contenteditable]';
		yt.define("slider", em.exports = function(e, t) {
			var n = {},
				r = e.tram,
				i = e(document),
				o, s, a = yt.env(),
				u = ".w-slider",
				l = '<div class="w-slider-dot" data-wf-ignore />',
				_ = '<div aria-live="off" aria-atomic="true" class="w-slider-aria-label" data-wf-ignore />',
				d = "w-slider-force-show",
				m = KF.triggers,
				v, E = !1;
			n.ready = function() {
				s = yt.env("design"), b()
			}, n.design = function() {
				s = !0, setTimeout(b, 1e3)
			}, n.preview = function() {
				s = !1, b()
			}, n.redraw = function() {
				E = !0, b(), E = !1
			}, n.destroy = x;

			function b() {
				o = i.find(u), o.length && (o.each(P), !v && (x(), T()))
			}

			function x() {
				yt.resize.off(L), yt.redraw.off(n.redraw)
			}

			function T() {
				yt.resize.on(L), yt.redraw.on(n.redraw)
			}

			function L() {
				o.filter(":visible").each(W)
			}

			function P(I, y) {
				var p = e(y),
					c = e.data(y, u);
				c || (c = e.data(y, u, {
					index: 0,
					depth: 1,
					hasFocus: {
						keyboard: !1,
						mouse: !1
					},
					el: p,
					config: {}
				})), c.mask = p.children(".w-slider-mask"), c.left = p.children(".w-slider-arrow-left"), c.right = p.children(".w-slider-arrow-right"), c.nav = p.children(".w-slider-nav"), c.slides = c.mask.children(".w-slide"), c.slides.each(m.reset), E && (c.maskWidth = 0), p.attr("role") === void 0 && p.attr("role", "region"), p.attr("aria-label") === void 0 && p.attr("aria-label", "carousel");
				var A = c.mask.attr("id");
				if (A || (A = "w-slider-mask-" + I, c.mask.attr("id", A)), !s && !c.ariaLiveLabel && (c.ariaLiveLabel = e(_).appendTo(c.mask)), c.left.attr("role", "button"), c.left.attr("tabindex", "0"), c.left.attr("aria-controls", A), c.left.attr("aria-label") === void 0 && c.left.attr("aria-label", "previous slide"), c.right.attr("role", "button"), c.right.attr("tabindex", "0"), c.right.attr("aria-controls", A), c.right.attr("aria-label") === void 0 && c.right.attr("aria-label", "next slide"), !r.support.transform) {
					c.left.hide(), c.right.hide(), c.nav.hide(), v = !0;
					return
				}
				c.el.off(u), c.left.off(u), c.right.off(u), c.nav.off(u), D(c), s ? (c.el.on("setting" + u, S(c)), V(c), c.hasTimer = !1) : (c.el.on("swipe" + u, S(c)), c.left.on("click" + u, K(c)), c.right.on("click" + u, Q(c)), c.left.on("keydown" + u, Y(c, K)), c.right.on("keydown" + u, Y(c, Q)), c.nav.on("keydown" + u, "> div", S(c)), c.config.autoplay && !c.hasTimer && (c.hasTimer = !0, c.timerCount = 1, ne(c)), c.el.on("mouseenter" + u, M(c, !0, "mouse")), c.el.on("focusin" + u, M(c, !0, "keyboard")), c.el.on("mouseleave" + u, M(c, !1, "mouse")), c.el.on("focusout" + u, M(c, !1, "keyboard"))), c.nav.on("click" + u, "> div", S(c)), a || c.mask.contents().filter(function() {
					return this.nodeType === 3
				}).remove();
				var O = p.filter(":hidden");
				O.addClass(d);
				var R = p.parents(":hidden");
				R.addClass(d), E || W(I, y), O.removeClass(d), R.removeClass(d)
			}

			function D(I) {
				var y = {};
				y.crossOver = 0, y.animation = I.el.attr("data-animation") || "slide", y.animation === "outin" && (y.animation = "cross", y.crossOver = .5), y.easing = I.el.attr("data-easing") || "ease";
				var p = I.el.attr("data-duration");
				if (y.duration = p != null ? parseInt(p, 10) : 500, F(I.el.attr("data-infinite")) && (y.infinite = !0), F(I.el.attr("data-disable-swipe")) && (y.disableSwipe = !0), F(I.el.attr("data-hide-arrows")) ? y.hideArrows = !0 : I.config.hideArrows && (I.left.show(), I.right.show()), F(I.el.attr("data-autoplay"))) {
					y.autoplay = !0, y.delay = parseInt(I.el.attr("data-delay"), 10) || 2e3, y.timerMax = parseInt(I.el.attr("data-autoplay-limit"), 10);
					var c = "mousedown" + u + " touchstart" + u;
					s || I.el.off(c).one(c, function() {
						V(I)
					})
				}
				var A = I.right.width();
				y.edge = A ? A + 40 : 100, I.config = y
			}

			function F(I) {
				return I === "1" || I === "true"
			}

			function M(I, y, p) {
				return function(c) {
					if (y) I.hasFocus[p] = y;
					else if (e.contains(I.el.get(0), c.relatedTarget) || (I.hasFocus[p] = y, I.hasFocus.mouse && p === "keyboard" || I.hasFocus.keyboard && p === "mouse")) return;
					y ? (I.ariaLiveLabel.attr("aria-live", "polite"), I.hasTimer && V(I)) : (I.ariaLiveLabel.attr("aria-live", "off"), I.hasTimer && ne(I))
				}
			}

			function Y(I, y) {
				return function(p) {
					switch (p.keyCode) {
						case ot.SPACE:
						case ot.ENTER:
							return y(I)(), p.preventDefault(), p.stopPropagation()
					}
				}
			}

			function K(I) {
				return function() {
					z(I, {
						index: I.index - 1,
						vector: -1
					})
				}
			}

			function Q(I) {
				return function() {
					z(I, {
						index: I.index + 1,
						vector: 1
					})
				}
			}

			function ee(I, y) {
				var p = null;
				y === I.slides.length && (b(), te(I)), t.each(I.anchors, function(c, A) {
					e(c.els).each(function(O, R) {
						e(R).index() === y && (p = A)
					})
				}), p != null && z(I, {
					index: p,
					immediate: !0
				})
			}

			function ne(I) {
				V(I);
				var y = I.config,
					p = y.timerMax;
				p && I.timerCount++ > p || (I.timerId = window.setTimeout(function() {
					I.timerId == null || s || (Q(I)(), ne(I))
				}, y.delay))
			}

			function V(I) {
				window.clearTimeout(I.timerId), I.timerId = null
			}

			function S(I) {
				return function(y, p) {
					p = p || {};
					var c = I.config;
					if (s && y.type === "setting") {
						if (p.select === "prev") return K(I)();
						if (p.select === "next") return Q(I)();
						if (D(I), te(I), p.select == null) return;
						ee(I, p.select);
						return
					}
					if (y.type === "swipe") return c.disableSwipe || yt.env("editor") ? void 0 : p.direction === "left" ? Q(I)() : p.direction === "right" ? K(I)() : void 0;
					if (I.nav.has(y.target).length) {
						var A = e(y.target).index();
						if (y.type === "click" && z(I, {
								index: A
							}), y.type === "keydown") switch (y.keyCode) {
							case ot.ENTER:
							case ot.SPACE: {
								z(I, {
									index: A
								}), y.preventDefault();
								break
							}
							case ot.ARROW_LEFT:
							case ot.ARROW_UP: {
								q(I.nav, Math.max(A - 1, 0)), y.preventDefault();
								break
							}
							case ot.ARROW_RIGHT:
							case ot.ARROW_DOWN: {
								q(I.nav, Math.min(A + 1, I.pages)), y.preventDefault();
								break
							}
							case ot.HOME: {
								q(I.nav, 0), y.preventDefault();
								break
							}
							case ot.END: {
								q(I.nav, I.pages), y.preventDefault();
								break
							}
							default:
								return
						}
					}
				}
			}

			function q(I, y) {
				var p = I.children().eq(y).focus();
				I.children().not(p)
			}

			function z(I, y) {
				y = y || {};
				var p = I.config,
					c = I.anchors;
				I.previous = I.index;
				var A = y.index,
					O = {};
				A < 0 ? (A = c.length - 1, p.infinite && (O.x = -I.endX, O.from = 0, O.to = c[0].width)) : A >= c.length && (A = 0, p.infinite && (O.x = c[c.length - 1].width, O.from = -c[c.length - 1].x, O.to = O.from - O.x)), I.index = A;
				var R = I.nav.children().eq(A).addClass("w-active").attr("aria-pressed", "true").attr("tabindex", "0");
				I.nav.children().not(R).removeClass("w-active").attr("aria-pressed", "false").attr("tabindex", "-1"), p.hideArrows && (I.index === c.length - 1 ? I.right.hide() : I.right.show(), I.index === 0 ? I.left.hide() : I.left.show());
				var U = I.offsetX || 0,
					J = I.offsetX = -c[I.index].x,
					H = {
						x: J,
						opacity: 1,
						visibility: ""
					},
					h = e(c[I.index].els),
					X = e(c[I.previous] && c[I.previous].els),
					Z = I.slides.not(h),
					j = p.animation,
					de = p.easing,
					be = Math.round(p.duration),
					xe = y.vector || (I.index > I.previous ? 1 : -1),
					f = "opacity " + be + "ms " + de,
					w = "transform " + be + "ms " + de;
				if (h.find(Jv).removeAttr("tabindex"), h.removeAttr("aria-hidden"), h.find("*").removeAttr("aria-hidden"), Z.find(Jv).attr("tabindex", "-1"), Z.attr("aria-hidden", "true"), Z.find("*").attr("aria-hidden", "true"), s || (h.each(m.intro), Z.each(m.outro)), y.immediate && !E) {
					r(h).set(H), k();
					return
				}
				if (I.index === I.previous) return;
				if (s || I.ariaLiveLabel.text(`Slide ${A+1} of ${c.length}.`), j === "cross") {
					var C = Math.round(be - be * p.crossOver),
						N = Math.round(be - C);
					f = "opacity " + C + "ms " + de, r(X).set({
						visibility: ""
					}).add(f).start({
						opacity: 0
					}), r(h).set({
						visibility: "",
						x: J,
						opacity: 0,
						zIndex: I.depth++
					}).add(f).wait(N).then({
						opacity: 1
					}).then(k);
					return
				}
				if (j === "fade") {
					r(X).set({
						visibility: ""
					}).stop(), r(h).set({
						visibility: "",
						x: J,
						opacity: 0,
						zIndex: I.depth++
					}).add(f).start({
						opacity: 1
					}).then(k);
					return
				}
				if (j === "over") {
					H = {
						x: I.endX
					}, r(X).set({
						visibility: ""
					}).stop(), r(h).set({
						visibility: "",
						zIndex: I.depth++,
						x: J + c[I.index].width * xe
					}).add(w).start({
						x: J
					}).then(k);
					return
				}
				p.infinite && O.x ? (r(I.slides.not(X)).set({
					visibility: "",
					x: O.x
				}).add(w).start({
					x: J
				}), r(X).set({
					visibility: "",
					x: O.from
				}).add(w).start({
					x: O.to
				}), I.shifted = X) : (p.infinite && I.shifted && (r(I.shifted).set({
					visibility: "",
					x: U
				}), I.shifted = null), r(I.slides).set({
					visibility: ""
				}).add(w).start({
					x: J
				}));

				function k() {
					h = e(c[I.index].els), Z = I.slides.not(h), j !== "slide" && (H.visibility = "hidden"), r(Z).set(H)
				}
			}

			function W(I, y) {
				var p = e.data(y, u);
				if (p) {
					if (ce(p)) return te(p);
					s && fe(p) && te(p)
				}
			}

			function te(I) {
				var y = 1,
					p = 0,
					c = 0,
					A = 0,
					O = I.maskWidth,
					R = O - I.config.edge;
				R < 0 && (R = 0), I.anchors = [{
					els: [],
					x: 0,
					width: 0
				}], I.slides.each(function(J, H) {
					c - p > R && (y++, p += O, I.anchors[y - 1] = {
						els: [],
						x: c,
						width: 0
					}), A = e(H).outerWidth(!0), c += A, I.anchors[y - 1].width += A, I.anchors[y - 1].els.push(H);
					var h = J + 1 + " of " + I.slides.length;
					e(H).attr("aria-label", h), e(H).attr("role", "group")
				}), I.endX = c, s && (I.pages = null), I.nav.length && I.pages !== y && (I.pages = y, re(I));
				var U = I.index;
				U >= y && (U = y - 1), z(I, {
					immediate: !0,
					index: U
				})
			}

			function re(I) {
				var y = [],
					p, c = I.el.attr("data-nav-spacing");
				c && (c = parseFloat(c) + "px");
				for (var A = 0, O = I.pages; A < O; A++) p = e(l), p.attr("aria-label", "Show slide " + (A + 1) + " of " + O).attr("aria-pressed", "false").attr("role", "button").attr("tabindex", "-1"), I.nav.hasClass("w-num") && p.text(A + 1), c != null && p.css({
					"margin-left": c,
					"margin-right": c
				}), y.push(p);
				I.nav.empty().append(y)
			}

			function ce(I) {
				var y = I.mask.width();
				return I.maskWidth !== y ? (I.maskWidth = y, !0) : !1
			}

			function fe(I) {
				var y = 0;
				return I.slides.each(function(p, c) {
					y += e(c).outerWidth(!0)
				}), I.slidesWidth !== y ? (I.slidesWidth = y, !0) : !1
			}
			return n
		})
	});
	_a();
	Ia();
	Da();
	Fa();
	ka();
	Xa();
	on();
	Mv();
	qv();
	Gv();
	Xv();
	Hv();
	jv();
	Qv();
	Zv();
	tm();
})();
/*!
 * tram.js v0.8.2-global
 * Cross-browser CSS3 transitions in JavaScript
 * https://github.com/bkwld/tram
 * MIT License
 */
/*!
 * Webflow._ (aka) Underscore.js 1.6.0 (custom build)
 *
 * http://underscorejs.org
 * (c) 2009-2013 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 * Underscore may be freely distributed under the MIT license.
 * @license MIT
 */
/*! Bundled license information:

timm/lib/timm.js:
  (*!
   * Timm
   *
   * Immutability helpers with fast reads and acceptable writes.
   *
   * @copyright Guillermo Grau Panea 2016
   * @license MIT
   *)
*/
/**
 * ----------------------------------------------------------------------
 * Webflow: Interactions 2.0: Init
 */
Webflow.require('ix2').init({
	"events": {
		"e": {
			"id": "e",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-193"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf535|5e0a6046-03e4-6a3f-0807-b13cba8f3cb1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf535|5e0a6046-03e4-6a3f-0807-b13cba8f3cb1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1534233016320
		},
		"e-3": {
			"id": "e-3",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-2",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-419"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf535|63dc4587-fce3-06c3-29ce-e9076e8b9b1f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf535|63dc4587-fce3-06c3-29ce-e9076e8b9b1f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1534233374692
		},
		"e-14": {
			"id": "e-14",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "FADE_EFFECT",
				"instant": false,
				"config": {
					"actionListId": "fadeIn",
					"autoStopEventId": "e-15"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".gallery__image",
				"originalId": "656ef8b027ad4189724cf533|bec01694-10cb-99e6-1449-9179b9e8aa52",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".gallery__image",
				"originalId": "656ef8b027ad4189724cf533|bec01694-10cb-99e6-1449-9179b9e8aa52",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": 0,
				"direction": null,
				"effectIn": true
			},
			"createdOn": 1584891709795
		},
		"e-24": {
			"id": "e-24",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-7",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-7-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1585586648125
		},
		"e-33": {
			"id": "e-33",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-12",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|5081d615-0f25-5fe1-7685-9edf5f769155",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|5081d615-0f25-5fe1-7685-9edf5f769155",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-12-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1585822842440
		},
		"e-34": {
			"id": "e-34",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-11",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-35"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|ffc31d0d-3010-375f-d278-2d1ac2745b08",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|ffc31d0d-3010-375f-d278-2d1ac2745b08",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": 200,
				"direction": null,
				"effectIn": true
			},
			"createdOn": 1585825973138
		},
		"e-36": {
			"id": "e-36",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-11",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-37"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|6c909163-2851-fd70-f9a7-f3f32ce72870",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|6c909163-2851-fd70-f9a7-f3f32ce72870",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": 200,
				"direction": null,
				"effectIn": true
			},
			"createdOn": 1585826753336
		},
		"e-38": {
			"id": "e-38",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SLIDER_ACTIVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-23",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-39"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".testimonials__slide",
				"originalId": "656ef8b027ad4189724cf4e3|25c10dcb-638f-d2e7-98f5-dfa3cd907bc1",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".testimonials__slide",
				"originalId": "656ef8b027ad4189724cf4e3|25c10dcb-638f-d2e7-98f5-dfa3cd907bc1",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1586333358259
		},
		"e-39": {
			"id": "e-39",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SLIDER_INACTIVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-24",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-38"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".testimonials__slide",
				"originalId": "656ef8b027ad4189724cf4e3|25c10dcb-638f-d2e7-98f5-dfa3cd907bc1",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".testimonials__slide",
				"originalId": "656ef8b027ad4189724cf4e3|25c10dcb-638f-d2e7-98f5-dfa3cd907bc1",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1586333358259
		},
		"e-48": {
			"id": "e-48",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-21",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-49"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "a82c728d-9014-4684-e672-dd057b1616f8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "a82c728d-9014-4684-e672-dd057b1616f8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1586364960671
		},
		"e-57": {
			"id": "e-57",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-7",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ee",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ee",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-7-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1586442887940
		},
		"e-58": {
			"id": "e-58",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-59"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1586442927542
		},
		"e-62": {
			"id": "e-62",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-25",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-25-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1586959706580
		},
		"e-63": {
			"id": "e-63",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-25",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|5e69299645cee839e68510cd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|5e69299645cee839e68510cd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-25-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1586959851564
		},
		"e-119": {
			"id": "e-119",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-42",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-42-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1591627844079
		},
		"e-134": {
			"id": "e-134",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-135"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1580325657627
		},
		"e-136": {
			"id": "e-136",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "DROPDOWN_OPEN",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-46",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-137"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1580325657627
		},
		"e-137": {
			"id": "e-137",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "DROPDOWN_CLOSE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-47",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-136"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "c81deec2-094f-9f0a-64ca-e871b2bdb10c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1580325657627
		},
		"e-138": {
			"id": "e-138",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-139"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1591968113329
		},
		"e-140": {
			"id": "e-140",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "DROPDOWN_OPEN",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-46",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-141"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eeb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eeb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1591968113329
		},
		"e-141": {
			"id": "e-141",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "DROPDOWN_CLOSE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-47",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-140"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eeb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|455c09f9-ad64-143f-effa-ae7922403eeb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1591968113329
		},
		"e-157": {
			"id": "e-157",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-54",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-54-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1599836053503
		},
		"e-158": {
			"id": "e-158",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-143",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-159"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1599837223342
		},
		"e-166": {
			"id": "e-166",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-67",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-67-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1604329940485
		},
		"e-177": {
			"id": "e-177",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-62",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-178"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "18eddfef-60ca-c29b-d5bc-0cac8d1782e3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "18eddfef-60ca-c29b-d5bc-0cac8d1782e3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1604947727209
		},
		"e-182": {
			"id": "e-182",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-62",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-183"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "cd95b464-0e15-52ff-a248-fc9339f9d162",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "cd95b464-0e15-52ff-a248-fc9339f9d162",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1605105465238
		},
		"e-184": {
			"id": "e-184",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-62",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-185"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "cd95b464-0e15-52ff-a248-fc9339f9d15d",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "cd95b464-0e15-52ff-a248-fc9339f9d15d",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1605105475636
		},
		"e-188": {
			"id": "e-188",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-62",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-189"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "a4f4b466-2e79-575c-3118-ea2b7431d657",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "a4f4b466-2e79-575c-3118-ea2b7431d657",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1605175872475
		},
		"e-198": {
			"id": "e-198",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-199"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643283770350
		},
		"e-200": {
			"id": "e-200",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "DROPDOWN_OPEN",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-46",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-201"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643283770350
		},
		"e-201": {
			"id": "e-201",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "DROPDOWN_CLOSE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-47",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-200"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|48f1ec34-fc2a-d1ce-6252-3716de61ebc7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643283770350
		},
		"e-202": {
			"id": "e-202",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-73",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-203"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".control",
				"originalId": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".control",
				"originalId": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1617476135370
		},
		"e-203": {
			"id": "e-203",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-74",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-202"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".control",
				"originalId": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".control",
				"originalId": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1617476135371
		},
		"e-207": {
			"id": "e-207",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-54",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-54-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1643640167955
		},
		"e-209": {
			"id": "e-209",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-55",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-210"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643640167955
		},
		"e-210": {
			"id": "e-210",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-79",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-209"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643640167955
		},
		"e-213": {
			"id": "e-213",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-135",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-214"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643640167955
		},
		"e-214": {
			"id": "e-214",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_FINISH",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-136",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-213"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643640167955
		},
		"e-217": {
			"id": "e-217",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-218"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"selector": ".collections-link",
				"originalId": "041ae113-a1ab-7d75-9348-1f3ecf4b6f5d",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"id": "041ae113-a1ab-7d75-9348-1f3ecf4b6f5d",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643646082891
		},
		"e-222": {
			"id": "e-222",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-55",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-223"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|93dbaf2b-656a-7438-15f6-336502a4e842",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|93dbaf2b-656a-7438-15f6-336502a4e842",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643734044214
		},
		"e-223": {
			"id": "e-223",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-79",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-222"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|93dbaf2b-656a-7438-15f6-336502a4e842",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|93dbaf2b-656a-7438-15f6-336502a4e842",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1643734044214
		},
		"e-237": {
			"id": "e-237",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-82",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|f0249b79-bd11-0b7d-7c24-040870c19b4e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|f0249b79-bd11-0b7d-7c24-040870c19b4e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-82-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1644491415296
		},
		"e-238": {
			"id": "e-238",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-83",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|6e1afc34-8f91-9b6e-13ea-91ec57c61786",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|6e1afc34-8f91-9b6e-13ea-91ec57c61786",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-83-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1644493078082
		},
		"e-239": {
			"id": "e-239",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-84",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|3dbc88d9-4041-7689-dcd7-d6eb97db8d43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|3dbc88d9-4041-7689-dcd7-d6eb97db8d43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-84-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1644493655639
		},
		"e-240": {
			"id": "e-240",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-85",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-85-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-85-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}],
			"createdOn": 1644507953392
		},
		"e-242": {
			"id": "e-242",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-85",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-85-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-85-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}],
			"createdOn": 1645797731999
		},
		"e-243": {
			"id": "e-243",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-85",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-85-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-85-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}],
			"createdOn": 1645799822178
		},
		"e-244": {
			"id": "e-244",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-85",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-85-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-85-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}],
			"createdOn": 1645799863928
		},
		"e-253": {
			"id": "e-253",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-88",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-88-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1645809585684
		},
		"e-254": {
			"id": "e-254",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-89",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-255"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1|383c5ac8-a017-a0a8-91a3-cbec7fbb1f09",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1|383c5ac8-a017-a0a8-91a3-cbec7fbb1f09",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1645809962514
		},
		"e-255": {
			"id": "e-255",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-90",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-254"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1|383c5ac8-a017-a0a8-91a3-cbec7fbb1f09",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1|383c5ac8-a017-a0a8-91a3-cbec7fbb1f09",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1645809962514
		},
		"e-256": {
			"id": "e-256",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-89",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-257"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1645809977171
		},
		"e-257": {
			"id": "e-257",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-90",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-256"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de43",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1645809977171
		},
		"e-258": {
			"id": "e-258",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-88",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-88-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1645810012110
		},
		"e-259": {
			"id": "e-259",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-91",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-91-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 90,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-91-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 90,
				"restingState": 50
			}],
			"createdOn": 1646311335249
		},
		"e-264": {
			"id": "e-264",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-85",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-85-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-85-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 80,
				"restingState": 50
			}],
			"createdOn": 1646322346967
		},
		"e-265": {
			"id": "e-265",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-92",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-266"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646390975814
		},
		"e-266": {
			"id": "e-266",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-96",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-265"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646390975816
		},
		"e-267": {
			"id": "e-267",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-268"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "c4c74e15-1068-7077-a568-cfb57c41cd9b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "c4c74e15-1068-7077-a568-cfb57c41cd9b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646398942595
		},
		"e-269": {
			"id": "e-269",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-270"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646399246628
		},
		"e-270": {
			"id": "e-270",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-98",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-269"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646399246628
		},
		"e-271": {
			"id": "e-271",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-272"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|cca87002-ec21-0d93-71d1-2df9a944b5ea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|cca87002-ec21-0d93-71d1-2df9a944b5ea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401076863
		},
		"e-272": {
			"id": "e-272",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-98",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-271"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|cca87002-ec21-0d93-71d1-2df9a944b5ea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|cca87002-ec21-0d93-71d1-2df9a944b5ea",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401076863
		},
		"e-273": {
			"id": "e-273",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-274"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|b6673fd2-097e-92d6-10dc-f202e58f62fd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|b6673fd2-097e-92d6-10dc-f202e58f62fd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401077403
		},
		"e-274": {
			"id": "e-274",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-98",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-273"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|b6673fd2-097e-92d6-10dc-f202e58f62fd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|b6673fd2-097e-92d6-10dc-f202e58f62fd",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401077403
		},
		"e-275": {
			"id": "e-275",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-276"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|6fa65ab9-d0ce-ed8c-272a-f3aa69788807",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|6fa65ab9-d0ce-ed8c-272a-f3aa69788807",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401077792
		},
		"e-276": {
			"id": "e-276",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-98",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-275"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|6fa65ab9-d0ce-ed8c-272a-f3aa69788807",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|6fa65ab9-d0ce-ed8c-272a-f3aa69788807",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401077792
		},
		"e-277": {
			"id": "e-277",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-97",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-278"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|f5a3da6e-37ce-3e53-be45-f7f8d859d6c9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|f5a3da6e-37ce-3e53-be45-f7f8d859d6c9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401078136
		},
		"e-278": {
			"id": "e-278",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-98",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-277"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|f5a3da6e-37ce-3e53-be45-f7f8d859d6c9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|f5a3da6e-37ce-3e53-be45-f7f8d859d6c9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401078136
		},
		"e-281": {
			"id": "e-281",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-99",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-282"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".faq__question",
				"originalId": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".faq__question",
				"originalId": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401310785
		},
		"e-282": {
			"id": "e-282",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-100",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-281"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".faq__question",
				"originalId": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".faq__question",
				"originalId": "656ef8b027ad4189724cf4de|77bada86-e977-99a3-a19e-52b04ae13cf4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1646401310787
		},
		"e-283": {
			"id": "e-283",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-101",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-284"
				}
			},
			"mediaQueries": ["medium", "small", "tiny"],
			"target": {
				"selector": ".nav__link",
				"originalId": "22d603c1-d2b5-51e3-3f78-2d24261fd7c4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".nav__link",
				"originalId": "22d603c1-d2b5-51e3-3f78-2d24261fd7c4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1632749951434
		},
		"e-288": {
			"id": "e-288",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-105",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-289"
				}
			},
			"mediaQueries": ["medium", "small", "tiny"],
			"target": {
				"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1622215755933
		},
		"e-289": {
			"id": "e-289",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-107",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-288"
				}
			},
			"mediaQueries": ["medium", "small", "tiny"],
			"target": {
				"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1622215755934
		},
		"e-290": {
			"id": "e-290",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-108",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-291"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".close-link",
				"originalId": "656ef8b027ad4189724cf4ea|424af766-ab3b-9821-983b-91a2a4f70fcf",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".close-link",
				"originalId": "656ef8b027ad4189724cf4ea|424af766-ab3b-9821-983b-91a2a4f70fcf",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1642506510796
		},
		"e-292": {
			"id": "e-292",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-110",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-293"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|524ab80a-fe10-2e11-1a3f-245a0067b979",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|524ab80a-fe10-2e11-1a3f-245a0067b979",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647428788858
		},
		"e-293": {
			"id": "e-293",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-111",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-292"
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|524ab80a-fe10-2e11-1a3f-245a0067b979",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|524ab80a-fe10-2e11-1a3f-245a0067b979",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647428788864
		},
		"e-299": {
			"id": "e-299",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-116",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-300"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".button",
				"originalId": "61f29c0959b6d0c1ae94631f|8bd18f06-e04f-3434-a859-ce36219f63bd",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".button",
				"originalId": "61f29c0959b6d0c1ae94631f|8bd18f06-e04f-3434-a859-ce36219f63bd",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635619216748
		},
		"e-300": {
			"id": "e-300",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-117",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-299"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".button",
				"originalId": "61f29c0959b6d0c1ae94631f|8bd18f06-e04f-3434-a859-ce36219f63bd",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".button",
				"originalId": "61f29c0959b6d0c1ae94631f|8bd18f06-e04f-3434-a859-ce36219f63bd",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635619216754
		},
		"e-302": {
			"id": "e-302",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-124",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-320"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635433891192
		},
		"e-303": {
			"id": "e-303",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-127",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-352"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0e7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0e7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781754847
		},
		"e-304": {
			"id": "e-304",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-124",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-315"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f166",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f166",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635433979794
		},
		"e-305": {
			"id": "e-305",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-120",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-349"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f102",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f102",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775982233
		},
		"e-307": {
			"id": "e-307",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-121",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-337"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f125",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f125",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775728812
		},
		"e-308": {
			"id": "e-308",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-127",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-356"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0eb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0eb",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781766125
		},
		"e-310": {
			"id": "e-310",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-120",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-322"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f10e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f10e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781860917
		},
		"e-311": {
			"id": "e-311",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-122",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-326"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0b3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0b3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635449088570
		},
		"e-312": {
			"id": "e-312",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-130",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-350"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f131",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f131",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775609701
		},
		"e-313": {
			"id": "e-313",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-131",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-339"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f148",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f148",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635776037621
		},
		"e-314": {
			"id": "e-314",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-121",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-360"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f129",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f129",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775739542
		},
		"e-316": {
			"id": "e-316",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-125",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-301"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f153",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f153",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635798612629
		},
		"e-317": {
			"id": "e-317",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-120",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-323"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f10a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f10a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781868659
		},
		"e-318": {
			"id": "e-318",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-127",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-354"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ef",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ef",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781775042
		},
		"e-319": {
			"id": "e-319",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-122",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-332"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ab",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ab",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635446918606
		},
		"e-321": {
			"id": "e-321",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-117",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-325"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".txt-field",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d1",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".txt-field",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d1",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781638978
		},
		"e-324": {
			"id": "e-324",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-118",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-359"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0d2",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0d2",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775425507
		},
		"e-325": {
			"id": "e-325",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-116",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-321"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".txt-field",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d1",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".txt-field",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d1",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781638966
		},
		"e-328": {
			"id": "e-328",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-117",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-344"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".back-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".back-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635595828387
		},
		"e-330": {
			"id": "e-330",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-129",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-336"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f112",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f112",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775879587
		},
		"e-333": {
			"id": "e-333",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-128",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-343"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0f3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0f3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775486866
		},
		"e-334": {
			"id": "e-334",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-121",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-362"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f12d",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f12d",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775748322
		},
		"e-335": {
			"id": "e-335",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-121",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-348"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f121",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f121",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775698704
		},
		"e-336": {
			"id": "e-336",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-129",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-330"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f112",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f112",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775879575
		},
		"e-339": {
			"id": "e-339",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-131",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-313"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f148",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f148",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635776037631
		},
		"e-340": {
			"id": "e-340",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-126",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-329"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635448902702
		},
		"e-343": {
			"id": "e-343",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-128",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-333"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0f3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0f3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775486854
		},
		"e-344": {
			"id": "e-344",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-116",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-328"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".back-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".back-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f0d4",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635595828382
		},
		"e-345": {
			"id": "e-345",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-120",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-346"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f106",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f106",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635781852426
		},
		"e-350": {
			"id": "e-350",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-130",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-312"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f131",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f131",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775609711
		},
		"e-353": {
			"id": "e-353",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-127",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-361"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0e3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0e3",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635775571859
		},
		"e-357": {
			"id": "e-357",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-116",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-358"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".close-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".close-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635595803265
		},
		"e-358": {
			"id": "e-358",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-117",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-357"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"selector": ".close-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".close-button",
				"originalId": "29ee1b45-56ce-d078-234d-c9b91de1f09a",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1635595803270
		},
		"e-363": {
			"id": "e-363",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-115",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-364"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647430615131
		},
		"e-365": {
			"id": "e-365",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-123",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-366"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0b7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f0b7",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647441562192
		},
		"e-367": {
			"id": "e-367",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-124",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-368"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f156",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "29ee1b45-56ce-d078-234d-c9b91de1f156",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647529307634
		},
		"e-369": {
			"id": "e-369",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-133",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-370"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647534248228
		},
		"e-370": {
			"id": "e-370",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_FINISH",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-132",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-369"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1647534248230
		},
		"e-371": {
			"id": "e-371",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-134",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-134-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1648650553581
		},
		"e-376": {
			"id": "e-376",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-377"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648722225646
		},
		"e-378": {
			"id": "e-378",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-379"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".black-curtain_transition",
				"originalId": "b3c10ae0-64c1-24bd-3ae0-4aa144c3201a",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".black-curtain_transition",
				"originalId": "b3c10ae0-64c1-24bd-3ae0-4aa144c3201a",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648722648359
		},
		"e-380": {
			"id": "e-380",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-552"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".nav__item",
				"originalId": "48f1ec34-fc2a-d1ce-6252-3716de61ebc0",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".nav__item",
				"originalId": "48f1ec34-fc2a-d1ce-6252-3716de61ebc0",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648725068730
		},
		"e-396": {
			"id": "e-396",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-397"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648730373881
		},
		"e-398": {
			"id": "e-398",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-399"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648730394256
		},
		"e-400": {
			"id": "e-400",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-401"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|834dc21c-d0d4-4d70-58cb-b9f497c3da30",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|834dc21c-d0d4-4d70-58cb-b9f497c3da30",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648730405531
		},
		"e-402": {
			"id": "e-402",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-403"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|24eb596e-c75f-710a-88cc-c0867ddddfc4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|24eb596e-c75f-710a-88cc-c0867ddddfc4",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648730413202
		},
		"e-404": {
			"id": "e-404",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-405"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".photos-slide",
				"originalId": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".photos-slide",
				"originalId": "656ef8b027ad4189724cf4f1|cc84a292-e56d-d2fe-db7b-33bf6e496ec8",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648732398438
		},
		"e-410": {
			"id": "e-410",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-143",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-411"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1648733755562
		},
		"e-416": {
			"id": "e-416",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-145",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|f0d8a79a-26d0-1d6b-ce36-54adc2c2b5e9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|f0d8a79a-26d0-1d6b-ce36-54adc2c2b5e9",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-145-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1649154594539
		},
		"e-417": {
			"id": "e-417",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-147",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-418"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|115ebf87-c90b-0ab8-7fc3-7a22e9694b35",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|115ebf87-c90b-0ab8-7fc3-7a22e9694b35",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": true,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1651228321583
		},
		"e-419": {
			"id": "e-419",
			"animationType": "custom",
			"eventTypeId": "SLIDER_ACTIVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-148",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-420"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".testimonial__slide",
				"originalId": "656ef8b027ad4189724cf4de|e4fca4d6-9e98-af54-b432-e68fc2695108",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".testimonial__slide",
				"originalId": "656ef8b027ad4189724cf4de|e4fca4d6-9e98-af54-b432-e68fc2695108",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1596072421071
		},
		"e-420": {
			"id": "e-420",
			"animationType": "custom",
			"eventTypeId": "SLIDER_INACTIVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-149",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-419"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".testimonial__slide",
				"originalId": "656ef8b027ad4189724cf4de|e4fca4d6-9e98-af54-b432-e68fc2695108",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".testimonial__slide",
				"originalId": "656ef8b027ad4189724cf4de|e4fca4d6-9e98-af54-b432-e68fc2695108",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1596072421074
		},
		"e-421": {
			"id": "e-421",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-84",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|cc734a68-74c6-802b-0509-e220d64516aa",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|cc734a68-74c6-802b-0509-e220d64516aa",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-84-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1652104543931
		},
		"e-424": {
			"id": "e-424",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-150",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|7571f281-9993-96ae-3b29-0f27a7a02460",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|7571f281-9993-96ae-3b29-0f27a7a02460",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-150-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1652174430891
		},
		"e-427": {
			"id": "e-427",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-151",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-151-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-151-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}],
			"createdOn": 1652187161278
		},
		"e-428": {
			"id": "e-428",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-115",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-429"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "60dcba3b-e7bc-53ed-e184-a1fe4a594dba",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "60dcba3b-e7bc-53ed-e184-a1fe4a594dba",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652200378472
		},
		"e-430": {
			"id": "e-430",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-115",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-431"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "f4cc1f5a-89c1-af4f-876c-4758e2b68f5b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "f4cc1f5a-89c1-af4f-876c-4758e2b68f5b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652283075289
		},
		"e-432": {
			"id": "e-432",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-115",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-433"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|6030a238-1312-de57-207d-c86676008de0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|6030a238-1312-de57-207d-c86676008de0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652286610319
		},
		"e-436": {
			"id": "e-436",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-54",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-54-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1652455167696
		},
		"e-437": {
			"id": "e-437",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-123",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-438"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|680bfe43-4443-1e7c-16e4-061f5cc4b835",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|680bfe43-4443-1e7c-16e4-061f5cc4b835",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652455570375
		},
		"e-440": {
			"id": "e-440",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-121",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-439"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|35923eb1-77bd-94fc-5d9d-05fc867ae38c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|35923eb1-77bd-94fc-5d9d-05fc867ae38c",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652455852943
		},
		"e-441": {
			"id": "e-441",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-152",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-442"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1652886089672
		},
		"e-443": {
			"id": "e-443",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-153",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|3e36870f-7698-104f-dbea-04e3c257f756",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|3e36870f-7698-104f-dbea-04e3c257f756",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-153-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1652893123070
		},
		"e-444": {
			"id": "e-444",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-154",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|28e84f2d-e3e7-214f-d9bd-e213d06d9b15",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|28e84f2d-e3e7-214f-d9bd-e213d06d9b15",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-154-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1652982338635
		},
		"e-445": {
			"id": "e-445",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-155",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-446"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "01335317-1c68-65ab-5190-63ba0e62ca39",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "01335317-1c68-65ab-5190-63ba0e62ca39",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653055877204
		},
		"e-446": {
			"id": "e-446",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-156",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-445"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "01335317-1c68-65ab-5190-63ba0e62ca39",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "01335317-1c68-65ab-5190-63ba0e62ca39",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653055877207
		},
		"e-447": {
			"id": "e-447",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-157",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|28e84f2d-e3e7-214f-d9bd-e213d06d9b15",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|28e84f2d-e3e7-214f-d9bd-e213d06d9b15",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-157-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1653056585361
		},
		"e-450": {
			"id": "e-450",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-451"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "0cffded4-35c1-2041-d91f-e93f08b0affe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "0cffded4-35c1-2041-d91f-e93f08b0affe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653062900130
		},
		"e-456": {
			"id": "e-456",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-144",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-457"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de47",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|93cd8abb-81d0-39d5-8366-363e0851de47",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653063554767
		},
		"e-458": {
			"id": "e-458",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-144",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-459"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5|c0d82860-5d7a-b517-d6e3-3f49dfdc26be",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5|c0d82860-5d7a-b517-d6e3-3f49dfdc26be",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653063568928
		},
		"e-460": {
			"id": "e-460",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-143",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-461"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7|b420d846-ab26-b172-ba37-3195324a2658",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7|b420d846-ab26-b172-ba37-3195324a2658",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653063765325
		},
		"e-462": {
			"id": "e-462",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-159",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-463"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|e63bacad-d24f-0eef-e91f-cacce8b86be1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|e63bacad-d24f-0eef-e91f-cacce8b86be1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": true,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653312471529
		},
		"e-463": {
			"id": "e-463",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-160",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-462"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|e63bacad-d24f-0eef-e91f-cacce8b86be1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|e63bacad-d24f-0eef-e91f-cacce8b86be1",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653312471533
		},
		"e-464": {
			"id": "e-464",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-170",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-465"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|88b4bcc5-29b3-d55f-7bfc-7e95c1f9d61f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|88b4bcc5-29b3-d55f-7bfc-7e95c1f9d61f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": true,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653312759873
		},
		"e-465": {
			"id": "e-465",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-170",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-464"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|88b4bcc5-29b3-d55f-7bfc-7e95c1f9d61f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|88b4bcc5-29b3-d55f-7bfc-7e95c1f9d61f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653312759877
		},
		"e-466": {
			"id": "e-466",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-171",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-467"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|d3eac157-c2f8-8211-2bf5-a87983f444fe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|d3eac157-c2f8-8211-2bf5-a87983f444fe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313557925
		},
		"e-467": {
			"id": "e-467",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-165",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-466"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|d3eac157-c2f8-8211-2bf5-a87983f444fe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|d3eac157-c2f8-8211-2bf5-a87983f444fe",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313557928
		},
		"e-468": {
			"id": "e-468",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-172",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-469"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|c3a2c14d-367a-19ac-91ef-f018ebd52a54",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|c3a2c14d-367a-19ac-91ef-f018ebd52a54",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313637975
		},
		"e-469": {
			"id": "e-469",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-167",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-468"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|c3a2c14d-367a-19ac-91ef-f018ebd52a54",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|c3a2c14d-367a-19ac-91ef-f018ebd52a54",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313637979
		},
		"e-470": {
			"id": "e-470",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-173",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-471"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|6e0edfd2-2bb4-fa6b-0afe-a8c74b4780d5",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|6e0edfd2-2bb4-fa6b-0afe-a8c74b4780d5",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313703148
		},
		"e-471": {
			"id": "e-471",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-169",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-470"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|6e0edfd2-2bb4-fa6b-0afe-a8c74b4780d5",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|6e0edfd2-2bb4-fa6b-0afe-a8c74b4780d5",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653313703152
		},
		"e-472": {
			"id": "e-472",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-174",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-473"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|1e783225-395b-b96b-a539-7d3b8606c71e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|1e783225-395b-b96b-a539-7d3b8606c71e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314612820
		},
		"e-473": {
			"id": "e-473",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_SECOND_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-175",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-472"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|1e783225-395b-b96b-a539-7d3b8606c71e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|1e783225-395b-b96b-a539-7d3b8606c71e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314612824
		},
		"e-474": {
			"id": "e-474",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-176",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-475"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|264c6b7f-49ed-c5c8-a3fd-195fc1a646e6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|264c6b7f-49ed-c5c8-a3fd-195fc1a646e6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314689486
		},
		"e-475": {
			"id": "e-475",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-177",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-474"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|264c6b7f-49ed-c5c8-a3fd-195fc1a646e6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|264c6b7f-49ed-c5c8-a3fd-195fc1a646e6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314689527
		},
		"e-476": {
			"id": "e-476",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-178",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-477"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|0e2f5c73-79f1-4195-6524-d14f51f6f3d6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|0e2f5c73-79f1-4195-6524-d14f51f6f3d6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314767800
		},
		"e-477": {
			"id": "e-477",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-180",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-476"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|0e2f5c73-79f1-4195-6524-d14f51f6f3d6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|0e2f5c73-79f1-4195-6524-d14f51f6f3d6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314767804
		},
		"e-478": {
			"id": "e-478",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-179",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-479"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|056b0e3e-0a76-ce34-7eba-1c9340e8260e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|056b0e3e-0a76-ce34-7eba-1c9340e8260e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314798976
		},
		"e-479": {
			"id": "e-479",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-181",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-478"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|056b0e3e-0a76-ce34-7eba-1c9340e8260e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|056b0e3e-0a76-ce34-7eba-1c9340e8260e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653314798980
		},
		"e-480": {
			"id": "e-480",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-481"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "b2839d15-cd17-e3c9-4a45-96f6c755104e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "b2839d15-cd17-e3c9-4a45-96f6c755104e",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1579628263938
		},
		"e-482": {
			"id": "e-482",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-182",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-483"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "b2839d15-cd17-e3c9-4a45-96f6c755104f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "b2839d15-cd17-e3c9-4a45-96f6c755104f",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1578680969902
		},
		"e-484": {
			"id": "e-484",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-183",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-485"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "b2839d15-cd17-e3c9-4a45-96f6c7551054",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "b2839d15-cd17-e3c9-4a45-96f6c7551054",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1578680623964
		},
		"e-486": {
			"id": "e-486",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-487"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde8679a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde8679a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653386882690
		},
		"e-488": {
			"id": "e-488",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-182",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-489"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde8679b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde8679b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653386882690
		},
		"e-490": {
			"id": "e-490",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-183",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-491"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde867a0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db|6db65384-4957-1606-9e3d-282abde867a0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653386882690
		},
		"e-492": {
			"id": "e-492",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-493"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|5257ce5e-755a-d725-a011-eb866b05f304",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|5257ce5e-755a-d725-a011-eb866b05f304",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1653427350179
		},
		"e-496": {
			"id": "e-496",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-497"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655398814727
		},
		"e-498": {
			"id": "e-498",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-499"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4f1|2da89df2-a9e1-a329-7026-d5b68904684b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4f1|2da89df2-a9e1-a329-7026-d5b68904684b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655458204718
		},
		"e-500": {
			"id": "e-500",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-501"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e7",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655805828228
		},
		"e-502": {
			"id": "e-502",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-503"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4e5",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655817705311
		},
		"e-504": {
			"id": "e-504",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-505"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655818590693
		},
		"e-506": {
			"id": "e-506",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-507"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|6cf95d47-c56b-2050-210f-9f4957a87e24",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|6cf95d47-c56b-2050-210f-9f4957a87e24",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655818677631
		},
		"e-508": {
			"id": "e-508",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-509"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4de|c7fd465f-0dde-0448-4684-83ec23b96da2",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4de|c7fd465f-0dde-0448-4684-83ec23b96da2",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655818704107
		},
		"e-510": {
			"id": "e-510",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-511"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4db",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655818731871
		},
		"e-512": {
			"id": "e-512",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-138",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-513"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"selector": ".nav__logo",
				"originalId": "48f1ec34-fc2a-d1ce-6252-3716de61ebbd",
				"appliesTo": "CLASS"
			},
			"targets": [{
				"selector": ".nav__logo",
				"originalId": "48f1ec34-fc2a-d1ce-6252-3716de61ebbd",
				"appliesTo": "CLASS"
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655819410672
		},
		"e-514": {
			"id": "e-514",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-515"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|834704a5-e135-6f2b-83d6-b6e577236679",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|834704a5-e135-6f2b-83d6-b6e577236679",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655829920592
		},
		"e-516": {
			"id": "e-516",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-517"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4da|834704a5-e135-6f2b-83d6-b6e57723667b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4da|834704a5-e135-6f2b-83d6-b6e57723667b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1655829928898
		},
		"e-518": {
			"id": "e-518",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-519"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c248",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c248",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1658996065478
		},
		"e-520": {
			"id": "e-520",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-521"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52192",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52192",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1658996076860
		},
		"e-522": {
			"id": "e-522",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-133",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-523"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4cb|b3d63899-ce32-f543-37fb-da61f1cf9c77",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4cb|b3d63899-ce32-f543-37fb-da61f1cf9c77",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1673770153320
		},
		"e-524": {
			"id": "e-524",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-7",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-7-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1683032982348
		},
		"e-529": {
			"id": "e-529",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-151",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-151-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-151-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "VIEWPORT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}],
			"createdOn": 1683032982348
		},
		"e-532": {
			"id": "e-532",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-45",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-533"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde8679a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde8679a",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683032982348
		},
		"e-534": {
			"id": "e-534",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-182",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-535"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde8679b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde8679b",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683032982348
		},
		"e-536": {
			"id": "e-536",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-183",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-537"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde867a0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed|6db65384-4957-1606-9e3d-282abde867a0",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683032982348
		},
		"e-538": {
			"id": "e-538",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-539"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683032982348
		},
		"e-540": {
			"id": "e-540",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-115",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-541"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed|20714505-08a5-087a-d8f1-f749c2c86fa6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed|20714505-08a5-087a-d8f1-f749c2c86fa6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683129095713
		},
		"e-542": {
			"id": "e-542",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-185",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-543"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "656ef8b027ad4189724cf4ed|9a4d4eb6-0d2b-855a-5231-66e32af2bc36",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ed|9a4d4eb6-0d2b-855a-5231-66e32af2bc36",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1683196674754
		},
		"e-544": {
			"id": "e-544",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_MOVE",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-75",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "656ef8b027ad4189724cf4ea|d3c12eaf-85d8-0efa-a9e5-88d484610211",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "656ef8b027ad4189724cf4ea|d3c12eaf-85d8-0efa-a9e5-88d484610211",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-75-p",
				"selectedAxis": "X_AXIS",
				"basedOn": "ELEMENT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}, {
				"continuousParameterGroupId": "a-75-p-2",
				"selectedAxis": "Y_AXIS",
				"basedOn": "ELEMENT",
				"reverse": false,
				"smoothing": 50,
				"restingState": 50
			}],
			"createdOn": 1707924156603
		},
		"e-545": {
			"id": "e-545",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLLING_IN_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-188",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "664337bfa31c2c190eb37350|bff06ba5-55bd-2eca-02c5-ef1faa4fc000",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350|bff06ba5-55bd-2eca-02c5-ef1faa4fc000",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-188-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1697538171432
		},
		"e-546": {
			"id": "e-546",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "SCROLL_INTO_VIEW",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-189",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-547"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "664337bfa31c2c190eb37350|bff06ba5-55bd-2eca-02c5-ef1faa4fc001",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350|bff06ba5-55bd-2eca-02c5-ef1faa4fc001",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": 0,
				"scrollOffsetUnit": "%",
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1697537963773
		},
		"e-550": {
			"id": "e-550",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OVER",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-191",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-551"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1715703222473
		},
		"e-551": {
			"id": "e-551",
			"name": "",
			"animationType": "preset",
			"eventTypeId": "MOUSE_OUT",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-192",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-550"
				}
			},
			"mediaQueries": ["main"],
			"target": {
				"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1715703222473
		},
		"e-552": {
			"id": "e-552",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_SCROLL",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_CONTINUOUS_ACTION",
				"config": {
					"actionListId": "a-195",
					"affectedElements": {},
					"duration": 0
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "664337bfa31c2c190eb37350",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": [{
				"continuousParameterGroupId": "a-195-p",
				"smoothing": 50,
				"startsEntering": true,
				"addStartOffset": false,
				"addOffsetValue": 50,
				"startsExiting": false,
				"addEndOffset": false,
				"endOffsetValue": 50
			}],
			"createdOn": 1715764256112
		},
		"e-553": {
			"id": "e-553",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "MOUSE_CLICK",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-196",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-554"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "664337bfa31c2c190eb37350|96399971-15c5-5b38-7e61-4ae398db09f6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350|96399971-15c5-5b38-7e61-4ae398db09f6",
				"appliesTo": "ELEMENT",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1715764554057
		},
		"e-555": {
			"id": "e-555",
			"name": "",
			"animationType": "custom",
			"eventTypeId": "PAGE_START",
			"action": {
				"id": "",
				"actionTypeId": "GENERAL_START_ACTION",
				"config": {
					"delay": 0,
					"easing": "",
					"duration": 0,
					"actionListId": "a-184",
					"affectedElements": {},
					"playInReverse": false,
					"autoStopEventId": "e-556"
				}
			},
			"mediaQueries": ["main", "medium", "small", "tiny"],
			"target": {
				"id": "664337bfa31c2c190eb37350",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			},
			"targets": [{
				"id": "664337bfa31c2c190eb37350",
				"appliesTo": "PAGE",
				"styleBlockIds": []
			}],
			"config": {
				"loop": false,
				"playInReverse": false,
				"scrollOffsetValue": null,
				"scrollOffsetUnit": null,
				"delay": null,
				"direction": null,
				"effectIn": null
			},
			"createdOn": 1715765842300
		}
	},
	"actionLists": {
		"a": {
			"id": "a",
			"title": "Show Popup",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|bc2a29a4-5b56-4fda-da05-c92bb53b8566"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|bc2a29a4-5b56-4fda-da05-c92bb53b8566"
						},
						"yValue": 135,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 700,
						"target": {
							"id": "656ef8b027ad4189724cf535|bc2a29a4-5b56-4fda-da05-c92bb53b8566"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf535|bc2a29a4-5b56-4fda-da05-c92bb53b8566"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1534233019828
		},
		"a-2": {
			"id": "a-2",
			"title": "Close Popup",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-2-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": 1,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-2-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-2-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf535|bc2a29a4-5b56-4fda-da05-c92bb53b8566"
						},
						"yValue": 135,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-2-n-3",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf535|eba28960-8905-76da-5ae1-1a434ccda9bf"
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1534233378451
		},
		"a-7": {
			"id": "a-7",
			"title": "Parallax - cercles",
			"continuousParameterGroups": [{
				"id": "a-7-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-7-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.rouge.cercle-1",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "2def6f11-1de0-09fc-295e-437d8e95a902", "654bc14e-5add-2a54-e38c-e78fe023f627"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-2",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d395af15-74af-c994-f8b5-c1a322ee1a4b", "66021f0c-25b2-04f2-2674-6f32b57683f9"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.jaune.cercle-3b",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "845a5628-2791-021c-a3e4-02196dc35415", "b706c312-d103-b938-9569-386bd9b0c490"]
							},
							"yValue": 80,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-13",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-4",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d395af15-74af-c994-f8b5-c1a322ee1a4b", "b461c1e8-a692-8e55-aecd-33b5406c9a26"]
							},
							"yValue": 360,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-15",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-5",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "5f65311b-f2fd-a2d8-728c-7e77d6da53ce", "a3948a7e-5c9f-c177-24fd-580ce49f9bd9"]
							},
							"yValue": -640,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-17",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.cercle-6",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "f4b4401f-f320-93c8-0dba-b719a8ffba0f"]
							},
							"yValue": 240,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-19",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.cercle-7",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d0fa3715-b44e-256d-0d54-80ab61918369"]
							},
							"yValue": 960,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-21",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.blue.cercle-8",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "f44f86ec-61cb-8beb-9c40-6c5ebe28510f", "8170541d-f8bb-c525-85f0-7884ddbee423"]
							},
							"yValue": -400,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-27",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.yellow.cercle-11",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "756eceb5-c913-8c86-6557-ffa58d51560c", "8ebcaea0-47b3-d96d-ae5a-0286e6a5c908"]
							},
							"yValue": -800,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 30,
					"actionItems": [{
						"id": "a-7-n-29",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-12",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "6436b1e1-6c9f-c5f8-718c-e78d54d471e8", "441b3993-5402-a395-ee6f-1c807569700b"]
							},
							"yValue": 800,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-24",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.yellow.cercle-9b",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "c6bdfc84-2e2f-4a79-e3f9-2bfcb6eb586d", "c553f421-07ec-3cca-1455-8a2ea9bf9803"]
							},
							"yValue": -560,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 40,
					"actionItems": [{
						"id": "a-7-n-25",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.blue.cercle-10",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "bcb2f44b-b34c-f3c5-24a8-ff74785ca313", "9cacd727-ec57-00dc-cd7c-bf0cad6b06b3"]
							},
							"yValue": 800,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 50,
					"actionItems": [{
						"id": "a-7-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-2",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d395af15-74af-c994-f8b5-c1a322ee1a4b", "66021f0c-25b2-04f2-2674-6f32b57683f9"]
							},
							"yValue": -1000,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-14",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-4",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d395af15-74af-c994-f8b5-c1a322ee1a4b", "b461c1e8-a692-8e55-aecd-33b5406c9a26"]
							},
							"yValue": -160,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 72,
					"actionItems": [{
						"id": "a-7-n-20",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.cercle-7",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "d0fa3715-b44e-256d-0d54-80ab61918369"]
							},
							"yValue": -240,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 90,
					"actionItems": [{
						"id": "a-7-n-6",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.jaune.cercle-3b",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "845a5628-2791-021c-a3e4-02196dc35415", "b706c312-d103-b938-9569-386bd9b0c490"]
							},
							"yValue": -300,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-16",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-5",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "5f65311b-f2fd-a2d8-728c-7e77d6da53ce", "a3948a7e-5c9f-c177-24fd-580ce49f9bd9"]
							},
							"yValue": 320,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-18",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.cercle-6",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "f4b4401f-f320-93c8-0dba-b719a8ffba0f"]
							},
							"yValue": -480,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-22",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.blue.cercle-8",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "f44f86ec-61cb-8beb-9c40-6c5ebe28510f", "8170541d-f8bb-c525-85f0-7884ddbee423"]
							},
							"yValue": 240,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-26",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.blue.cercle-10",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "bcb2f44b-b34c-f3c5-24a8-ff74785ca313", "9cacd727-ec57-00dc-cd7c-bf0cad6b06b3"]
							},
							"yValue": -400,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-30",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.red.cercle-12",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "6436b1e1-6c9f-c5f8-718c-e78d54d471e8", "441b3993-5402-a395-ee6f-1c807569700b"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-23",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.yellow.cercle-9b",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "c6bdfc84-2e2f-4a79-e3f9-2bfcb6eb586d", "c553f421-07ec-3cca-1455-8a2ea9bf9803"]
							},
							"yValue": 240,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-7-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.rouge.cercle-1",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "2def6f11-1de0-09fc-295e-437d8e95a902", "654bc14e-5add-2a54-e38c-e78fe023f627"]
							},
							"yValue": 2000,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-7-n-28",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cercle-single.yellow.cercle-11",
								"selectorGuids": ["1a76f5fe-4bee-1ef0-d341-e974f567d0e4", "756eceb5-c913-8c86-6557-ffa58d51560c", "8ebcaea0-47b3-d96d-ae5a-0286e6a5c908"]
							},
							"yValue": 480,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1584782965684
		},
		"a-12": {
			"id": "a-12",
			"title": "Colonnes - Projets",
			"continuousParameterGroups": [{
				"id": "a-12-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-12-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4ea|5081d615-0f25-5fe1-7685-9edf5f769155"
							},
							"yValue": -64,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-12-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "SIBLINGS",
								"id": "656ef8b027ad4189724cf4ea|a8b3be54-2760-64c9-6d29-513613eea111"
							},
							"yValue": 48,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-12-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4ea|5081d615-0f25-5fe1-7685-9edf5f769155"
							},
							"yValue": 120,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-12-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "SIBLINGS",
								"id": "656ef8b027ad4189724cf4ea|a8b3be54-2760-64c9-6d29-513613eea111"
							},
							"yValue": -120,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1585822853339
		},
		"a-11": {
			"id": "a-11",
			"title": "Image - Case study",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-11-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4ea|05abe5e8-41c7-4f66-efec-0d8c54cbafad"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-11-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4ea|05abe5e8-41c7-4f66-efec-0d8c54cbafad"
						},
						"yValue": 48,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-11-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4ea|05abe5e8-41c7-4f66-efec-0d8c54cbafad"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-11-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4ea|05abe5e8-41c7-4f66-efec-0d8c54cbafad"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1585670560923
		},
		"a-23": {
			"id": "a-23",
			"title": "Grayscale",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-23-n-2",
					"actionTypeId": "STYLE_FILTER",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slider-slide",
							"selectorGuids": ["3e11612c-c1d0-715e-9d91-d299812cd048"]
						},
						"filters": [{
							"type": "grayscale",
							"filterId": "d25d",
							"value": 0,
							"unit": "%"
						}]
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1586437183774
		},
		"a-24": {
			"id": "a-24",
			"title": "Grayscale - Out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-24-n",
					"actionTypeId": "STYLE_FILTER",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slider-slide",
							"selectorGuids": ["3e11612c-c1d0-715e-9d91-d299812cd048"]
						},
						"filters": [{
							"type": "grayscale",
							"filterId": "d25d",
							"value": 0,
							"unit": "%"
						}]
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-24-n-2",
					"actionTypeId": "STYLE_FILTER",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slider-slide",
							"selectorGuids": ["3e11612c-c1d0-715e-9d91-d299812cd048"]
						},
						"filters": [{
							"type": "grayscale",
							"filterId": "f2ee",
							"value": 100,
							"unit": "%"
						}]
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1586437183774
		},
		"a-21": {
			"id": "a-21",
			"title": "Cursor - Hover (out)",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-21-n-4",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"widthValue": 40,
						"heightValue": 40,
						"widthUnit": "PX",
						"heightUnit": "PX",
						"locked": true
					}
				}, {
					"id": "a-21-n-5",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-21-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-21-n",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"widthValue": 10,
						"heightValue": 10,
						"widthUnit": "PX",
						"heightUnit": "PX",
						"locked": false
					}
				}, {
					"id": "a-21-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-21-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 200,
						"target": {},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1586363913674
		},
		"a-184": {
			"id": "a-184",
			"title": "Load - Curtain",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-184-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-184-n-2",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"xValue": 85,
						"xUnit": "deg",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-184-n-9",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"value": "block"
					}
				}, {
					"id": "a-184-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black_curtain",
							"selectorGuids": ["b8762b42-abc4-5ebc-6b8e-a4b75f77f635"]
						},
						"value": "block"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-184-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inOutQuad",
						"duration": 1000,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"yValue": -130,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-184-n-4",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 850,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"xValue": 0,
						"xUnit": "deg",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-184-n-11",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black_curtain",
							"selectorGuids": ["b8762b42-abc4-5ebc-6b8e-a4b75f77f635"]
						},
						"value": "none"
					}
				}, {
					"id": "a-184-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 850,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"value": "none"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-184-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"yValue": 130,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-184-n-8",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"zValue": 180,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1633463713015
		},
		"a-25": {
			"id": "a-25",
			"title": "Gif - à propos",
			"continuousParameterGroups": [{
				"id": "a-25-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 30,
					"actionItems": [{
						"id": "a-25-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4db|8fe53cfd-796b-12cb-4b91-3f62128dbc58"
							},
							"yValue": -160,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-25-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4db|11062cd1-f8b6-6480-7a0b-1275dfcbd866"
							},
							"yValue": 160,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 50,
					"actionItems": [{
						"id": "a-25-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "ease",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4db|8fe53cfd-796b-12cb-4b91-3f62128dbc58"
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-25-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4db|11062cd1-f8b6-6480-7a0b-1275dfcbd866"
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1586959710873
		},
		"a-42": {
			"id": "a-42",
			"title": "Parallax - Landing page",
			"continuousParameterGroups": [{
				"id": "a-42-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-42-n-15",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--1",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "c5194e3c-982d-083f-1dab-3ed122434c02"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-42-n-17",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--2",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "b00f3433-799e-015b-5117-529d86cf42c4"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-42-n-19",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--3",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "ba7bc67d-af7e-dc38-4eb1-1848abd9cc72"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 10,
					"actionItems": [{
						"id": "a-42-n-16",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--1",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "c5194e3c-982d-083f-1dab-3ed122434c02"]
							},
							"yValue": 13.33,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-42-n-18",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--2",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "b00f3433-799e-015b-5117-529d86cf42c4"]
							},
							"yValue": 8.88,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-42-n-20",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".webpages__container.is--3",
								"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "ba7bc67d-af7e-dc38-4eb1-1848abd9cc72"]
							},
							"yValue": 4.44,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1585067635486
		},
		"a-45": {
			"id": "a-45",
			"title": "WG OnLoad 4",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-45-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "b2839d15-cd17-e3c9-4a45-96f6c755104e"
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-45-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 300,
						"target": {
							"useEventTarget": true,
							"id": "b2839d15-cd17-e3c9-4a45-96f6c755104e"
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1579628269665
		},
		"a-46": {
			"id": "a-46",
			"title": "WG Dropdown 1-1",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-46-n",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".wg-dd-1-list",
							"selectorGuids": ["890677e4-fa19-cfcf-afa5-2fb2c0f9293c"]
						},
						"heightValue": 0,
						"widthUnit": "%",
						"heightUnit": "%",
						"locked": false
					}
				}, {
					"id": "a-46-n-2",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "5ee374a338b51ef3df01a6f3|834766fe-7106-1d89-7156-4fb64c7cd26b"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-46-n-3",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 0,
						"target": {
							"useEventTarget": true,
							"id": "5ee374a338b51ef3df01a6f3|834766fe-7106-1d89-7156-4fb64c7cd26b"
						},
						"globalSwatchId": "0a038bb9",
						"rValue": 255,
						"bValue": 255,
						"gValue": 255,
						"aValue": 1
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-46-n-4",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 300,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".wg-dd-1-list",
							"selectorGuids": ["890677e4-fa19-cfcf-afa5-2fb2c0f9293c"]
						},
						"widthUnit": "PX",
						"heightUnit": "AUTO",
						"locked": false
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1578694894509
		},
		"a-47": {
			"id": "a-47",
			"title": "WG Dropdown 1-2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-47-n",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 300,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".wg-dd-1-list",
							"selectorGuids": ["890677e4-fa19-cfcf-afa5-2fb2c0f9293c"]
						},
						"heightValue": 0,
						"widthUnit": "%",
						"heightUnit": "%",
						"locked": false
					}
				}, {
					"id": "a-47-n-2",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": true,
							"id": "5ee374a338b51ef3df01a6f3|834766fe-7106-1d89-7156-4fb64c7cd26b"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1578694894509
		},
		"a-54": {
			"id": "a-54",
			"title": "Photos - texte slider",
			"continuousParameterGroups": [{
				"id": "a-54-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-54-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".photos__text-slider",
								"selectorGuids": ["f990db06-303c-b531-c5a8-68bfc365348c"]
							},
							"xValue": 1000,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-54-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".photos__text-slider",
								"selectorGuids": ["f990db06-303c-b531-c5a8-68bfc365348c"]
							},
							"xValue": -2000,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1599747305506
		},
		"a-143": {
			"id": "a-143",
			"title": "Photos - In",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-143-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-143-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-143-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inOutQuart",
						"duration": 1400,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-143-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1648734303599
		},
		"a-67": {
			"id": "a-67",
			"title": "Bouton contact mobile",
			"continuousParameterGroups": [{
				"id": "a-67-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 2,
					"actionItems": [{
						"id": "a-67-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "53935799-fc91-c813-6775-898bb32c328e"
							},
							"yValue": 160,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 6,
					"actionItems": [{
						"id": "a-67-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "53935799-fc91-c813-6775-898bb32c328e"
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1604329949122
		},
		"a-62": {
			"id": "a-62",
			"title": "Page transition - in",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-62-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inQuint",
						"duration": 1200,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-62-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"value": "none"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-62-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inOutCubic",
						"duration": 1200,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-62-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1601044572893
		},
		"a-73": {
			"id": "a-73",
			"title": "Control hover - In",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-73-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".control__fill",
							"selectorGuids": ["32045839-7b2a-b6b9-3012-dd735ced4a72"]
						},
						"xValue": 0,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-73-n-7",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "0a038bb9",
						"rValue": 255,
						"bValue": 255,
						"gValue": 255,
						"aValue": 1
					}
				}, {
					"id": "a-73-n-9",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-73-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".control__fill",
							"selectorGuids": ["32045839-7b2a-b6b9-3012-dd735ced4a72"]
						},
						"xValue": -100,
						"yValue": 100,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-73-n-8",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 0,
						"easing": "easeInOut",
						"duration": 400,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "db501570",
						"rValue": 27,
						"bValue": 27,
						"gValue": 27,
						"aValue": 1
					}
				}, {
					"id": "a-73-n-10",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "c1e7705a",
						"rValue": 253,
						"bValue": 40,
						"gValue": 162,
						"aValue": 1
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1617476139421
		},
		"a-74": {
			"id": "a-74",
			"title": "Control Hover Out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-74-n",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 200,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}, {
					"id": "a-74-n-2",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 100,
						"easing": "outQuint",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "656ef8b027ad4189724cf4de|51a850fa-a40e-8bfc-4faa-a95dec2262a4"
						},
						"globalSwatchId": "0a038bb9",
						"rValue": 255,
						"bValue": 255,
						"gValue": 255,
						"aValue": 1
					}
				}, {
					"id": "a-74-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 100,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".control__fill",
							"selectorGuids": ["32045839-7b2a-b6b9-3012-dd735ced4a72"]
						},
						"xValue": 0,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1617476139421
		},
		"a-55": {
			"id": "a-55",
			"title": "Hover photo",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-55-n-7",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": "flex"
					}
				}, {
					"id": "a-55-n-15",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photo__cover",
							"selectorGuids": ["ac079638-0279-6804-d1bb-9b289121c9d0"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-55-n-17",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-text",
							"selectorGuids": ["f5ca23c7-3a0a-b3f5-c6f4-2d5736c950e9"]
						},
						"value": "block"
					}
				}, {
					"id": "a-55-n-20",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".heading-xs.is--collection",
							"selectorGuids": ["ded8d7f5-f7d9-7f3d-1146-de5144f2cadf", "0b13fdef-e76d-0b01-9beb-07b12c9fd9eb"]
						},
						"yValue": -1,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-55-n-21",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-title",
							"selectorGuids": ["3d8f8068-13c1-2755-fc1c-50d7dc2dc74a"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-55-n-23",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": 0.2,
						"unit": ""
					}
				}, {
					"id": "a-55-n-25",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"yValue": 2,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-55-n-27",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-55-n-8",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": "block"
					}
				}, {
					"id": "a-55-n-16",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photo__cover",
							"selectorGuids": ["ac079638-0279-6804-d1bb-9b289121c9d0"]
						},
						"xValue": 1.1,
						"yValue": 1.1,
						"locked": true
					}
				}, {
					"id": "a-55-n-18",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-text",
							"selectorGuids": ["f5ca23c7-3a0a-b3f5-c6f4-2d5736c950e9"]
						},
						"value": "block"
					}
				}, {
					"id": "a-55-n-24",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-55-n-26",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-55-n-28",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-55-n-19",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".heading-xs.is--collection",
							"selectorGuids": ["ded8d7f5-f7d9-7f3d-1146-de5144f2cadf", "0b13fdef-e76d-0b01-9beb-07b12c9fd9eb"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-55-n-22",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-title",
							"selectorGuids": ["3d8f8068-13c1-2755-fc1c-50d7dc2dc74a"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1599748982550
		},
		"a-79": {
			"id": "a-79",
			"title": "Hover photo - out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-79-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".heading-xs.is--collection",
							"selectorGuids": ["ded8d7f5-f7d9-7f3d-1146-de5144f2cadf", "0b13fdef-e76d-0b01-9beb-07b12c9fd9eb"]
						},
						"yValue": -1,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-79-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-title",
							"selectorGuids": ["3d8f8068-13c1-2755-fc1c-50d7dc2dc74a"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-79-n-2",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photo__cover",
							"selectorGuids": ["ac079638-0279-6804-d1bb-9b289121c9d0"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-79-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": 0.2,
						"unit": ""
					}
				}, {
					"id": "a-79-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"yValue": 2,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-79-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".collection__single-date",
							"selectorGuids": ["80d2e7eb-fca4-aaf1-b6a1-feefcbbd1e1d"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-79-n-3",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single-text",
							"selectorGuids": ["f5ca23c7-3a0a-b3f5-c6f4-2d5736c950e9"]
						},
						"value": "block"
					}
				}, {
					"id": "a-79-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".photos__single--filter",
							"selectorGuids": ["43538317-aa54-1f75-af99-f5e17e6db8c2"]
						},
						"value": "flex"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1599748982550
		},
		"a-135": {
			"id": "a-135",
			"title": "Load - Photos",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-135-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "041ae113-a1ab-7d75-9348-1f3ecf4b6f57"
						},
						"yValue": 100,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|f6d1e900-4e6d-3aff-5bf3-54af645759f3"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|58d22464-cdde-6137-c028-446f87cc2d9c"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|13f31a82-641e-6218-a2e5-49db2b175f9e"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-9",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|499e9d59-ff2f-f312-aff2-2c88ff471ecc"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-11",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|892c0934-7faf-ea86-6f87-2d7c6104aa94"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-13",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|f3ecc6d0-5194-e366-313c-6f4121396e16"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-15",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|120e0de7-22f0-580a-db0a-2dd4059c25a1"
						},
						"xValue": -20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-17",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|120e0de7-22f0-580a-db0a-2dd4059c25a1"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-19",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|d1a8ac99-b334-863b-a3ad-d24cdc7ea456"
						},
						"xValue": -20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-20",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|d1a8ac99-b334-863b-a3ad-d24cdc7ea456"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-23",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|e66fba3e-9e2e-9da9-6898-576ea96578f7"
						},
						"xValue": -20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-24",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|e66fba3e-9e2e-9da9-6898-576ea96578f7"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-27",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|7e55b9ab-6bed-1d36-da49-406b3650ebe3"
						},
						"xValue": -20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-28",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|7e55b9ab-6bed-1d36-da49-406b3650ebe3"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-31",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|69b4c785-c929-6f67-9718-1868d442771b"
						},
						"xValue": -20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-32",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|69b4c785-c929-6f67-9718-1868d442771b"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-35",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|2e4e6bc9-4020-d7b7-6b0d-90cbb5cbe6a1"
						},
						"xValue": 20,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-36",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|2e4e6bc9-4020-d7b7-6b0d-90cbb5cbe6a1"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-39",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a30"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-135-n-43",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a32"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-135-n-45",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a31"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-135-n-47",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a34"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-135-n-53",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|17d88ede-8764-51fc-b984-9fda381bcc81"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-135-n-41",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a33"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-135-n-18",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "ease",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|120e0de7-22f0-580a-db0a-2dd4059c25a1"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-16",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|120e0de7-22f0-580a-db0a-2dd4059c25a1"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-30",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|7e55b9ab-6bed-1d36-da49-406b3650ebe3"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-29",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "",
						"duration": 600,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|7e55b9ab-6bed-1d36-da49-406b3650ebe3"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-21",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "ease",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|d1a8ac99-b334-863b-a3ad-d24cdc7ea456"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-22",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|d1a8ac99-b334-863b-a3ad-d24cdc7ea456"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-34",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 600,
						"easing": "ease",
						"duration": 600,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|69b4c785-c929-6f67-9718-1868d442771b"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-33",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "swingTo",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|69b4c785-c929-6f67-9718-1868d442771b"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-37",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 600,
						"easing": "ease",
						"duration": 600,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|2e4e6bc9-4020-d7b7-6b0d-90cbb5cbe6a1"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-38",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "swingTo",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|2e4e6bc9-4020-d7b7-6b0d-90cbb5cbe6a1"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|f6d1e900-4e6d-3aff-5bf3-54af645759f3"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-26",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 600,
						"easing": "ease",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|e66fba3e-9e2e-9da9-6898-576ea96578f7"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-135-n-25",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|e66fba3e-9e2e-9da9-6898-576ea96578f7"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 850,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|58d22464-cdde-6137-c028-446f87cc2d9c"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 900,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|13f31a82-641e-6218-a2e5-49db2b175f9e"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-10",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 950,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|499e9d59-ff2f-f312-aff2-2c88ff471ecc"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-12",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1000,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|892c0934-7faf-ea86-6f87-2d7c6104aa94"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-40",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1050,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a32"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-135-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1050,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"id": "041ae113-a1ab-7d75-9348-1f3ecf4b6f57"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-54",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1050,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|17d88ede-8764-51fc-b984-9fda381bcc81"
						},
						"value": 0.02,
						"unit": ""
					}
				}, {
					"id": "a-135-n-14",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1100,
						"easing": "outSine",
						"duration": 400,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|f3ecc6d0-5194-e366-313c-6f4121396e16"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-135-n-42",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1150,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a33"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-135-n-44",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1200,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a31"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-135-n-46",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1250,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a30"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-135-n-48",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1300,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4f1|3997eb14-f712-a664-6b03-052447398a34"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1648652852781
		},
		"a-136": {
			"id": "a-136",
			"title": "Load - Menu",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-136-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".nav__logo-img",
							"selectorGuids": ["32c9ae9b-5b2b-aa63-5fc2-b0c8547bcf77"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-136-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".nav__menu",
							"selectorGuids": ["97eba5c6-f0ba-db12-dd70-34a3d80f226e"]
						},
						"xValue": 10,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-136-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".nav__menu",
							"selectorGuids": ["97eba5c6-f0ba-db12-dd70-34a3d80f226e"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-136-n-28",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".nav__logo-img",
							"selectorGuids": ["32c9ae9b-5b2b-aa63-5fc2-b0c8547bcf77"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-136-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "ease",
						"duration": 1000,
						"target": {
							"selector": ".nav__logo-img",
							"selectorGuids": ["32c9ae9b-5b2b-aa63-5fc2-b0c8547bcf77"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-136-n-29",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"selector": ".nav__logo-img",
							"selectorGuids": ["32c9ae9b-5b2b-aa63-5fc2-b0c8547bcf77"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-136-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"selector": ".nav__menu",
							"selectorGuids": ["97eba5c6-f0ba-db12-dd70-34a3d80f226e"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-136-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 500,
						"easing": "ease",
						"duration": 600,
						"target": {
							"selector": ".nav__menu",
							"selectorGuids": ["97eba5c6-f0ba-db12-dd70-34a3d80f226e"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1648653025692
		},
		"a-185": {
			"id": "a-185",
			"title": "Click Transition",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-185-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 1000,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-185-n-7",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"value": "block"
					}
				}, {
					"id": "a-185-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"value": "block"
					}
				}, {
					"id": "a-185-n-3",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "easeOut",
						"duration": 850,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"xValue": 85,
						"xUnit": "deg",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-185-n-4",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 2000,
						"easing": "easeOut",
						"duration": 850,
						"target": {
							"selector": ".loader-bottom-img",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f08"]
						},
						"xValue": 0,
						"xUnit": "deg",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-185-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 2000,
						"easing": "outQuart",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"yValue": 130,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-185-n-6",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 2000,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".loader",
							"selectorGuids": ["38a17ead-b301-394c-76cb-5148fe9e8f05"]
						},
						"zValue": 180,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1633463957551
		},
		"a-82": {
			"id": "a-82",
			"title": "Text ring",
			"continuousParameterGroups": [{
				"id": "a-82-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-82-n",
						"actionTypeId": "TRANSFORM_ROTATE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": true,
								"id": "656ef8b027ad4189724cf4de|f0249b79-bd11-0b7d-7c24-040870c19b4e"
							},
							"zValue": 0,
							"xUnit": "DEG",
							"yUnit": "DEG",
							"zUnit": "deg"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-82-n-2",
						"actionTypeId": "TRANSFORM_ROTATE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": true,
								"id": "656ef8b027ad4189724cf4de|f0249b79-bd11-0b7d-7c24-040870c19b4e"
							},
							"zValue": 360,
							"xUnit": "DEG",
							"yUnit": "DEG",
							"zUnit": "deg"
						}
					}]
				}]
			}],
			"createdOn": 1644491420003
		},
		"a-83": {
			"id": "a-83",
			"title": "Scroll text",
			"continuousParameterGroups": [{
				"id": "a-83-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-83-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".super-text.first.is--outline-text",
								"selectorGuids": ["1da587d9-0b11-925c-33ad-60a9792b3d13", "61b289fc-fecb-3498-1250-b91f7d377508", "e2fc0ccb-df90-9bbb-e204-43120a68fc0b"]
							},
							"xValue": 0,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-83-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".super-text.second",
								"selectorGuids": ["1da587d9-0b11-925c-33ad-60a9792b3d13", "ea1967ad-8622-8460-a05a-b0be6a0d2ca8"]
							},
							"xValue": 0,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-83-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".super-text.first.is--outline-text",
								"selectorGuids": ["1da587d9-0b11-925c-33ad-60a9792b3d13", "61b289fc-fecb-3498-1250-b91f7d377508", "e2fc0ccb-df90-9bbb-e204-43120a68fc0b"]
							},
							"xValue": 4,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-83-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".super-text.second",
								"selectorGuids": ["1da587d9-0b11-925c-33ad-60a9792b3d13", "ea1967ad-8622-8460-a05a-b0be6a0d2ca8"]
							},
							"xValue": -4,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1644493086453
		},
		"a-84": {
			"id": "a-84",
			"title": "Parallax - photos",
			"continuousParameterGroups": [{
				"id": "a-84-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-84-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.one",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "7a800d33-f80a-3aef-ee03-ccdcd98b3091"]
							},
							"yValue": 16,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.tow",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "f317a877-e294-75b8-ec6f-f2a2d5fc3672"]
							},
							"yValue": 12,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.three",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "0120faee-8302-1cbe-4505-3cceed9ba8e7"]
							},
							"yValue": 8,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-7",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.four",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "412ac48a-8d13-238b-3021-218019a539d9"]
							},
							"yValue": 4,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-84-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.one",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "7a800d33-f80a-3aef-ee03-ccdcd98b3091"]
							},
							"yValue": -16,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.tow",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "f317a877-e294-75b8-ec6f-f2a2d5fc3672"]
							},
							"yValue": -12,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-6",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.three",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "0120faee-8302-1cbe-4505-3cceed9ba8e7"]
							},
							"yValue": -8,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-84-n-8",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".photos-bg__column.four",
								"selectorGuids": ["6a210fa6-70e2-deff-2493-295d3ef46164", "412ac48a-8d13-238b-3021-218019a539d9"]
							},
							"yValue": -4,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1644493662247
		},
		"a-85": {
			"id": "a-85",
			"title": "Cursor",
			"continuousParameterGroups": [{
				"id": "a-85-p",
				"type": "MOUSE_X",
				"parameterLabel": "Mouse X",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-85-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cursor__circle",
								"selectorGuids": ["778b1e9d-dda5-39ae-1a6f-3edaf268624e"]
							},
							"xValue": -50,
							"xUnit": "vw",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-85-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cursor__circle",
								"selectorGuids": ["778b1e9d-dda5-39ae-1a6f-3edaf268624e"]
							},
							"xValue": 50,
							"xUnit": "vw",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}, {
				"id": "a-85-p-2",
				"type": "MOUSE_Y",
				"parameterLabel": "Mouse Y",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-85-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cursor__circle",
								"selectorGuids": ["778b1e9d-dda5-39ae-1a6f-3edaf268624e"]
							},
							"yValue": -50,
							"xUnit": "PX",
							"yUnit": "vh",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-85-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".cursor__circle",
								"selectorGuids": ["778b1e9d-dda5-39ae-1a6f-3edaf268624e"]
							},
							"yValue": 50,
							"xUnit": "PX",
							"yUnit": "vh",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1644507963708
		},
		"a-88": {
			"id": "a-88",
			"title": "Dropdown - appear",
			"continuousParameterGroups": [{
				"id": "a-88-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 5,
					"actionItems": [{
						"id": "a-88-n",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".dropdown",
								"selectorGuids": ["e385c32f-5297-9094-8f04-2d294a2bc4b8"]
							},
							"value": 0,
							"unit": ""
						}
					}]
				}, {
					"keyframe": 10,
					"actionItems": [{
						"id": "a-88-n-2",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".dropdown",
								"selectorGuids": ["e385c32f-5297-9094-8f04-2d294a2bc4b8"]
							},
							"value": 1,
							"unit": ""
						}
					}]
				}]
			}],
			"createdOn": 1645809591613
		},
		"a-89": {
			"id": "a-89",
			"title": "Dropdown photos - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-89-n",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdow__icon",
							"selectorGuids": ["51ef079b-7368-647b-f36d-4495a794af39"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-89-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": "none"
					}
				}, {
					"id": "a-89-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"yValue": 320,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-89-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-89-n-5",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdow__icon",
							"selectorGuids": ["51ef079b-7368-647b-f36d-4495a794af39"]
						},
						"zValue": -180,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-89-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": "block"
					}
				}, {
					"id": "a-89-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"yValue": 6,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-89-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1645807241517
		},
		"a-90": {
			"id": "a-90",
			"title": "Dropdown photos - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-90-n",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdow__icon",
							"selectorGuids": ["51ef079b-7368-647b-f36d-4495a794af39"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-90-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"yValue": 320,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-90-n-3",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": "none"
					}
				}, {
					"id": "a-90-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 200,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".dropdown__list",
							"selectorGuids": ["8bc98bba-2696-b725-3b7f-7b9c6e445780"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1645807241517
		},
		"a-91": {
			"id": "a-91",
			"title": "Photo home - Move",
			"continuousParameterGroups": [{
				"id": "a-91-p",
				"type": "MOUSE_X",
				"parameterLabel": "Mouse X",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-91-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4cb|1ab57201-c476-c2b0-7aa9-86f41b75eb30"
							},
							"xValue": -3,
							"xUnit": "vw",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-91-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4cb|1ab57201-c476-c2b0-7aa9-86f41b75eb30"
							},
							"xValue": 3,
							"xUnit": "vw",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}, {
				"id": "a-91-p-2",
				"type": "MOUSE_Y",
				"parameterLabel": "Mouse Y",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-91-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4cb|1ab57201-c476-c2b0-7aa9-86f41b75eb30"
							},
							"yValue": -1,
							"xUnit": "PX",
							"yUnit": "vh",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-91-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4cb|1ab57201-c476-c2b0-7aa9-86f41b75eb30"
							},
							"yValue": 1,
							"xUnit": "PX",
							"yUnit": "vh",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1646311338296
		},
		"a-92": {
			"id": "a-92",
			"title": "Home Photographe hover - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-92-n-2",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}, {
					"id": "a-92-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".intro__link.is--second",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "f81a5540-1c79-5f80-02bc-7b9c1d0dd586"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-92-n-9",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".intro__link.is--first",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "6f237876-5a64-f43e-de12-feb1d56f4b4e"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-92-n",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b"
						},
						"globalSwatchId": "db501570",
						"rValue": 27,
						"bValue": 27,
						"gValue": 27,
						"aValue": 1
					}
				}, {
					"id": "a-92-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".intro__link.is--second",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "f81a5540-1c79-5f80-02bc-7b9c1d0dd586"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-92-n-10",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".intro__link.is--first",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "6f237876-5a64-f43e-de12-feb1d56f4b4e"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1646313968917
		},
		"a-96": {
			"id": "a-96",
			"title": "Home Photographe hover - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-96-n",
					"actionTypeId": "STYLE_TEXT_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "656ef8b027ad4189724cf4cb|756ec37e-6306-f5c6-6e9b-77e2ff85246b"
						},
						"globalSwatchId": "",
						"rValue": 0,
						"bValue": 0,
						"gValue": 0,
						"aValue": 0
					}
				}, {
					"id": "a-96-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".intro__link.is--second",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "f81a5540-1c79-5f80-02bc-7b9c1d0dd586"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-96-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".intro__link.is--first",
							"selectorGuids": ["89797d13-1ee6-dc47-78ce-b07fabfb8f35", "6f237876-5a64-f43e-de12-feb1d56f4b4e"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1646313968917
		},
		"a-97": {
			"id": "a-97",
			"title": "FAQ - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-97-n",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-97-n-3",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": "none"
					}
				}, {
					"id": "a-97-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-97-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"yValue": -4,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-97-n-2",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"yValue": 0,
						"zValue": -90,
						"xUnit": "DEG",
						"yUnit": "deg",
						"zUnit": "deg"
					}
				}, {
					"id": "a-97-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-97-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-97-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1646398921594
		},
		"a-98": {
			"id": "a-98",
			"title": "FAQ - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-98-n",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-98-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-98-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"yValue": -4,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-98-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".faq__answer",
							"selectorGuids": ["eab097c6-29fa-56eb-afe1-fafed63de968"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1646398921594
		},
		"a-99": {
			"id": "a-99",
			"title": "FAQ hover - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-99-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"xValue": 0,
						"xUnit": "em",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-99-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".question",
							"selectorGuids": ["5d032030-5dd1-8ab3-d34c-04d2496f0e22"]
						},
						"xValue": 0,
						"xUnit": "em",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-99-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"xValue": -0.56,
						"yValue": null,
						"xUnit": "em",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-99-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".question",
							"selectorGuids": ["5d032030-5dd1-8ab3-d34c-04d2496f0e22"]
						},
						"xValue": 0.28,
						"yValue": null,
						"xUnit": "em",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1646401292209
		},
		"a-100": {
			"id": "a-100",
			"title": "FAQ hover - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-100-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".faq__arrow",
							"selectorGuids": ["14f3503a-78ff-74b2-8252-787b94d99a97"]
						},
						"xValue": 0,
						"xUnit": "em",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-100-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 600,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".question",
							"selectorGuids": ["5d032030-5dd1-8ab3-d34c-04d2496f0e22"]
						},
						"xValue": 0,
						"xUnit": "em",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1646401292209
		},
		"a-101": {
			"id": "a-101",
			"title": "Menu Mobile - Out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-101-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"selector": ".nav__mobile",
							"selectorGuids": ["2ac44fb7-7562-b9b8-9318-d81bca116b56"]
						},
						"yValue": 1200,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-101-n-2",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 200,
						"target": {
							"id": "5623632d-f38a-2d34-8114-6064e5ea4a18"
						},
						"globalSwatchId": "e0b3ea92",
						"rValue": 144,
						"bValue": 151,
						"gValue": 194,
						"aValue": 1
					}
				}, {
					"id": "a-101-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 400,
						"target": {},
						"yValue": -24,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-101-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 400,
						"target": {},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-101-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".nav__mobile",
							"selectorGuids": ["2ac44fb7-7562-b9b8-9318-d81bca116b56"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1626362471383
		},
		"a-105": {
			"id": "a-105",
			"title": "Menu mobile - OPEN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-105-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0d"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0e"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0f"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"value": "none"
					}
				}, {
					"id": "a-105-n-5",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"zValue": -90,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"xValue": -32,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-12",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": "none"
					}
				}, {
					"id": "a-105-n-46",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"yValue": 900,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-80",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-27",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "ad9d207c-7112-d300-f77a-c02c32993b89"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-29",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "0d9eb416-5699-0575-8f30-b34bc83b201d"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-31",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "56e9b4c1-59f7-7df2-9ec2-359c0844168c"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-34",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-35",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-37",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-38",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-39",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-40",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-48",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "1d6fa60f-f97c-465c-15bf-13fbd59aa990"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-105-n-52",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "5187d8cc-7916-280f-d1b9-6f70fc2e8982"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-105-n-50",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "6e5e2d49-82f6-5a57-6d38-3e8a98ec032d"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-105-n-54",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "81234079-ad2a-f5ed-dca0-ab59bec89053"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-58",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0c"
						},
						"value": "flex"
					}
				}, {
					"id": "a-105-n-59",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-60",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-61",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"zValue": -45,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-65",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-105-n-69",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-72",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-105-n-71",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"zValue": -45,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-70",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-73",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-76",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-75",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"zValue": -45,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-83",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".menu__line",
							"selectorGuids": ["cc9c3103-b4a4-4242-21ad-eb2284dab03a"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-84",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-85",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-91",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-105-n-93",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"zValue": 45,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-92",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-94",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-105-n-74",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-105-n-14",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0d"
						},
						"xValue": 32,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-45",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": "flex"
					}
				}, {
					"id": "a-105-n-47",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-81",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 600,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-15",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 100,
						"easing": "outQuint",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0e"
						},
						"xValue": 32,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-17",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "outQuint",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0f"
						},
						"xValue": 32,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-55",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "inOutQuart",
						"duration": 1500,
						"target": {
							"id": "81234079-ad2a-f5ed-dca0-ab59bec89053"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-23",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 500,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"value": "flex"
					}
				}, {
					"id": "a-105-n-25",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-26",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-28",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "inOutQuart",
						"duration": 1500,
						"target": {
							"id": "ad9d207c-7112-d300-f77a-c02c32993b89"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-30",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 700,
						"easing": "inOutQuart",
						"duration": 1500,
						"target": {
							"id": "0d9eb416-5699-0575-8f30-b34bc83b201d"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-82",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 800,
						"easing": "inOutQuart",
						"duration": 1500,
						"target": {
							"selector": ".menu__line",
							"selectorGuids": ["cc9c3103-b4a4-4242-21ad-eb2284dab03a"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-32",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 900,
						"easing": "inOutQuart",
						"duration": 1500,
						"target": {
							"id": "56e9b4c1-59f7-7df2-9ec2-359c0844168c"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-36",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 900,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-33",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 900,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-41",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1100,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-42",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1100,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-62",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1100,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-64",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 1100,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-63",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1100,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-66",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1300,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-68",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1300,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-67",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 1300,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-87",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1300,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-86",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1300,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-43",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1500,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-44",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1500,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-88",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1500,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-90",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1500,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-89",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 1500,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-78",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1700,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-105-n-77",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1700,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-105-n-79",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 1700,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-105-n-49",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 2000,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "1d6fa60f-f97c-465c-15bf-13fbd59aa990"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-105-n-51",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 2200,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "6e5e2d49-82f6-5a57-6d38-3e8a98ec032d"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-105-n-53",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 2400,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "5187d8cc-7916-280f-d1b9-6f70fc2e8982"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1622215765947
		},
		"a-107": {
			"id": "a-107",
			"title": "Menu mobile - CLOSE",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-107-n-5",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "inQuart",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"zValue": -90,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "deg"
					}
				}, {
					"id": "a-107-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inQuart",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"xValue": -32,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-11",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"id": "56e9b4c1-59f7-7df2-9ec2-359c0844168c"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0f"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a10"
						},
						"value": "none"
					}
				}, {
					"id": "a-107-n-16",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-17",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "f4e01045-1c19-f8df-e2ca-8b4b9aa52193"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-31",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 400,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-32",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "inQuart",
						"duration": 600,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-35",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 200,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "bbbd2257-df75-a016-a7b4-4b11c11f7555"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-107-n-10",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"id": "0d9eb416-5699-0575-8f30-b34bc83b201d"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0e"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"yValue": 900,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-36",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "outQuart",
						"duration": 400,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-38",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inQuart",
						"duration": 600,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-37",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 400,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc39"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-107-n-39",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc3b"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-41",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-42",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "9a4d4eb6-0d2b-855a-5231-66e32af2bc37"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-9",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"id": "ad9d207c-7112-d300-f77a-c02c32993b89"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "adf3bcec-a7b9-7ee6-968c-bdba5e2c8a0d"
						},
						"xValue": 0,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-27",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 600,
						"easing": "outQuart",
						"duration": 400,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-28",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 600,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-107-n-30",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "inQuart",
						"duration": 600,
						"target": {
							"id": "90bf6ac8-1aec-f014-557d-13c55d5c3ef1"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-14",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 600,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-15",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 600,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "70dc0722-0f27-54ea-0ea3-2c8d5f25c249"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-21",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 800,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"id": "81234079-ad2a-f5ed-dca0-ab59bec89053"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-20",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 800,
						"easing": "inQuart",
						"duration": 500,
						"target": {
							"id": "6e5e2d49-82f6-5a57-6d38-3e8a98ec032d"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-107-n-23",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 800,
						"easing": "",
						"duration": 400,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-24",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 800,
						"easing": "inQuart",
						"duration": 600,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"xValue": -40,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-34",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 800,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "b7fd9354-c75a-bd8c-da38-4cec0ab90d4e"
						},
						"xValue": 0.6,
						"yValue": 0.6,
						"locked": true
					}
				}, {
					"id": "a-107-n-40",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 800,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "1953c30b-d8ac-beef-a7f1-df6e01b68e43"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-12",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 800,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"xValue": -48,
						"xUnit": "px",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-107-n-13",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 800,
						"easing": "inQuint",
						"duration": 800,
						"target": {
							"id": "bd3125ab-c5db-fe45-1e48-bc5bc69386fe"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-107-n-19",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1000,
						"easing": "inQuart",
						"duration": 500,
						"target": {
							"id": "5187d8cc-7916-280f-d1b9-6f70fc2e8982"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-107-n-18",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1100,
						"easing": "inQuart",
						"duration": 500,
						"target": {
							"id": "1d6fa60f-f97c-465c-15bf-13fbd59aa990"
						},
						"xValue": 0,
						"yValue": 0,
						"locked": true
					}
				}, {
					"id": "a-107-n-33",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1200,
						"easing": "inQuint",
						"duration": 600,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-107-n-7",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "SIBLINGS",
							"id": "22d603c1-d2b5-51e3-3f78-2d24261fd7c3"
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1622215765947
		},
		"a-108": {
			"id": "a-108",
			"title": "Banner / Close",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-108-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "easeOut",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".banner",
							"selectorGuids": ["30b087ac-9a2f-4d31-a1c9-430cfba73d19"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-108-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".banner",
							"selectorGuids": ["30b087ac-9a2f-4d31-a1c9-430cfba73d19"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1642506517073
		},
		"a-110": {
			"id": "a-110",
			"title": "Next - Hover IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-110-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav__projects__single-img",
							"selectorGuids": ["1e887b27-e6ce-c60e-70ac-25053e5e4464"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-110-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-title",
							"selectorGuids": ["d13e6f8e-d3cb-38e0-8478-ea1e3f3a01c0"]
						},
						"yValue": -4,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-110-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-name",
							"selectorGuids": ["b0b99c31-28bc-1a87-a647-3d5bf058b721"]
						},
						"yValue": 4,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-110-n-2",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav__projects__single-img",
							"selectorGuids": ["1e887b27-e6ce-c60e-70ac-25053e5e4464"]
						},
						"xValue": 1.1,
						"yValue": 1.1,
						"locked": true
					}
				}, {
					"id": "a-110-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-title",
							"selectorGuids": ["d13e6f8e-d3cb-38e0-8478-ea1e3f3a01c0"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-110-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-name",
							"selectorGuids": ["b0b99c31-28bc-1a87-a647-3d5bf058b721"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647428874087
		},
		"a-111": {
			"id": "a-111",
			"title": "Next - Hover OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-111-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav__projects__single-img",
							"selectorGuids": ["1e887b27-e6ce-c60e-70ac-25053e5e4464"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-111-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-title",
							"selectorGuids": ["d13e6f8e-d3cb-38e0-8478-ea1e3f3a01c0"]
						},
						"yValue": -4,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-111-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 800,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".nav-projects__single-name",
							"selectorGuids": ["b0b99c31-28bc-1a87-a647-3d5bf058b721"]
						},
						"yValue": 4,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1647428874087
		},
		"a-116": {
			"id": "a-116",
			"title": "Radio hover - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-116-n",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ab"
						},
						"globalSwatchId": "db501570",
						"rValue": 27,
						"bValue": 27,
						"gValue": 27,
						"aValue": 1
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-116-n-2",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "29ee1b45-56ce-d078-234d-c9b91de1f0ab"
						},
						"globalSwatchId": "c1e7705a",
						"rValue": 253,
						"bValue": 40,
						"gValue": 162,
						"aValue": 1
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1633204472364
		},
		"a-117": {
			"id": "a-117",
			"title": "Hover - Cursor OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-117-n",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "inOutQuad",
						"duration": 500,
						"target": {},
						"widthValue": 12,
						"heightValue": 12,
						"widthUnit": "px",
						"heightUnit": "px",
						"locked": false
					}
				}, {
					"id": "a-117-n-2",
					"actionTypeId": "STYLE_BACKGROUND_COLOR",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {},
						"globalSwatchId": "",
						"rValue": 255,
						"bValue": 255,
						"gValue": 255,
						"aValue": 1
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1633204472364
		},
		"a-124": {
			"id": "a-124",
			"title": "Click - Close Form",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-124-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-124-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".close-form-div",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a5"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-124-n-3",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"xValue": 0.9,
						"yValue": 0.9,
						"locked": true
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-124-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".form__container",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a7"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635433761514
		},
		"a-127": {
			"id": "a-127",
			"title": "Q3",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-127-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-127-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-127-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-127-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-127-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": "none"
					}
				}, {
					"id": "a-127-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-127-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-127-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-120": {
			"id": "a-120",
			"title": "Q22",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-120-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-120-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-120-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-120-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-120-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": "none"
					}
				}, {
					"id": "a-120-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-120-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-120-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-121": {
			"id": "a-121",
			"title": "Q5",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-121-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-121-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-121-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-121-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-121-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": "none"
					}
				}, {
					"id": "a-121-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-121-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-121-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-122": {
			"id": "a-122",
			"title": "Q1",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-122-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-122-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-122-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-122-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-122-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": "none"
					}
				}, {
					"id": "a-122-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-122-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-122-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-130": {
			"id": "a-130",
			"title": "Back 4",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-130-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-130-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-130-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-130-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-130-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": "none"
					}
				}, {
					"id": "a-130-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-130-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-130-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-131": {
			"id": "a-131",
			"title": "Back 5",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-131-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-131-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-131-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-131-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-131-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-55",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "26929a89-4a4d-e9fd-8c62-699b70247876"]
						},
						"value": "none"
					}
				}, {
					"id": "a-131-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-131-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-131-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-44",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2a59c563-6ce0-1ad0-beb7-aa884f676847"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-125": {
			"id": "a-125",
			"title": "Back Photos",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-125-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-125-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-125-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-125-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-125-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"value": "none"
					}
				}, {
					"id": "a-125-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-125-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-125-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-118": {
			"id": "a-118",
			"title": "Q2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-118-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-118-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-118-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-118-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-118-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": "none"
					}
				}, {
					"id": "a-118-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-118-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-118-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-129": {
			"id": "a-129",
			"title": "Back 3",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-129-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-129-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-129-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-129-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-129-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-22",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ab"]
						},
						"value": "none"
					}
				}, {
					"id": "a-129-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-129-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-129-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-128": {
			"id": "a-128",
			"title": "Back 2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-128-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-128-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-128-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-128-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-128-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-3",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2f6200d7-276d-cb50-92d8-f05f5f53ae88"]
						},
						"value": "none"
					}
				}, {
					"id": "a-128-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-128-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-128-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-126": {
			"id": "a-126",
			"title": "Back 1",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-126-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-126-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-126-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-126-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-126-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-2",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "2ee275bc-03f7-31d8-14a5-45532221ef8e"]
						},
						"value": "none"
					}
				}, {
					"id": "a-126-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-126-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-126-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635448911371
		},
		"a-115": {
			"id": "a-115",
			"title": "Form - OPEN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-115-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".form__container",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a7"]
						},
						"value": "none"
					}
				}, {
					"id": "a-115-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".close-form-div",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a5"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-115-n-3",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"xValue": 0.9,
						"yValue": 0.9,
						"locked": true
					}
				}, {
					"id": "a-115-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-115-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".form__container",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a7"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-115-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 400,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-115-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".close-form-div",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f562a5"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-115-n-8",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 400,
						"target": {
							"selector": ".form__wrap",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629d"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1635433761514
		},
		"a-123": {
			"id": "a-123",
			"title": "Q Photos",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-123-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inCubic",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"yValue": -30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-123-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-123-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"yValue": 30,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-123-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-123-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".q.is-1",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ac"]
						},
						"value": "none"
					}
				}, {
					"id": "a-123-n-6",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"value": "flex"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-123-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outCubic",
						"duration": 300,
						"target": {
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-123-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "ease",
						"duration": 300,
						"target": {
							"selector": ".q.is-photos",
							"selectorGuids": ["80127651-7f76-2114-2389-4cbff4f5629b", "80127651-7f76-2114-2389-4cbff4f562ae"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1635446921036
		},
		"a-133": {
			"id": "a-133",
			"title": "Page in - Home",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-133-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".preloader",
							"selectorGuids": ["0b825d7d-cdf9-9704-9da9-53b516657a78"]
						},
						"value": "flex"
					}
				}, {
					"id": "a-133-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".panel-left",
							"selectorGuids": ["0e806ca1-983d-9cfa-adb9-3eb9b269c433"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".panel-right",
							"selectorGuids": ["1f0d3ba9-dbb2-e341-a801-59fc57bf4f83"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"xValue": null,
						"yValue": 40,
						"xUnit": "px",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-9",
					"actionTypeId": "TRANSFORM_SKEW",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".panel-right",
							"selectorGuids": ["1f0d3ba9-dbb2-e341-a801-59fc57bf4f83"]
						},
						"yValue": -45,
						"xUnit": "DEG",
						"yUnit": "deg",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-133-n-10",
					"actionTypeId": "TRANSFORM_SKEW",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".panel-left",
							"selectorGuids": ["0e806ca1-983d-9cfa-adb9-3eb9b269c433"]
						},
						"yValue": -45,
						"xUnit": "DEG",
						"yUnit": "deg",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-133-n-11",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".preloader__img",
							"selectorGuids": ["154077c8-8841-9ada-6719-10fd28a1b547"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-133-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1000,
						"easing": "inOutQuart",
						"duration": 1800,
						"target": {
							"selector": ".panel-left",
							"selectorGuids": ["0e806ca1-983d-9cfa-adb9-3eb9b269c433"]
						},
						"xValue": null,
						"yValue": -220,
						"xUnit": "%",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1000,
						"easing": "inOutQuart",
						"duration": 1800,
						"target": {
							"selector": ".panel-right",
							"selectorGuids": ["1f0d3ba9-dbb2-e341-a801-59fc57bf4f83"]
						},
						"xValue": null,
						"yValue": 220,
						"xUnit": "%",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1000,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-133-n-12",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1000,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"selector": ".preloader__img",
							"selectorGuids": ["154077c8-8841-9ada-6719-10fd28a1b547"]
						},
						"xValue": null,
						"yValue": 300,
						"xUnit": "%",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-133-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".preloader",
							"selectorGuids": ["0b825d7d-cdf9-9704-9da9-53b516657a78"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647537186800
		},
		"a-132": {
			"id": "a-132",
			"title": "Homepage - load",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-132-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 2000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5dd49879-bb6d-9761-6b9f-99ef10e8ed50"
						},
						"xValue": 100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce2251"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-9",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 2000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8eac85f7-1afe-c8e0-48bc-0a52a4b25563"
						},
						"xValue": -120,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-10",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8eac85f7-1afe-c8e0-48bc-0a52a4b25563"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-13",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8d57ad6c-62ec-f861-a23d-abc80ad9be26"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-15",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225b"
						},
						"xValue": 0.2,
						"yValue": 0.2,
						"locked": true
					}
				}, {
					"id": "a-132-n-23",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225b"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-17",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225c"
						},
						"xValue": 0.2,
						"yValue": 0.2,
						"locked": true
					}
				}, {
					"id": "a-132-n-19",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225d"
						},
						"xValue": 0.2,
						"yValue": 0.2,
						"locked": true
					}
				}, {
					"id": "a-132-n-21",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225a"
						},
						"xValue": 0.2,
						"yValue": 0.2,
						"locked": true
					}
				}, {
					"id": "a-132-n-25",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225c"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-27",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225d"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-29",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225a"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-32",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1200,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce224e"
						},
						"xValue": null,
						"yValue": -2.2,
						"xUnit": "px",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-33",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce2256"
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060"
						},
						"yValue": 1,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-132-n-35",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37"
						},
						"yValue": 1,
						"xUnit": "PX",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-36",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37"
						},
						"value": 0,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-132-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5dd49879-bb6d-9761-6b9f-99ef10e8ed50"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-12",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 3000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8eac85f7-1afe-c8e0-48bc-0a52a4b25563"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-132-n-11",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 3000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8eac85f7-1afe-c8e0-48bc-0a52a4b25563"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce2251"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-132-n-31",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce224e"
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "px",
						"yUnit": "em",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-16",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1000,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225b"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-132-n-24",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1000,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225b"
						},
						"value": 0.6,
						"unit": ""
					}
				}, {
					"id": "a-132-n-18",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1200,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225c"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-132-n-26",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1200,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225c"
						},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-132-n-34",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 1200,
						"easing": "outQuart",
						"duration": 2000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce2256"
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-20",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1400,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225d"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-132-n-28",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1400,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225d"
						},
						"value": 0.4,
						"unit": ""
					}
				}, {
					"id": "a-132-n-22",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 1600,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225a"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-132-n-30",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 1600,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|918f980a-0561-03d6-d64a-8d6a25ce225a"
						},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-132-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 2000,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-132-n-4",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 2000,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|dcd55a3d-d607-333d-57a0-046353cdf060"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-132-n-14",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 2200,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|8d57ad6c-62ec-f861-a23d-abc80ad9be26"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-132-n-38",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 2400,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-132-n-37",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 2400,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4cb|5d5055c2-e474-3228-4701-1f081e6fbf37"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647534252187
		},
		"a-134": {
			"id": "a-134",
			"title": "CTA photo mobile - Fade in",
			"continuousParameterGroups": [{
				"id": "a-134-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 5,
					"actionItems": [{
						"id": "a-134-n",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "outQuart",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4e7|c6b71904-ba34-b014-8e54-1c429dff0a2a"
							},
							"value": 0,
							"unit": ""
						}
					}]
				}, {
					"keyframe": 10,
					"actionItems": [{
						"id": "a-134-n-3",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "656ef8b027ad4189724cf4e7|c6b71904-ba34-b014-8e54-1c429dff0a2a"
							},
							"value": 1,
							"unit": ""
						}
					}]
				}]
			}],
			"createdOn": 1648650592442
		},
		"a-138": {
			"id": "a-138",
			"title": "Page out - black",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-138-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".colorpanel-left",
							"selectorGuids": ["0e0a5e69-471a-2d0e-037f-abeaeb3d192b"]
						},
						"xValue": null,
						"yValue": -220,
						"xUnit": "px",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".colorpanel-right",
							"selectorGuids": ["ffba3b91-23b2-e4c3-73d9-7f24e85a2975"]
						},
						"xValue": null,
						"yValue": 220,
						"xUnit": "px",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-5",
					"actionTypeId": "TRANSFORM_SKEW",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".colorpanel-right",
							"selectorGuids": ["ffba3b91-23b2-e4c3-73d9-7f24e85a2975"]
						},
						"yValue": -45,
						"xUnit": "DEG",
						"yUnit": "deg",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-138-n-6",
					"actionTypeId": "TRANSFORM_SKEW",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".colorpanel-left",
							"selectorGuids": ["0e0a5e69-471a-2d0e-037f-abeaeb3d192b"]
						},
						"yValue": -45,
						"xUnit": "DEG",
						"yUnit": "deg",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-138-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"value": "none"
					}
				}, {
					"id": "a-138-n-12",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-14",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"value": 1,
						"unit": ""
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-138-n-13",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inOutQuart",
						"duration": 2000,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"yValue": 64,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-11",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".black-curtain_transition",
							"selectorGuids": ["83af7b7a-1703-ef44-629b-b80336e126ac"]
						},
						"value": "block"
					}
				}, {
					"id": "a-138-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"selector": ".colorpanel-left",
							"selectorGuids": ["0e0a5e69-471a-2d0e-037f-abeaeb3d192b"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-9",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1500,
						"target": {
							"selector": ".colorpanel-right",
							"selectorGuids": ["ffba3b91-23b2-e4c3-73d9-7f24e85a2975"]
						},
						"xValue": null,
						"yValue": 0,
						"xUnit": "%",
						"yUnit": "vw",
						"zUnit": "PX"
					}
				}, {
					"id": "a-138-n-15",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 500,
						"easing": "ease",
						"duration": 2000,
						"target": {
							"selector": ".main",
							"selectorGuids": ["2a7e059c-4fba-2232-7be9-76d947a81d21"]
						},
						"value": 0.4,
						"unit": ""
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647537186800
		},
		"a-145": {
			"id": "a-145",
			"title": "Hero - groove text",
			"continuousParameterGroups": [{
				"id": "a-145-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 25,
					"actionItems": [{
						"id": "a-145-n",
						"actionTypeId": "STYLE_SIZE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": true,
								"id": "656ef8b027ad4189724cf4de|f0d8a79a-26d0-1d6b-ce36-54adc2c2b5e9"
							},
							"widthValue": 0,
							"heightValue": 0.25,
							"widthUnit": "%",
							"heightUnit": "rem",
							"locked": false
						}
					}]
				}, {
					"keyframe": 45,
					"actionItems": [{
						"id": "a-145-n-2",
						"actionTypeId": "STYLE_SIZE",
						"config": {
							"delay": 0,
							"easing": "ease",
							"duration": 500,
							"target": {
								"useEventTarget": true,
								"id": "656ef8b027ad4189724cf4de|f0d8a79a-26d0-1d6b-ce36-54adc2c2b5e9"
							},
							"widthValue": 105,
							"heightValue": 0.25,
							"widthUnit": "%",
							"heightUnit": "rem",
							"locked": false
						}
					}]
				}, {
					"keyframe": 50,
					"actionItems": [{
						"id": "a-145-n-3",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".hero__headline.is--last",
								"selectorGuids": ["4fd1f2c1-7db8-9849-6251-0a836cb74cce", "bd96d00a-1336-b769-0a82-40c321ef6a29"]
							},
							"value": 0,
							"unit": ""
						}
					}]
				}, {
					"keyframe": 65,
					"actionItems": [{
						"id": "a-145-n-4",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"selector": ".hero__headline.is--last",
								"selectorGuids": ["4fd1f2c1-7db8-9849-6251-0a836cb74cce", "bd96d00a-1336-b769-0a82-40c321ef6a29"]
							},
							"value": 1,
							"unit": ""
						}
					}]
				}]
			}],
			"createdOn": 1649154597747
		},
		"a-147": {
			"id": "a-147",
			"title": "Loop - logos",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-147-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".clients__loop",
							"selectorGuids": ["034d4657-ba71-5ea6-b988-714510966e1f"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-147-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 25000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".clients__loop",
							"selectorGuids": ["034d4657-ba71-5ea6-b988-714510966e1f"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-147-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".clients__loop",
							"selectorGuids": ["034d4657-ba71-5ea6-b988-714510966e1f"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1651228326564
		},
		"a-148": {
			"id": "a-148",
			"title": "slide in",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-148-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": 0,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-3",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-4",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}, {
					"id": "a-148-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-7",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"zValue": 3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-8",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}, {
					"id": "a-148-n-9",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-10",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": -120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-11",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"zValue": -3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-12",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-148-n-13",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-14",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": -120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-15",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"zValue": -3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-16",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}, {
					"id": "a-148-n-17",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-18",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 0,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-19",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-20",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-148-n-21",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"value": "block"
					}
				}, {
					"id": "a-148-n-22",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": 120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-148-n-23",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"zValue": 3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-148-n-24",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outExpo",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1596072429032
		},
		"a-149": {
			"id": "a-149",
			"title": "slide out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-149-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"value": "none"
					}
				}, {
					"id": "a-149-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": 0,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-149-n-3",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"zValue": 0,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-149-n-4",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.previous",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db1"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}, {
					"id": "a-149-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"value": "none"
					}
				}, {
					"id": "a-149-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-149-n-7",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"zValue": 3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-149-n-8",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.current",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929daf"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}, {
					"id": "a-149-n-9",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"value": "none"
					}
				}, {
					"id": "a-149-n-10",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": -120,
						"xUnit": "PX",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-149-n-11",
					"actionTypeId": "TRANSFORM_ROTATE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"zValue": -3,
						"xUnit": "DEG",
						"yUnit": "DEG",
						"zUnit": "DEG"
					}
				}, {
					"id": "a-149-n-12",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".slide__image.next",
							"selectorGuids": ["e3eda33d-0d3c-bd85-d4c1-629d06929dad", "e3eda33d-0d3c-bd85-d4c1-629d06929db2"]
						},
						"xValue": 0.8,
						"yValue": 0.8,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1596072429032
		},
		"a-150": {
			"id": "a-150",
			"title": "Scroll - testimonials",
			"continuousParameterGroups": [{
				"id": "a-150-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-150-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|f3fc8495-e8bb-6357-1aa4-0d5c7648448b"
							},
							"xValue": 0,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-150-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|a5ca1960-6619-9701-9285-25ea0ff70157"
							},
							"xValue": -32,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-150-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|aa96da57-e0e3-b7ca-9b2f-c8a43e37c56f"
							},
							"xValue": 4,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-150-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|f3fc8495-e8bb-6357-1aa4-0d5c7648448b"
							},
							"xValue": -35,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-150-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|a5ca1960-6619-9701-9285-25ea0ff70157"
							},
							"xValue": -4,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-150-n-6",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"id": "656ef8b027ad4189724cf4db|aa96da57-e0e3-b7ca-9b2f-c8a43e37c56f"
							},
							"xValue": -20,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1652173301723
		},
		"a-151": {
			"id": "a-151",
			"title": "Photo - about",
			"continuousParameterGroups": [{
				"id": "a-151-p",
				"type": "MOUSE_X",
				"parameterLabel": "Mouse X",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-151-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".about__photo",
								"selectorGuids": ["1ebe5f19-d1cc-a315-9586-55316abbf364"]
							},
							"xValue": 2,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-151-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".about__photo",
								"selectorGuids": ["1ebe5f19-d1cc-a315-9586-55316abbf364"]
							},
							"xValue": -2,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}]
				}]
			}, {
				"id": "a-151-p-2",
				"type": "MOUSE_Y",
				"parameterLabel": "Mouse Y",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-151-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".about__photo",
								"selectorGuids": ["1ebe5f19-d1cc-a315-9586-55316abbf364"]
							},
							"yValue": 2,
							"xUnit": "PX",
							"yUnit": "%",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-151-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".about__photo",
								"selectorGuids": ["1ebe5f19-d1cc-a315-9586-55316abbf364"]
							},
							"yValue": -2,
							"xUnit": "PX",
							"yUnit": "%",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1652186971093
		},
		"a-152": {
			"id": "a-152",
			"title": "Load - Design",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-152-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|89b5b512-bb2c-08af-a626-8a3ecb623378"
						},
						"xValue": null,
						"yValue": -100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|5dae0344-2210-fe7f-9a0a-f3ba68c802c3"
						},
						"xValue": null,
						"yValue": 100,
						"xUnit": "px",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "easeInOut",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f"
						},
						"yValue": 50,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-7",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-9",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a13db041-5da7-2020-e35c-bb7e66259938"
						},
						"xValue": 0.1,
						"yValue": 0.1,
						"locked": true
					}
				}, {
					"id": "a-152-n-11",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a13db041-5da7-2020-e35c-bb7e66259938"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-13",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|d1c1da47-d80b-1aa1-9633-3397c37c6210"
						},
						"xValue": 0.1,
						"yValue": 0.1,
						"locked": true
					}
				}, {
					"id": "a-152-n-14",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|d1c1da47-d80b-1aa1-9633-3397c37c6210"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-17",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|906d5213-967a-103e-5440-6b1bcf5b8dcb"
						},
						"xValue": 0.1,
						"yValue": 0.1,
						"locked": true
					}
				}, {
					"id": "a-152-n-18",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|906d5213-967a-103e-5440-6b1bcf5b8dcb"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-21",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|b92c173d-5611-b281-13a9-9f4c37e2a74a"
						},
						"xValue": 0.1,
						"yValue": 0.1,
						"locked": true
					}
				}, {
					"id": "a-152-n-22",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|b92c173d-5611-b281-13a9-9f4c37e2a74a"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-25",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a9aee1ea-e9e3-a921-1124-164be8dd4c70"
						},
						"xValue": 0.1,
						"yValue": 0.1,
						"locked": true
					}
				}, {
					"id": "a-152-n-26",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a9aee1ea-e9e3-a921-1124-164be8dd4c70"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-30",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".webpages__container.is--1",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "c5194e3c-982d-083f-1dab-3ed122434c02"]
						},
						"yValue": 50,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-32",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".webpages__container.is--2",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "b00f3433-799e-015b-5117-529d86cf42c4"]
						},
						"yValue": 50,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-34",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".webpages__container.is--3",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "ba7bc67d-af7e-dc38-4eb1-1848abd9cc72"]
						},
						"yValue": 50,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-36",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".webpages__container.is--4",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "f623f3b2-2db3-6610-dfe0-f69f87f47c2c"]
						},
						"yValue": 50,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-38",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|7e286e84-b54f-0442-122c-714371a9939f"
						},
						"value": 0,
						"unit": ""
					}
				}, {
					"id": "a-152-n-40",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf4de|89b5b512-bb2c-08af-a626-8a3ecb623378"
						},
						"value": "none"
					}
				}, {
					"id": "a-152-n-42",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf4de|5dae0344-2210-fe7f-9a0a-f3ba68c802c3"
						},
						"value": "none"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-152-n-10",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a13db041-5da7-2020-e35c-bb7e66259938"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-152-n-12",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a13db041-5da7-2020-e35c-bb7e66259938"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-41",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf4de|89b5b512-bb2c-08af-a626-8a3ecb623378"
						},
						"value": "inline-block"
					}
				}, {
					"id": "a-152-n-43",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"id": "656ef8b027ad4189724cf4de|5dae0344-2210-fe7f-9a0a-f3ba68c802c3"
						},
						"value": "inline-block"
					}
				}, {
					"id": "a-152-n-16",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 100,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|d1c1da47-d80b-1aa1-9633-3397c37c6210"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-15",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 100,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|d1c1da47-d80b-1aa1-9633-3397c37c6210"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-152-n-39",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 100,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|7e286e84-b54f-0442-122c-714371a9939f"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-20",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 200,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|906d5213-967a-103e-5440-6b1bcf5b8dcb"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-152-n-19",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 200,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|906d5213-967a-103e-5440-6b1bcf5b8dcb"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-31",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 200,
						"easing": "outCubic",
						"duration": 1000,
						"target": {
							"selector": ".webpages__container.is--1",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "c5194e3c-982d-083f-1dab-3ed122434c02"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-24",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 300,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|b92c173d-5611-b281-13a9-9f4c37e2a74a"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-23",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 300,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|b92c173d-5611-b281-13a9-9f4c37e2a74a"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-152-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "outQuart",
						"duration": 1400,
						"target": {
							"id": "656ef8b027ad4189724cf4de|89b5b512-bb2c-08af-a626-8a3ecb623378"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "outQuart",
						"duration": 1400,
						"target": {
							"id": "656ef8b027ad4189724cf4de|5dae0344-2210-fe7f-9a0a-f3ba68c802c3"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-33",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 300,
						"easing": "outCubic",
						"duration": 1000,
						"target": {
							"selector": ".webpages__container.is--2",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "b00f3433-799e-015b-5117-529d86cf42c4"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-28",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 400,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a9aee1ea-e9e3-a921-1124-164be8dd4c70"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-152-n-27",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "",
						"duration": 1000,
						"target": {
							"id": "656ef8b027ad4189724cf4de|a9aee1ea-e9e3-a921-1124-164be8dd4c70"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-8",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 400,
						"easing": "",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-152-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "easeInOut",
						"duration": 500,
						"target": {
							"id": "656ef8b027ad4189724cf4de|69fb5aed-6142-f41b-0758-42108db73a5f"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-35",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 400,
						"easing": "outCubic",
						"duration": 1000,
						"target": {
							"selector": ".webpages__container.is--3",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "ba7bc67d-af7e-dc38-4eb1-1848abd9cc72"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-152-n-37",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 500,
						"easing": "outCubic",
						"duration": 1000,
						"target": {
							"selector": ".webpages__container.is--4",
							"selectorGuids": ["a3505c9b-fc70-daf8-2c4a-9d72fc7b5f20", "f623f3b2-2db3-6610-dfe0-f69f87f47c2c"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1652886238680
		},
		"a-153": {
			"id": "a-153",
			"title": "Parallax - Branding",
			"continuousParameterGroups": [{
				"id": "a-153-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-153-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--1.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "260366f5-cb30-a6ec-b586-6ca7b41aa50d", "ab716df8-cd64-5121-c0ea-3b8d25935b17"]
							},
							"xValue": -2,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-153-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--2.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "c61c5b98-d5aa-d92d-5095-5e146952b21e", "f446e1a3-275d-39ee-afbe-f2da835162c0"]
							},
							"xValue": 20,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-153-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--3.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "31ccd36d-78b7-1caf-1414-767229b14d3c", "0f905a18-d124-3be8-0222-49842d417501"]
							},
							"xValue": -24,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-153-n-7",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--4.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "29ad4c04-9f94-28f5-378b-0acc26870e60", "b513c93c-a367-fe8c-82a0-bcd40df8dc48"]
							},
							"xValue": 8,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 20,
					"actionItems": [{
						"id": "a-153-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--1.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "260366f5-cb30-a6ec-b586-6ca7b41aa50d", "ab716df8-cd64-5121-c0ea-3b8d25935b17"]
							},
							"xValue": 2,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-153-n-6",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--3.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "31ccd36d-78b7-1caf-1414-767229b14d3c", "0f905a18-d124-3be8-0222-49842d417501"]
							},
							"xValue": 0,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 24,
					"actionItems": [{
						"id": "a-153-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--2.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "c61c5b98-d5aa-d92d-5095-5e146952b21e", "f446e1a3-275d-39ee-afbe-f2da835162c0"]
							},
							"xValue": 0,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-153-n-8",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".branding__logo.is--4.shadow",
								"selectorGuids": ["6fe7ba95-04bb-3b48-3f4b-b5e1257abd81", "29ad4c04-9f94-28f5-378b-0acc26870e60", "b513c93c-a367-fe8c-82a0-bcd40df8dc48"]
							},
							"xValue": 0,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1652893127810
		},
		"a-154": {
			"id": "a-154",
			"title": "Parallax - Affiches Desktop",
			"continuousParameterGroups": [{
				"id": "a-154-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-154-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--left",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "4100013b-79d0-64e3-fc86-1aabb96d7115"]
							},
							"yValue": 20,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-154-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--right",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "d5d10d5d-2350-98b4-8a31-7c15bc9c4dba"]
							},
							"yValue": -2,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-154-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--left",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "4100013b-79d0-64e3-fc86-1aabb96d7115"]
							},
							"yValue": -20,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-154-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--right",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "d5d10d5d-2350-98b4-8a31-7c15bc9c4dba"]
							},
							"yValue": 2,
							"xUnit": "PX",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1652982342194
		},
		"a-155": {
			"id": "a-155",
			"title": "Footer - Hover IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-155-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "01335317-1c68-65ab-5190-63ba0e62ca39"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-155-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca3c"
						},
						"yValue": -8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-155-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca42"
						},
						"yValue": 8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-155-n-4",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": true,
							"id": "01335317-1c68-65ab-5190-63ba0e62ca39"
						},
						"xValue": 1.02,
						"yValue": 1.02,
						"locked": true
					}
				}, {
					"id": "a-155-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca3c"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-155-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca42"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647428874087
		},
		"a-156": {
			"id": "a-156",
			"title": "Footer - Hover OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-156-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "01335317-1c68-65ab-5190-63ba0e62ca39"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-156-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca3c"
						},
						"yValue": -8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-156-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "01335317-1c68-65ab-5190-63ba0e62ca42"
						},
						"yValue": 8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1647428874087
		},
		"a-157": {
			"id": "a-157",
			"title": "Parallax - Affiches Mobile",
			"continuousParameterGroups": [{
				"id": "a-157-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-157-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--left",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "4100013b-79d0-64e3-fc86-1aabb96d7115"]
							},
							"xValue": -10,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-157-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--right",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "d5d10d5d-2350-98b4-8a31-7c15bc9c4dba"]
							},
							"xValue": 10,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-157-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--left",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "4100013b-79d0-64e3-fc86-1aabb96d7115"]
							},
							"xValue": 10,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}, {
						"id": "a-157-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".skills__posters-column.is--right",
								"selectorGuids": ["e6de3a0f-16e2-1f1a-38cd-64175593f95b", "d5d10d5d-2350-98b4-8a31-7c15bc9c4dba"]
							},
							"xValue": -10,
							"yValue": null,
							"xUnit": "em",
							"yUnit": "em",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1652982342194
		},
		"a-144": {
			"id": "a-144",
			"title": "Photos - Out",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-144-n-2",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"value": "flex"
					}
				}, {
					"id": "a-144-n-6",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 0,
						"easing": "inOutQuart",
						"duration": 1000,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"widthValue": 100,
						"heightValue": 0,
						"widthUnit": "%",
						"heightUnit": "%",
						"locked": false
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-144-n-5",
					"actionTypeId": "STYLE_SIZE",
					"config": {
						"delay": 200,
						"easing": "inOutQuart",
						"duration": 1400,
						"target": {
							"selector": ".photo-transition",
							"selectorGuids": ["67b16d99-9e41-aaa8-2ff7-147765c9d047"]
						},
						"widthValue": 100,
						"heightValue": 100,
						"widthUnit": "%",
						"heightUnit": "%",
						"locked": false
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1648734303599
		},
		"a-159": {
			"id": "a-159",
			"title": "Hover - Zone 1 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-159-n-5",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-1",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "e7950dd7-9075-40c2-8f21-25f8396c0352"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-160": {
			"id": "a-160",
			"title": "Hover - Zone 1 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-160-n-4",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-1",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "e7950dd7-9075-40c2-8f21-25f8396c0352"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1653312474615
		},
		"a-170": {
			"id": "a-170",
			"title": "Hover - Zone 2 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-170-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-2",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "8c438748-a14c-e28c-c09e-3140c08938d0"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1653312474615
		},
		"a-171": {
			"id": "a-171",
			"title": "Hover - Zone 3 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-171-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-3",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "22b6a8b6-feab-c829-3820-2a9303fcb797"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-165": {
			"id": "a-165",
			"title": "Hover - Zone 3 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-165-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-3",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "22b6a8b6-feab-c829-3820-2a9303fcb797"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1653312474615
		},
		"a-172": {
			"id": "a-172",
			"title": "Hover - Zone 4 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-172-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-4",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "8002d5ce-243e-2595-f684-0c43897c30f2"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-167": {
			"id": "a-167",
			"title": "Hover - Zone 4 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-167-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-4",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "8002d5ce-243e-2595-f684-0c43897c30f2"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1653312474615
		},
		"a-173": {
			"id": "a-173",
			"title": "Hover - Zone 5 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-173-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-5",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "6832fb0f-4985-9fac-75df-58548c204890"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-169": {
			"id": "a-169",
			"title": "Hover - Zone 5 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-169-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-5",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "6832fb0f-4985-9fac-75df-58548c204890"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1653312474615
		},
		"a-174": {
			"id": "a-174",
			"title": "Hover - Zone 6 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-174-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-6",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "452cec96-489f-e385-8047-9e7116499c21"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-175": {
			"id": "a-175",
			"title": "Hover - Zone 6 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-175-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-6",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "452cec96-489f-e385-8047-9e7116499c21"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-176": {
			"id": "a-176",
			"title": "Hover - Zone 7 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-176-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-7",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "ba1601c3-930a-a98c-fdce-61c0ca65a690"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-177": {
			"id": "a-177",
			"title": "Hover - Zone 7 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-177-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-6",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "452cec96-489f-e385-8047-9e7116499c21"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-178": {
			"id": "a-178",
			"title": "Hover - Zone 8 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-178-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-8",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "85fba81f-3be6-ce32-82b0-93dc4296c41f"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-180": {
			"id": "a-180",
			"title": "Hover - Zone 8 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-180-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-6",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "452cec96-489f-e385-8047-9e7116499c21"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-179": {
			"id": "a-179",
			"title": "Hover - Zone 9 - IN",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-179-n-10",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-9",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "ee501307-936b-7063-c45f-7653e1c7c250"]
						},
						"value": "block"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-181": {
			"id": "a-181",
			"title": "Hover - Zone 9 - OUT",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-181-n",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 0,
						"target": {
							"selector": ".portrait.is-6",
							"selectorGuids": ["9013c5ab-3276-8148-7baf-5394a3b0a480", "452cec96-489f-e385-8047-9e7116499c21"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1653312474615
		},
		"a-182": {
			"id": "a-182",
			"title": "WG Selector 1-2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-182-n",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"useEventTarget": true,
							"id": "b2839d15-cd17-e3c9-4a45-96f6c755104f"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-182-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".wg-selector-1.s2",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fb", "e4f0c885-4c92-a0a8-15cc-aeee67b866ff"]
						},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-182-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"selector": ".wg-selector-highlight.h2",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b86700"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-182-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 80,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"selector": ".wg-selector-highlight.h1",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b866fe"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1578680477085
		},
		"a-183": {
			"id": "a-183",
			"title": "WG Selector 1-1",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-183-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".wg-selector-highlight.h1",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b866fe"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-183-n-2",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".wg-selector-1.s1",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fb", "e4f0c885-4c92-a0a8-15cc-aeee67b86702"]
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-183-n-3",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "b2839d15-cd17-e3c9-4a45-96f6c7551054"
						},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-183-n-4",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"selector": ".wg-selector-highlight.h2",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b86700"]
						},
						"xValue": -100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-183-n-5",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"useEventTarget": "SIBLINGS",
							"selector": ".wg-selector-1.s1",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fb", "e4f0c885-4c92-a0a8-15cc-aeee67b86702"]
						},
						"value": 0.5,
						"unit": ""
					}
				}, {
					"id": "a-183-n-6",
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"useEventTarget": true,
							"id": "b2839d15-cd17-e3c9-4a45-96f6c7551054"
						},
						"value": 1,
						"unit": ""
					}
				}, {
					"id": "a-183-n-7",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"selector": ".wg-selector-highlight.h1",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b866fe"]
						},
						"xValue": 100,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}, {
					"id": "a-183-n-8",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 80,
						"easing": "inQuad",
						"duration": 100,
						"target": {
							"selector": ".wg-selector-highlight.h2",
							"selectorGuids": ["e4f0c885-4c92-a0a8-15cc-aeee67b866fc", "e4f0c885-4c92-a0a8-15cc-aeee67b86700"]
						},
						"xValue": 0,
						"xUnit": "%",
						"yUnit": "PX",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1578680477085
		},
		"a-75": {
			"id": "a-75",
			"title": "hoz-move-card",
			"continuousParameterGroups": [{
				"id": "a-75-p",
				"type": "MOUSE_X",
				"parameterLabel": "Mouse X",
				"continuousActionGroups": [{
					"keyframe": 0,
					"actionItems": [{
						"id": "a-75-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".project__gallery",
								"selectorGuids": ["39d2d500-5e50-2ac0-f328-3485d2664afc"]
							},
							"xValue": 22,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": -40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-3",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-4",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": -40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-5",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 50,
					"actionItems": [{
						"id": "a-75-n-6",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-7",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-8",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-9",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-75-n-10",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".project__gallery",
								"selectorGuids": ["39d2d500-5e50-2ac0-f328-3485d2664afc"]
							},
							"xValue": -22,
							"xUnit": "%",
							"yUnit": "PX",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-11",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-12",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": -40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-13",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": 40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}, {
						"id": "a-75-n-14",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {},
							"yValue": -40,
							"xUnit": "PX",
							"yUnit": "px",
							"zUnit": "PX"
						}
					}]
				}]
			}, {
				"id": "a-75-p-2",
				"type": "MOUSE_Y",
				"parameterLabel": "Mouse Y",
				"continuousActionGroups": []
			}],
			"createdOn": 1621934512209
		},
		"a-188": {
			"id": "a-188",
			"title": "Parallax photo hero",
			"continuousParameterGroups": [{
				"id": "a-188-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 50,
					"actionItems": [{
						"id": "a-188-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".reportage_hero-content",
								"selectorGuids": ["256b8b99-9396-ab13-7fa5-800ac8bb4a17"]
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "rem",
							"zUnit": "PX"
						}
					}]
				}, {
					"keyframe": 100,
					"actionItems": [{
						"id": "a-188-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"useEventTarget": "CHILDREN",
								"selector": ".reportage_hero-content",
								"selectorGuids": ["256b8b99-9396-ab13-7fa5-800ac8bb4a17"]
							},
							"yValue": -5,
							"xUnit": "PX",
							"yUnit": "rem",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1697538049736
		},
		"a-189": {
			"id": "a-189",
			"title": "Zoom in",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-189-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".hero_img",
							"selectorGuids": ["256b8b99-9396-ab13-7fa5-800ac8bb4a12"]
						},
						"xValue": 1.1,
						"yValue": 1.1,
						"locked": true
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-189-n-2",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 20000,
						"target": {
							"useEventTarget": "CHILDREN",
							"selector": ".hero_img",
							"selectorGuids": ["256b8b99-9396-ab13-7fa5-800ac8bb4a12"]
						},
						"xValue": 1.3,
						"yValue": 1.3,
						"locked": true
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1697537968636
		},
		"a-191": {
			"id": "a-191",
			"title": "Footer - Hover IN 2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-191-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-191-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f40"
						},
						"yValue": -8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-191-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f46"
						},
						"yValue": 8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-191-n-4",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": true,
							"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95"
						},
						"xValue": 1.02,
						"yValue": 1.02,
						"locked": true
					}
				}, {
					"id": "a-191-n-5",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f40"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-191-n-6",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f46"
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1647428874087
		},
		"a-192": {
			"id": "a-192",
			"title": "Footer - Hover OUT 2",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-192-n",
					"actionTypeId": "TRANSFORM_SCALE",
					"config": {
						"delay": 0,
						"easing": "",
						"duration": 500,
						"target": {
							"useEventTarget": true,
							"id": "664337bfa31c2c190eb37350|5aba4ec8-d907-e82e-50bc-157c38754c95"
						},
						"xValue": 1,
						"yValue": 1,
						"locked": true
					}
				}, {
					"id": "a-192-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f40"
						},
						"yValue": -8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}, {
					"id": "a-192-n-3",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"useEventTarget": "CHILDREN",
							"id": "664337bfa31c2c190eb37350|7d7186e0-28ce-c8ec-6696-65daa73b1f46"
						},
						"yValue": 8,
						"xUnit": "PX",
						"yUnit": "px",
						"zUnit": "PX"
					}
				}]
			}],
			"useFirstGroupAsInitialState": false,
			"createdOn": 1647428874087
		},
		"a-195": {
			"id": "a-195",
			"title": "Neswletter - appear",
			"continuousParameterGroups": [{
				"id": "a-195-p",
				"type": "SCROLL_PROGRESS",
				"parameterLabel": "Scroll",
				"continuousActionGroups": [{
					"keyframe": 10,
					"actionItems": [{
						"id": "a-195-n",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "easeOut",
							"duration": 500,
							"target": {
								"id": "664337bfa31c2c190eb37350|6d3917d5-d054-f06f-0830-bd712fb29059"
							},
							"yValue": 100,
							"xUnit": "PX",
							"yUnit": "%",
							"zUnit": "PX"
						}
					}, {
						"id": "a-195-n-3",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "664337bfa31c2c190eb37350|6d3917d5-d054-f06f-0830-bd712fb29059"
							},
							"value": 0,
							"unit": ""
						}
					}]
				}, {
					"keyframe": 11,
					"actionItems": [{
						"id": "a-195-n-4",
						"actionTypeId": "STYLE_OPACITY",
						"config": {
							"delay": 0,
							"easing": "",
							"duration": 500,
							"target": {
								"id": "664337bfa31c2c190eb37350|6d3917d5-d054-f06f-0830-bd712fb29059"
							},
							"value": 1,
							"unit": ""
						}
					}]
				}, {
					"keyframe": 15,
					"actionItems": [{
						"id": "a-195-n-2",
						"actionTypeId": "TRANSFORM_MOVE",
						"config": {
							"delay": 0,
							"easing": "easeOut",
							"duration": 500,
							"target": {
								"id": "664337bfa31c2c190eb37350|6d3917d5-d054-f06f-0830-bd712fb29059"
							},
							"yValue": 0,
							"xUnit": "PX",
							"yUnit": "%",
							"zUnit": "PX"
						}
					}]
				}]
			}],
			"createdOn": 1715764260106
		},
		"a-196": {
			"id": "a-196",
			"title": "Newsletter - close",
			"actionItemGroups": [{
				"actionItems": [{
					"id": "a-196-n",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".section_newsletter",
							"selectorGuids": ["5e09adec-d68a-97d3-f23b-ffb7c60dc5f8"]
						},
						"yValue": 0,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}]
			}, {
				"actionItems": [{
					"id": "a-196-n-2",
					"actionTypeId": "TRANSFORM_MOVE",
					"config": {
						"delay": 0,
						"easing": "outQuint",
						"duration": 1000,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".section_newsletter",
							"selectorGuids": ["5e09adec-d68a-97d3-f23b-ffb7c60dc5f8"]
						},
						"yValue": 100,
						"xUnit": "PX",
						"yUnit": "%",
						"zUnit": "PX"
					}
				}, {
					"id": "a-196-n-3",
					"actionTypeId": "GENERAL_DISPLAY",
					"config": {
						"delay": 1000,
						"easing": "",
						"duration": 0,
						"target": {
							"useEventTarget": "PARENT",
							"selector": ".section_newsletter",
							"selectorGuids": ["5e09adec-d68a-97d3-f23b-ffb7c60dc5f8"]
						},
						"value": "none"
					}
				}]
			}],
			"useFirstGroupAsInitialState": true,
			"createdOn": 1715764559596
		},
		"fadeIn": {
			"id": "fadeIn",
			"useFirstGroupAsInitialState": true,
			"actionItemGroups": [{
				"actionItems": [{
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"duration": 0,
						"target": {
							"id": "N/A",
							"appliesTo": "TRIGGER_ELEMENT",
							"useEventTarget": true
						},
						"value": 0
					}
				}]
			}, {
				"actionItems": [{
					"actionTypeId": "STYLE_OPACITY",
					"config": {
						"delay": 0,
						"easing": "outQuart",
						"duration": 1000,
						"target": {
							"id": "N/A",
							"appliesTo": "TRIGGER_ELEMENT",
							"useEventTarget": true
						},
						"value": 1
					}
				}]
			}]
		}
	},
	"site": {
		"mediaQueries": [{
			"key": "main",
			"min": 992,
			"max": 10000
		}, {
			"key": "medium",
			"min": 768,
			"max": 991
		}, {
			"key": "small",
			"min": 480,
			"max": 767
		}, {
			"key": "tiny",
			"min": 0,
			"max": 479
		}]
	}
});