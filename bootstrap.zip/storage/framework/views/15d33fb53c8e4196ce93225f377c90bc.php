New Contact Form Submission

Name: <?php echo e($formData['name']); ?>

Company: <?php echo e($formData['company'] ?? 'Not provided'); ?>

Email: <?php echo e($formData['email']); ?>

Phone: <?php echo e($formData['phone']); ?>


<?php if(!empty($formData['besoin'])): ?>
What do they need: <?php echo e($formData['besoin']); ?>

<?php endif; ?>

<?php if(!empty($formData['deadline'])): ?>
When do they need it: <?php echo e($formData['deadline']); ?>

<?php endif; ?>

<?php if(!empty($formData['budget'])): ?>
Budget: <?php echo e($formData['budget']); ?>

<?php endif; ?>

<?php if(!empty($formData['discovered'])): ?>
How did they discover you: <?php echo e($formData['discovered']); ?>

<?php endif; ?>

<?php if(!empty($formData['message'])): ?>

Message:
<?php echo e($formData['message']); ?>

<?php endif; ?>

<?php /**PATH D:\xampp\htdocs\raja-ahsan-laravel\resources\views/emails/contact-form.blade.php ENDPATH**/ ?>